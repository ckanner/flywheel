/**
 * Private POSIX group guardian for one Codex app-server.
 *
 * The caller creates this process as a group leader and establishes the IPC
 * lifeline in the same spawn operation. Codex inherits this group, but never
 * the IPC descriptor. An abruptly killed caller therefore closes the lifeline
 * even if Codex is hung, before or after initialization. The guardian then
 * terminates only its own group with a finite TERM/KILL sequence.
 *
 * A live caller can request a normal stop with SIGTERM/SIGINT. In that case the
 * caller keeps ownership and confirms the group itself, so this process exits
 * as soon as the app-server exits instead of making every normal delegation
 * sleep the whole dispose grace. A caller death (IPC disconnect) keeps the
 * full grace: there the guardian is the last group owner and must clean up
 * descendants that outlive the app-server.
 *
 * Normal cleanup is confirmed by the surviving caller with kill(-pgid, 0).
 * Emergency cleanup cannot write a final receipt after killing this guardian;
 * missing app-server exit facts must remain unknown in the caller's receipt.
 */
export {};
//# sourceMappingURL=process-guardian.d.ts.map