import type { MachineOptions, MachineReceipt, MachineRequest } from './machine.ts';
export interface MachineHostOptions {
    readonly env: Readonly<Record<string, string | undefined>>;
    readonly recoveryDirectory?: string;
}
/** This promise rejects on incomplete evidence; it never fabricates a successful receipt. */
export declare function superviseMachine(request: MachineRequest, options: MachineOptions): Promise<MachineReceipt>;
//# sourceMappingURL=machine-supervision.d.ts.map