import { type MachineRequest, type MachineOptions, type MachineReceipt } from './machine.ts';
/** Private supervisor entry; callers use runMachine so caller death cannot lose cleanup persistence. */
export declare function runMachineLocal(value: MachineRequest, options?: MachineOptions, id?: string, persistReceipt?: (receipt: MachineReceipt) => void): Promise<MachineReceipt>;
//# sourceMappingURL=machine-local.d.ts.map