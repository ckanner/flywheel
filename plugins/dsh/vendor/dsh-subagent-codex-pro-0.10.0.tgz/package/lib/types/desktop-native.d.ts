/** Desktop configuration and per-call policy over the shared native protocol. */
import { type NativeRequest, type NativeReceipt } from './native.ts';
/** Undefined inherits CLI defaults; null explicitly disables native agents. */
export type DesktopNative = NativeRequest | null;
/** Schemastery's volatile output, kept structural so the machine API stays independent. */
export interface NativeSetting {
    get(): DesktopNative | undefined;
}
export type NativeConfigValue = DesktopNative | NativeSetting;
/** Read one immutable snapshot for this delegation, including live settings updates. */
export declare function readNativeDefault(setting: NativeConfigValue | undefined): NativeRequest | undefined;
/** A normal delegation cannot silently turn into review/start, which ignores its prompt. */
export declare function parseDesktopNative(value: unknown): NativeRequest | undefined;
/**
 * A supplied native object replaces the whole default. Off never retains
 * concurrency, model, effort, or backend settings from an enabled default.
 */
export declare function resolveDesktopNative(defaults: NativeRequest | undefined, override: DesktopNative | undefined, modelSelection: boolean): NativeRequest | undefined;
/** Stable identity for implicit session reuse, independent of JSON key order. */
export declare function nativeSessionKey(native: NativeRequest | undefined, cwd: string, model: string | undefined, effort: string | undefined, permission: string): string;
/**
 * Bounded, valid JSON metadata for Host diagnostics and error-only surfaces.
 * Full receipts remain available in direct-tool and background-job results.
 */
export declare function nativeDiagnostic(native: NativeReceipt): string;
/** Public tool schema; the shared parser also enforces it for direct callers. */
export declare const desktopNativeSchema: Record<string, unknown>;
/** Explicit, operation-specific target. There is no prompt that review could ignore. */
export declare const reviewTargetSchema: Record<string, unknown>;
//# sourceMappingURL=desktop-native.d.ts.map