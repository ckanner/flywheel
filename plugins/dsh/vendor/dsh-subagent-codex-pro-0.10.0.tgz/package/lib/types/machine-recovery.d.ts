import type { MachineReceipt } from './machine.ts';
export declare const MACHINE_LIFECYCLE_VERSION: 1;
export declare const MACHINE_LIFECYCLE_CAPABILITIES: Readonly<{
    version: 1;
    durableJournal: true;
    readOnlyRecovery: true;
    threadReadyBeforeDispatch: true;
}>;
export interface MachineLifecycleEvent {
    readonly lifecycleVersion: 1;
    readonly type: 'lifecycle';
    readonly requestId: string;
    readonly runId: string;
    readonly sequence: number;
    readonly event: 'thread-ready' | 'dispatch-intent' | 'dispatch-possible' | 'turn-accepted' | 'terminal' | 'cleanup-confirmed';
    readonly threadId: string | null;
    readonly turnId: string | null;
    /** Requested history mode; thread-ready configuration carries the backend evidence. */
    readonly persistent: boolean;
    readonly configuration: Readonly<Record<string, unknown>> | null;
    readonly dispatch: 'not-dispatched' | 'possible' | 'accepted';
    readonly outcome: 'unknown' | 'completed' | 'failed' | 'cancelled';
    readonly cleanupConfirmed: boolean;
}
export interface MachineRecoveryRequest {
    readonly protocol: 1;
    readonly requestId: string;
    readonly runId: string;
    readonly recoveryDirectory: string;
}
export interface MachineRecoveryReceipt {
    readonly protocol: 1;
    readonly type: 'recovery';
    readonly requestId: string;
    readonly runId: string;
    readonly status: 'terminal' | 'pending' | 'unknown';
    readonly receipt: MachineReceipt | null;
    readonly lifecycle: MachineLifecycleEvent | null;
    readonly reason: string;
}
/** A recovery path is deliberately not a search root, an alias or a symlink. */
export declare function validateRecoveryDirectory(value: unknown, existing?: boolean): asserts value is string;
export declare function validLifecycle(value: unknown, requestId: string, runId: string): value is MachineLifecycleEvent;
/** One writer, exclusive directory admission, atomic replacement and directory fsync. */
export declare class MachineJournal {
    #private;
    constructor(directory: string, requestId: string, runId: string);
    lifecycle(event: MachineLifecycleEvent): void;
    receipt(receipt: MachineReceipt): void;
}
/** Read exactly one owned journal. Never starts a process, contacts a model or changes files. */
export declare function recoverMachine(value: MachineRecoveryRequest): Promise<MachineRecoveryReceipt>;
//# sourceMappingURL=machine-recovery.d.ts.map