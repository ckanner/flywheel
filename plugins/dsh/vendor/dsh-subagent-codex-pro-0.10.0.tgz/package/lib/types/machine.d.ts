/** Versioned, host-independent entry point for deterministic orchestrators. */
import { type NativeRequest, type NativeReceipt, type NativeEvent } from './native.ts';
export { MACHINE_NATIVE_VERSION, MACHINE_NATIVE_CAPABILITIES } from './native.ts';
export type { NativeRequest, NativeReceipt, NativeEvent } from './native.ts';
import type { CodexRunFailure, CodexRunOutcome } from './run.ts';
import { type MachineLifecycleEvent } from './machine-recovery.ts';
export { MACHINE_LIFECYCLE_VERSION, MACHINE_LIFECYCLE_CAPABILITIES, recoverMachine } from './machine-recovery.ts';
export type { MachineLifecycleEvent, MachineRecoveryRequest, MachineRecoveryReceipt } from './machine-recovery.ts';
export declare const MACHINE_PROTOCOL_VERSION: 1;
/** Caller input contains no credentials. Child authentication stays in its environment. */
export interface MachineRequest {
    readonly protocol: 1;
    readonly requestId: string;
    readonly prompt: string;
    readonly cwd: string;
    readonly model: string;
    readonly effort: string;
    readonly permissionMode: 'read-only' | 'workspace-write' | 'dangerously-bypass-approvals-and-sandbox';
    readonly command?: string;
    readonly timeoutMs?: number;
    readonly maxOutputBytes?: number;
    readonly threadMode?: 'ephemeral' | 'persistent';
    readonly threadId?: string;
    readonly images?: readonly string[];
    readonly outputSchema?: Record<string, unknown>;
    readonly native?: NativeRequest;
}
export interface MachineOptions {
    readonly signal?: AbortSignal;
    readonly env?: Readonly<Record<string, string>>;
    readonly onProgress?: (text: string) => void;
    readonly onNativeEvent?: (event: NativeEvent) => void;
    /** Returning resolves the caller's durable checkpoint ACK. Rejection stops dispatch. */
    readonly onLifecycle?: (event: MachineLifecycleEvent) => Promise<void> | void;
    /** A NEW private directory; its canonical parent must already exist. Never reused. */
    readonly recoveryDirectory?: string;
}
/** The result is not mixed into the model's structured answer or human thread marker. */
export interface MachineReceipt {
    readonly protocol: 1;
    readonly type: 'result';
    readonly requestId: string;
    readonly runId: string;
    readonly ok: boolean;
    readonly requested: {
        readonly cwd: string;
        readonly model: string;
        readonly effort: string;
        readonly permissionMode: MachineRequest['permissionMode'];
        readonly threadId: string | null;
    };
    readonly outcome: CodexRunOutcome | null;
    readonly failure: {
        readonly stage: string;
        readonly category: string;
        readonly diagnostic: string;
        readonly execution: CodexRunFailure['execution'] | null;
        readonly configuration: CodexRunFailure['configuration'] | null;
        readonly usage: CodexRunFailure['usage'] | null;
        readonly rateLimits: CodexRunFailure['rateLimits'] | null;
        readonly turnConfiguration: CodexRunFailure['turnConfiguration'] | null;
        readonly cleanup: CodexRunFailure['cleanup'] | null;
    } | null;
    readonly native?: NativeReceipt;
    readonly costUSD: null;
    readonly costStatus: 'unknown';
}
export declare class MachineInputError extends Error {
    readonly code = "INVALID_REQUEST";
    constructor(message: string);
}
/** Validate before starting any process; unknown options never silently disappear. */
export declare function parseMachineRequest(value: unknown): MachineRequest;
/** A machine run never invents an exit code, usage, effective effort, or dollar cost. */
export declare function runMachine(value: MachineRequest, options?: MachineOptions): Promise<MachineReceipt>;
export type { CodexRunOutcome } from './run.ts';
//# sourceMappingURL=machine.d.ts.map