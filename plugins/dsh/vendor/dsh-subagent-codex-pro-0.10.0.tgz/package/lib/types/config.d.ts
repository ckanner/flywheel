/** The real Host settings schema. Only native defaults are edited without remounting. */
import z from '@deepseek-ai/schemastery';
/** Exported as Config by the plugin, so DSH derives an editable live settings form. */
export declare const ConfigSchema: z<Schemastery.ObjectS<NoInfer<{
    providerName: z<string, string, "plain">;
    command: z<string, string, "plain">;
    model: z<string, string, "plain">;
    reasoningEffort: z<string, string, "plain">;
    modelSelection: z<boolean, boolean, "plain">;
    permissionMode: z<"read-only" | "workspace-write" | "never" | "approve-for-me" | "dangerously-bypass-approvals-and-sandbox", "read-only" | "workspace-write" | "never" | "approve-for-me" | "dangerously-bypass-approvals-and-sandbox", "plain">;
    env: z;
    presets: z;
    threadMode: z<"ephemeral" | "persistent" | "session", "ephemeral" | "persistent" | "session", "plain">;
    runTimeoutMs: z<number, number, "plain">;
    originator: z<string, string, "plain">;
    native: z<any, unknown, "volatile">;
}>>, Schemastery.ObjectT<NoInfer<{
    providerName: z<string, string, "plain">;
    command: z<string, string, "plain">;
    model: z<string, string, "plain">;
    reasoningEffort: z<string, string, "plain">;
    modelSelection: z<boolean, boolean, "plain">;
    permissionMode: z<"read-only" | "workspace-write" | "never" | "approve-for-me" | "dangerously-bypass-approvals-and-sandbox", "read-only" | "workspace-write" | "never" | "approve-for-me" | "dangerously-bypass-approvals-and-sandbox", "plain">;
    env: z;
    presets: z;
    threadMode: z<"ephemeral" | "persistent" | "session", "ephemeral" | "persistent" | "session", "plain">;
    runTimeoutMs: z<number, number, "plain">;
    originator: z<string, string, "plain">;
    native: z<any, unknown, "volatile">;
}>>, "plain">;
//# sourceMappingURL=config.d.ts.map