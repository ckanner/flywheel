/**
 * One-shot Codex child lifecycle over the real app-server.
 *
 * The run has one deadline from before startup through the terminal turn. Every
 * startup RPC (initialize, thread/start, thread/resume, thread/name/set) and the
 * turn use the same derived abort signal, so a server that stops answering
 * cannot keep a delegation alive past its budget. Cleanup is a separate, finite
 * grace: the deadline ends work, the grace ends the process range.
 *
 * The child is spawned as the leader of its own POSIX process group. Termination
 * targets the group and then proves it is gone; a descendant that ignores
 * SIGTERM or outlives its parent is reported instead of being silently assumed
 * dead.
 *
 * @module dsh-subagent-codex-pro/run
 */
import { type NativeRequest, type NativeReceipt, type NativeEvent } from './native.ts';
import { type JsonRpcMessage } from './jsonrpc.ts';
import { type AppliedConfiguration, type CodexPermissionMode, type CodexRateLimitsReport, type CodexStopReason, type TurnConfiguration } from './wire.ts';
import type { CodexImage, CodexThreadMode } from './wire.ts';
import type { CodexUsageReport } from './usage.ts';
/** The task text blocks a run accepts. */
export type PromptBlocks = readonly {
    readonly type: string;
    readonly text?: string;
}[];
/** What happened to the process range at cleanup. */
export interface CleanupReport {
    /** Whether the whole owned process group is confirmed gone. */
    readonly confirmed: boolean;
    /** Why confirmation was impossible, when it was. */
    readonly detail?: string;
}
/** Physical facts about one attempt, separate from the model's terminal turn. */
export interface CodexRunExecution {
    readonly runId: string;
    readonly dispatch: 'not-dispatched' | 'possible' | 'accepted';
    readonly startedAt: string;
    readonly finishedAt: string;
    readonly durationMs: number;
    readonly threadId: string | null;
    readonly turnId: string | null;
    readonly pid: number | null;
    readonly supervisorPid: number | null;
    readonly exitCode: number | null;
    readonly signal: NodeJS.Signals | null;
    readonly supervisorExitCode: number | null;
    readonly supervisorSignal: NodeJS.Signals | null;
    readonly terminationRequested: boolean;
    readonly timedOut: boolean;
    readonly cancelled: boolean;
    readonly truncated: boolean;
    readonly spawnError: string | null;
    readonly failure: FailureFacts | null;
    readonly ownership: 'supervised-group' | 'owned-process';
}
/** Everything one run needs that does not change between attempts. */
export interface CodexRunSpec {
    /** Internal machine correlation selected before the supervised run starts. */
    readonly runId?: string;
    readonly native?: NativeRequest;
    readonly onNativeEvent?: ((event: NativeEvent) => void) | undefined;
    /** The delegating session's working directory. */
    readonly cwd: string;
    /** The Codex executable. */
    readonly command: string;
    /** Unattended permission policy. */
    readonly permissionMode: CodexPermissionMode;
    /** Model requested for this run, when one was chosen. */
    readonly model?: string | undefined;
    /**
     * Per-turn thinking level.
     *
     * Codex carries a thinking level on `turn/start`, not on `thread/start`; the
     * latter is not part of the 0.165/0.166 start parameters. `effort` wins when
     * both are supplied.
     */
    readonly effort?: string | undefined;
    /** Backwards-compatible alias for `effort`; never sent as a thread default. */
    readonly reasoningEffort?: string | undefined;
    /** How long the thread lives. Defaults to `ephemeral`. */
    readonly threadMode?: CodexThreadMode | undefined;
    /**
     * Continue this thread instead of creating one.
     *
     * A thread is resumable only once it has carried a turn, so the caller owns
     * remembering an id it was given earlier.
     */
    readonly resumeThreadId?: string | undefined;
    /** What the app-server records as the thread's originator. */
    readonly originator?: string | undefined;
    /**
     * Deadline for the whole delegation in milliseconds.
     *
     * `0` disables it. Defaults to {@link DEFAULT_RUN_TIMEOUT_MS}.
     */
    readonly runTimeoutMs?: number | undefined;
    /**
     * Absolute deadline shared by an auto-resume retry.
     *
     * Internal: the caller computes this once and passes it to both attempts, so
     * creating a new thread after a failed resume cannot borrow a fresh timeout.
     */
    readonly deadlineAt?: number | undefined;
    /**
     * Absolute paths of images to put in front of Codex with the task.
     *
     * The app-server takes these as `localImage` blocks, so the picture reaches the
     * model as a picture and no bytes travel through the protocol.
     */
    readonly images?: readonly string[] | undefined;
    /**
     * A JSON Schema for the final answer.
     *
     * The app-server enforces it, so the answer arrives as JSON that conforms
     * instead of prose a caller has to parse and hope about. Sent on the turn.
     */
    readonly outputSchema?: Record<string, unknown> | undefined;
    /**
     * A name for a persistent thread, shown in the Codex application's thread list.
     *
     * Ignored for `ephemeral`: a thread that leaves nothing behind has no list to
     * appear in.
     */
    readonly threadName?: string | undefined;
    /** Extra environment entries. */
    readonly env?: Readonly<Record<string, string>> | undefined;
    /** Grace between termination tiers. */
    readonly disposeGraceMs?: number | undefined;
    /** Maximum stdout/stderr bytes before a non-successful, truncated result. */
    readonly maxOutputBytes?: number | undefined;
    /** Narrates notable child activity, for a caller that reports progress. */
    readonly onProgress?: ((text: string) => void) | undefined;
    /** Awaitable structured persistence barriers, independent from progress text. */
    readonly onLifecycle?: ((event: CodexRunLifecycle) => Promise<void> | void) | undefined;
}
export interface CodexRunLifecycle {
    readonly event: 'thread-ready' | 'dispatch-intent' | 'dispatch-possible' | 'turn-accepted';
    readonly runId: string;
    readonly threadId: string | null;
    readonly turnId: string | null;
    readonly configuration: AppliedConfiguration | null;
}
/** What one finished run reports. */
export interface CodexRunOutcome {
    readonly native?: NativeReceipt;
    readonly output: readonly {
        readonly type: 'text';
        readonly text: string;
    }[];
    readonly stopReason: CodexStopReason;
    readonly diagnostic?: string;
    /**
     * Bounded, package-generated approval/sandbox note, safe for Host diagnostics.
     * Raw server messages and task text are never copied here.
     */
    readonly approvalDiagnostic?: string;
    /**
     * The thread this run used.
     *
     * Reported for every outcome, including a failed one: a persistent thread that
     * half-ran is still a thread the user may want to open or clean up, and it is
     * the only handle `resumeThreadId` accepts.
     */
    readonly threadId?: string | undefined;
    /**
     * Images the run produced.
     *
     * Reported even on a failed run: a screenshot taken before the failure is
     * still a screenshot the user asked for.
     */
    readonly images?: readonly CodexImage[] | undefined;
    /** Token usage attributable to this run; `unknown` rather than zero when absent. */
    readonly usage: CodexUsageReport;
    /** Account rate limits, deliberately separate from token usage. */
    readonly rateLimits: CodexRateLimitsReport;
    /** Requested vs effective model/cwd/permission facts, when startup got that far. */
    readonly configuration?: AppliedConfiguration | undefined;
    /** Whether the process range is confirmed gone. */
    readonly cleanup: CleanupReport;
    readonly execution: CodexRunExecution;
    /** A turn request is evidence of acceptance, not a server effort echo. */
    readonly turnConfiguration?: TurnConfiguration | undefined;
    /** Parsed structured result, only when a schema was supplied and verification passed. */
    readonly structured?: unknown;
    /** Why structured verification failed, when it did. */
    readonly schemaError?: string;
}
/** The published run. */
export interface StartedCodexRun {
    /** A durable id for the harness's catalog. */
    readonly id: string;
    /** Never rejects: a failure arrives as a stop reason plus a diagnostic. */
    readonly result: Promise<CodexRunOutcome>;
    /** Ask the child to stop; local settlement stays authoritative. */
    requestCancel(): void;
    /** Release the process range. Idempotent, and awaited by the caller. */
    teardown(): Promise<CleanupReport>;
}
/**
 * How long one delegation may take before it is cancelled.
 *
 * A delegation that hangs is invisible: the job stays `running`, nothing is
 * logged, and the session waits. The deadline turns that into a failure with a
 * reason. Ten minutes is generous against a package whose own README says a
 * delegation takes "a minute or more", and `0` disables it.
 */
export declare const DEFAULT_RUN_TIMEOUT_MS = 600000;
/** The failure taxonomy carried out of a run. */
export interface FailureFacts {
    readonly stage: string;
    readonly category: string;
    readonly httpStatus?: number;
}
/** A run failure, kept for its structured facts and any cleanup it observed. */
export declare class CodexRunFailure extends Error {
    readonly facts: FailureFacts;
    readonly native: NativeReceipt | undefined;
    readonly cleanup: CleanupReport | undefined;
    readonly execution: CodexRunExecution | undefined;
    readonly configuration: AppliedConfiguration | undefined;
    readonly usage: CodexUsageReport | undefined;
    readonly rateLimits: CodexRateLimitsReport | undefined;
    readonly turnConfiguration: TurnConfiguration | undefined;
    constructor(facts: FailureFacts, cause?: unknown, cleanup?: CleanupReport, observations?: {
        native?: NativeReceipt | undefined;
        execution?: CodexRunExecution;
        configuration?: AppliedConfiguration | undefined;
        usage?: CodexUsageReport;
        rateLimits?: CodexRateLimitsReport;
        turnConfiguration?: TurnConfiguration | undefined;
    });
}
/** The diagnostic for a delegation the deadline stopped. */
export declare function describeTimeout(timeoutMs: number): string;
/**
 * Validate and preserve the one-shot task before crossing the process boundary.
 *
 * @param prompt - the delegation's content blocks.
 * @returns the exact non-empty text block sequence.
 */
export declare function textTask(prompt: PromptBlocks): string[];
/** Build the argv, for diagnostics and tests. */
export declare function codexAppServerArgv(command: string): string[];
/**
 * Start the app-server child and publish its one-shot run.
 *
 * Resolves only after initialization and thread creation/resume, so a failure
 * before that point rejects with no run published. After publication the result
 * never rejects; even a failed run carries its observed usage, images, thread,
 * configuration, and cleanup report.
 *
 * @param prompt - the delegation's content blocks.
 * @param spec - working directory, executable, permission mode, and choices.
 * @param signal - caller cancellation.
 * @returns the published run.
 */
export declare function startCodexRun(prompt: PromptBlocks, spec: CodexRunSpec, signal: AbortSignal): Promise<StartedCodexRun>;
/** The message shapes the wire exchanges, re-exported for diagnostics. */
export type { JsonRpcMessage };
/** Which thread a call should continue, if any. */
export interface ThreadChoice {
    /** The thread to continue, or `undefined` to start a fresh one. */
    readonly reuse: string | undefined;
    /**
     * The remembered thread this call wanted but found busy.
     *
     * Reported rather than dropped: the call still runs, in its own thread, and a
     * log line is the only way to know the session's thread was skipped.
     */
    readonly skippedBusy: string | undefined;
}
/**
 * Decide which thread one call continues.
 *
 * `session` mode has one thread per Agent session, but a thread carries one turn
 * at a time: two delegations sent together would otherwise both reach for it and
 * the second would fail. A remembered thread that another delegation is already
 * using is therefore skipped, and this call gets a thread of its own — which is
 * what `persistent` does anyway, so parallel work degrades to the mode that
 * supports it instead of failing and retrying.
 *
 * An id the caller passed explicitly is never skipped: continuing *that* thread
 * was the request, and silently running somewhere else would answer a different
 * question.
 *
 * @param input - the call's explicit id, the configured mode, the session's
 * remembered thread, and the threads currently in flight.
 * @returns the thread to continue and the remembered one that was busy.
 */
export declare function chooseThread(input: {
    readonly explicit: string | undefined;
    readonly configured: 'ephemeral' | 'persistent' | 'session';
    readonly remembered: string | undefined;
    readonly inFlight: ReadonlySet<string>;
}): ThreadChoice;
/**
 * A delegation that did not complete.
 *
 * Carries the thread, images, and (when publication reached the run) the whole
 * outcome, so a caller can report observed usage even though the run failed.
 */
export declare class CodexDelegationFailure extends Error {
    /** The thread the failed run used, when the app-server had got that far. */
    readonly threadId: string | undefined;
    /** Images the failed run produced before it failed. */
    readonly images: readonly CodexImage[];
    /** Everything observed about the failed run, when one was published. */
    readonly outcome: CodexRunOutcome | undefined;
    constructor(message: string, threadId: string | undefined, images?: readonly CodexImage[], outcome?: CodexRunOutcome);
}
/** The successful result of `delegateOnce`, with the observability fields intact. */
export interface DelegatedCodexRun {
    readonly native?: NativeReceipt;
    readonly text: string;
    readonly threadId: string | undefined;
    readonly images: readonly CodexImage[];
    readonly usage: CodexUsageReport;
    readonly rateLimits: CodexRateLimitsReport;
    readonly configuration?: AppliedConfiguration;
    readonly cleanup: CleanupReport;
    readonly execution: CodexRunExecution;
    readonly turnConfiguration?: TurnConfiguration;
    readonly structured?: unknown;
}
/** Run one delegation and return its settled outcome. */
export declare function runCodexOnce(options: {
    readonly prompt: string;
    readonly native?: NativeRequest | undefined;
    readonly onNativeEvent?: ((event: NativeEvent) => void) | undefined;
    readonly cwd: string;
    readonly command: string;
    readonly permissionMode: CodexPermissionMode;
    readonly model?: string | undefined;
    readonly reasoningEffort?: string | undefined;
    readonly threadMode?: CodexThreadMode | undefined;
    readonly threadId?: string | undefined;
    readonly originator?: string | undefined;
    readonly threadName?: string | undefined;
    readonly runTimeoutMs?: number | undefined;
    /** Absolute deadline shared with an auto-resume retry. */
    readonly deadlineAt?: number | undefined;
    readonly images?: readonly string[] | undefined;
    readonly outputSchema?: Record<string, unknown> | undefined;
    readonly env?: Readonly<Record<string, string>> | undefined;
    readonly disposeGraceMs?: number | undefined;
    readonly maxOutputBytes?: number | undefined;
    readonly signal: AbortSignal;
    readonly onStart?: ((id: string) => void) | undefined;
    readonly onProgress?: ((text: string) => void) | undefined;
}): Promise<CodexRunOutcome>;
/**
 * Run one delegation to completion and return its final text.
 *
 * The result keeps the thread, images, usage, configuration and cleanup report
 * available to callers that need to report more than the answer. A run that
 * does not complete rejects with the whole outcome attached.
 *
 * @param options - the task, its working directory, and the choices.
 * @returns the child's final message and its observability fields.
 * @throws `CodexDelegationFailure` when the run does not complete.
 */
export declare function delegateOnce(options: {
    readonly native?: NativeRequest | undefined;
    readonly onNativeEvent?: ((event: NativeEvent) => void) | undefined;
    readonly prompt: string;
    readonly cwd: string;
    readonly command: string;
    readonly permissionMode: CodexPermissionMode;
    readonly model?: string | undefined;
    readonly reasoningEffort?: string | undefined;
    /** How long the thread lives. Defaults to `ephemeral`. */
    readonly threadMode?: CodexThreadMode | undefined;
    /** Continue this thread instead of creating one. */
    readonly threadId?: string | undefined;
    /** What the app-server records as the thread's originator. */
    readonly originator?: string | undefined;
    /** A name for a persistent thread, shown in the Codex application. */
    readonly threadName?: string | undefined;
    /** Deadline for the whole delegation in milliseconds; `0` disables it. */
    readonly runTimeoutMs?: number | undefined;
    /** Absolute deadline shared with an auto-resume retry. */
    readonly deadlineAt?: number | undefined;
    /** Absolute paths of images to show Codex alongside the task. */
    readonly images?: readonly string[] | undefined;
    /** A JSON Schema the final answer must conform to. */
    readonly outputSchema?: Record<string, unknown> | undefined;
    readonly env?: Readonly<Record<string, string>> | undefined;
    readonly disposeGraceMs?: number | undefined;
    readonly maxOutputBytes?: number | undefined;
    readonly signal: AbortSignal;
    /** Called once the run is published, for diagnostics. */
    readonly onStart?: (id: string) => void;
    /** Narrates notable child activity. */
    readonly onProgress?: ((text: string) => void) | undefined;
}): Promise<DelegatedCodexRun>;
//# sourceMappingURL=run.d.ts.map