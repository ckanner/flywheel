/**
 * Token usage observed over one delegation.
 *
 * Codex reports a thread-cumulative snapshot (`total`) and a last-model-call
 * snapshot (`last`) through `thread/tokenUsage/updated`. A delegation can make
 * several model calls, so `last` is never a delegation total, and `total` is an
 * absolute high-water mark rather than an increment. Resume/attach replays the
 * latest persisted snapshot for the new connection, so the first observation
 * after a resume is history, not this run.
 *
 * The tracker therefore:
 * - uses a baseline and computes a delta from later cumulative snapshots;
 * - treats a replay after resume as the baseline;
 * - ignores duplicate and out-of-order snapshots;
 * - never derives a value by adding snapshots;
 * - reports `unknown` rather than zero when no usable observation exists;
 * - retains the last observed totals even when the run failed or was cancelled.
 *
 * `cachedInputTokens` is a subset of `inputTokens`, and
 * `reasoningOutputTokens` is a subset of `outputTokens`. The fields are reported
 * as Codex states them; they are never summed into a larger total.
 *
 * @module dsh-subagent-codex-pro/usage
 */
/** One token-usage breakdown exactly as Codex reports it. */
export interface TokenUsageBreakdown {
    readonly totalTokens: number;
    readonly inputTokens: number;
    /** Cached input, already included in `inputTokens`. */
    readonly cachedInputTokens: number;
    /** Cache writes, already included in `inputTokens`. */
    readonly cacheWriteInputTokens: number;
    readonly outputTokens: number;
    /** Reasoning output, already included in `outputTokens`. */
    readonly reasoningOutputTokens: number;
}
/** Whether a usage report covers the whole delegation, part of it, or nothing. */
export type UsageStatus = 'complete' | 'partial' | 'unknown';
/**
 * Usage attributable to one delegation.
 *
 * `run` is the delta from the observed baseline, not a sum of notifications.
 * `threadTotal` is the latest absolute thread snapshot, kept for diagnostics.
 * A report with `status: 'unknown'` deliberately has no `run`; it is not zero.
 */
export interface CodexUsageReport {
    readonly status: UsageStatus;
    /** The usage of this run, when a baseline and at least one later snapshot exist. */
    readonly run?: TokenUsageBreakdown;
    /** The latest thread-cumulative snapshot observed, including pre-run history. */
    readonly threadTotal?: TokenUsageBreakdown;
    /** Thread model context window when Codex reported it. */
    readonly modelContextWindow?: number | null;
    /** Usable usage notifications observed for this thread. */
    readonly observations: number;
    /** Whether a resumed thread's baseline came from a replay notification. */
    readonly replayedBaseline: boolean;
    /** Why the report is partial or unknown. */
    readonly reason?: string;
}
/** The shape of `thread/tokenUsage/updated` the wire accepts. */
export interface TokenUsageNotificationLike {
    readonly threadId?: unknown;
    readonly turnId?: unknown;
    readonly tokenUsage?: unknown;
}
/** One notification accepted by the tracker. */
export interface UsageObservation {
    readonly turnId: string;
    readonly tokenUsage: unknown;
    readonly modelContextWindow?: unknown;
}
/**
 * Fold the usage notifications of one thread into one delegation report.
 *
 * One tracker belongs to one wire/thread. `resetForNewThread` is called after a
 * successful `thread/start`; `resetForResume` after a successful
 * `thread/resume`; `beginTurn` when the turn id becomes authoritative. The
 * tracker is deliberately not a Codex client: it only accounts for snapshots,
 * never issues requests.
 */
export declare class TokenUsageTracker {
    #private;
    /** Start accounting for a thread that has no history. */
    resetForNewThread(threadId: string): void;
    /**
     * Start accounting for a resumed thread.
     *
     * Its first usage notification is normally the connection-scoped replay of
     * the last persisted snapshot, so it becomes the baseline and contributes no
     * run usage. If no replay arrives before the turn starts, the first live
     * snapshot is still used as a baseline but the report is `partial`, because
     * usage before that snapshot is unknowable from the protocol.
     */
    resetForResume(threadId: string): void;
    /**
     * Mark the turn/start request boundary.
     *
     * Notifications are buffered until the response proves the authoritative turn
     * id; that keeps a resumed thread's replay and a current-turn live snapshot
     * distinguishable even when the replay arrives after this request.
     */
    startTurnRequest(): void;
    /** Associate early notifications after the response proves the turn id. */
    beginTurn(turnId: string): void;
    /** The current turn id, when the wire has adopted it. */
    get turnId(): string | undefined;
    /** The latest absolute thread total, if any observation was accepted. */
    get latest(): TokenUsageBreakdown | undefined;
    /** The latest model context window, if Codex reported one. */
    get modelContextWindow(): number | null | undefined;
    /** Begin a report's closing fold; further observations are ignored. */
    close(): void;
    /**
     * Fold one `thread/tokenUsage/updated` notification.
     *
     * @param notification - the decoded notification parameters.
     * @returns whether the notification was usable for accounting.
     */
    observe(notification: TokenUsageNotificationLike): boolean;
    /** Record a malformed notification so the report can say so. */
    observeInvalid(): void;
    /**
     * The report for this run.
     *
     * No observation is `unknown`, never a zero report. A known baseline plus a
     * later snapshot is `complete` unless a reset/partial reason was recorded.
     */
    report(): CodexUsageReport;
}
//# sourceMappingURL=usage.d.ts.map