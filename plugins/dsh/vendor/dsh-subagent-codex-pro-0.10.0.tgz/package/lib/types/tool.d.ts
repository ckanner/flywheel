/**
 * The model-facing delegation tool.
 *
 * `@deepseek-ai/dsh-tool-subagent` cannot give an external provider the model
 * surface: a row may only carry `modelSelectionSettings: true` when the provider
 * declares `agentOptions`, and enabling it on the Codex row inside a preset
 * makes that row disappear — silently, with no tool and no error. The control
 * row in those experiments (same provider, same row, flag off) did register, so
 * the provider and the row shape are both fine.
 *
 * So this plugin registers the tool itself, the way the LCU plugin registers
 * `js`: on `agent/created`, into that agent's own context. `model` and
 * `reasoning_effort` appear while this plugin's modelSelection setting is
 * enabled; that setting is independent of the Host LLM route picker.
 *
 * @module dsh-subagent-codex-pro/tool
 */
import type { ToolDefinitionLike } from './dsh-types.ts';
import type { CodexPermissionMode } from './wire.ts';
import { type DesktopNative } from './desktop-native.ts';
import { type NativeRequest, type NativeReceipt } from './native.ts';
/** One call's choices, already resolved against the configured defaults. */
export interface CodexCall {
    readonly native?: DesktopNative;
    /** Set only by the dedicated review tool; normal delegation rejects native.review. */
    readonly review?: NativeRequest['review'];
    readonly label: string;
    readonly prompt: string;
    readonly model?: string;
    readonly reasoningEffort?: string;
    /** Per-call permission mode override, when the caller chose one. */
    readonly permissionMode?: CodexPermissionMode;
    /** How long this delegation's thread lives, when the call chose. */
    readonly threadMode?: 'ephemeral' | 'persistent';
    /** Continue this thread instead of creating one. */
    readonly threadId?: string;
    /** Working directory for the delegation, when the call named one. */
    readonly cwd?: string;
    /** Absolute paths of images to show Codex alongside the task. */
    readonly images?: readonly string[];
    /** A JSON Schema the final answer must conform to. */
    readonly outputSchema?: Record<string, unknown>;
    /** Deadline for this call in milliseconds; `0` means no deadline. */
    readonly timeoutMs?: number;
}
/** Everything the tool needs that does not change per call. */
export interface CodexToolOptions {
    /** The delegating Agent's working directory. */
    readonly cwd: string;
    /** Default model when a call does not name one. */
    readonly model?: string;
    /** Default reasoning effort when a call does not name one. */
    readonly reasoningEffort?: string;
    /** Configured permission policy; limits the per-call enum to safe choices. */
    readonly permissionMode?: CodexPermissionMode;
    /**
     * Whether the plugin permits Agent-chosen Codex models.
     *
     * When false the tool exposes no `model` or `reasoning_effort`, exactly as the
     * harness's own delegation tools behave — the user's authorization is the only
     * thing that makes those fields exist.
     */
    readonly modelSelectionEnabled: boolean;
    /** Whether the jobs service is present, which is what makes background runs possible. */
    readonly backgroundEnabled: boolean;
    /** The plugin's configured thread mode, named in the tool description. */
    readonly defaultThreadMode: 'ephemeral' | 'persistent' | 'session';
    /** Whether a call may override the thread mode and resume a thread. */
    readonly threadControlEnabled: boolean;
    /** Run one delegation and return its final text and the thread it used. */
    readonly run: (request: CodexCall & {
        readonly signal: AbortSignal;
    }) => Promise<{
        readonly text: string;
        readonly threadId: string | undefined;
        readonly native?: NativeReceipt;
        /**
         * Content blocks to hand the model, when the run produced more than text.
         *
         * A foreground delegation returns these so a screenshot the run took reaches
         * the model as an image. A background job's result is a string by contract,
         * so its images are reported by host path in the text instead.
         */
        readonly blocks?: readonly {
            readonly type: string;
        }[] | undefined;
    }>;
    /**
     * Start one delegation as a background job.
     *
     * @param request - the call's label and resolved choices.
     * @returns the job id the model collects with `job_output`.
     */
    readonly startBackground: (request: CodexCall) => string;
}
/**
 * Permission modes a per-call override may select without changing the
 * configured policy upward.
 *
 * The tool description and schema should not advertise a choice that the
 * runtime's narrowing guard will reject. When no policy is supplied (direct
 * tests or older callers), all modes remain visible for compatibility.
 */
export declare function allowedPermissionModes(configured: CodexPermissionMode | undefined): readonly CodexPermissionMode[];
/**
 * Build the delegation tool definition.
 *
 * @param options - the delegating Agent's fixed choices, its runner, and its
 * background starter.
 * @returns a definition ready for `agent.ctx.tools.register`.
 */
export declare function createCodexTool(options: CodexToolOptions): ToolDefinitionLike;
/**
 * A fresh read-only review/start operation. Target is explicit; prompt, images,
 * output_schema, thread_id and native defaults cannot change or be ignored by it.
 */
export declare function createCodexReviewTool(options: CodexToolOptions): ToolDefinitionLike;
//# sourceMappingURL=tool.d.ts.map