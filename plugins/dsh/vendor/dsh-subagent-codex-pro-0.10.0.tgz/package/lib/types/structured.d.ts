/**
 * Structured-output verification.
 *
 * Codex enforces the schema it was given, but a completed turn is not proof that
 * the answer the host received is valid JSON or that it still matches the
 * schema: the app-server can be replaced, a stub can answer, and a later change
 * to the wire can hand the caller prose. Treating an unparseable answer as
 * "structured output absent" would report exactly the success the caller asked
 * to avoid, so this module fails closed and returns the reason.
 *
 * The validator deliberately covers the JSON Schema subset this plugin accepts
 * for `output_schema` (object-rooted schemas using the common assertion
 * keywords). A schema using a keyword outside that subset is reported as an
 * error rather than silently accepted; the plugin never claims a validation it
 * did not perform.
 *
 * @module dsh-subagent-codex-pro/structured
 */
/** The verification result for one schema-constrained answer. */
export type StructuredVerification = {
    readonly ok: true;
    readonly value: unknown;
} | {
    readonly ok: false;
    readonly error: string;
};
/**
 * Parse and validate one schema-constrained final answer.
 *
 * @param text - the final answer text, exactly as Codex returned it.
 * @param schema - the object-rooted schema the answer was asked to conform to.
 * @returns the decoded value, or the reason verification failed.
 */
export declare function verifyStructuredOutput(text: string, schema: unknown): StructuredVerification;
//# sourceMappingURL=structured.d.ts.map