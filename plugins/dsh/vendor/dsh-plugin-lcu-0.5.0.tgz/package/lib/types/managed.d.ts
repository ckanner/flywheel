import type { Agent } from '@deepseek-ai/dsh-agent';
import type { Context } from '@deepseek-ai/cordis';
import { type LcuTurnEndEvent } from './connection.ts';
import { CUA_TOOL_NAME } from './ptc.ts';
/** Identity supplied by the trusted scheduler; it is never read from model arguments. */
export interface ManagedLcuIdentity {
    readonly runId: string;
    readonly invocationId: string;
    readonly rootSessionId: string;
    readonly candidateId?: string;
}
/** A reference to an existing host lease, not a grant of GUI permission. */
export interface ManagedLcuLease {
    readonly leaseId: string;
    readonly resourceId: string;
    readonly leaseEpoch: string;
    readonly ownerInvocationId: string;
}
export interface ManagedLcuConfig {
    readonly app?: string;
    readonly command?: string;
    readonly chrome?: boolean;
    readonly audio?: boolean;
    readonly allowedApps?: string[];
    readonly allowedOrigins?: string[];
}
export interface ManagedLcuAdmission {
    readonly identity: ManagedLcuIdentity;
    readonly lease: ManagedLcuLease;
    readonly agentSessionId: string;
    readonly runtimeEpoch: string;
    readonly phase: 'attach' | 'call' | 'approval';
    readonly turnId?: string;
    readonly callId?: string;
    readonly method?: string;
}
export interface ManagedLcuEvent {
    readonly schemaVersion: 1;
    readonly sequence: number;
    readonly type: 'attached' | 'turn.started' | 'call.started' | 'call.completed' | 'call.failed' | 'approval' | 'media' | 'turn.stopped' | 'cleanup';
    readonly identity: ManagedLcuIdentity;
    readonly lease: ManagedLcuLease;
    readonly agentSessionId: string;
    readonly runtimeEpoch: string;
    readonly turnId?: string;
    readonly callId?: string;
    readonly facts: Readonly<Record<string, unknown>>;
}
export interface ManagedLcuSnapshot {
    readonly schemaVersion: 1;
    readonly identity: ManagedLcuIdentity;
    readonly lease: ManagedLcuLease;
    readonly agentSessionId: string;
    readonly runtimeEpoch: string;
    readonly state: 'ready' | 'active' | 'stopping' | 'blocked' | 'closed';
    readonly toolName: typeof CUA_TOOL_NAME;
    readonly valueContract: 'canonical-json-with-deferred-images';
    readonly cleanup: 'not-requested' | 'confirmed' | 'unknown';
    readonly turnCleanupConfirmed: boolean;
    readonly runtimeExitConfirmed: boolean;
    readonly turnId?: string;
    readonly errors: readonly string[];
}
export interface ManagedLcuOptions {
    readonly agent: Agent;
    readonly identity: ManagedLcuIdentity;
    readonly lease: ManagedLcuLease;
    readonly config?: ManagedLcuConfig;
    /** Verify a current scheduler grant and this actor's lineage; rejection blocks dispatch. */
    readonly verifyLease: (admission: ManagedLcuAdmission) => Promise<void>;
    /** Awaited durability/observation callback. Throwing blocks new operations. */
    readonly onEvent: (event: ManagedLcuEvent) => Promise<void>;
}
export interface ManagedLcuHandle {
    snapshot(): ManagedLcuSnapshot;
    beginTurn(turnId: string): Promise<void>;
    stopTurn(reason?: LcuTurnEndEvent): Promise<ManagedLcuSnapshot>;
    close(reason?: LcuTurnEndEvent): Promise<ManagedLcuSnapshot>;
}
/** The exception retains a cleanup receipt even when attachment never returns a handle. */
export declare class ManagedLcuError extends Error {
    readonly receipt?: ManagedLcuSnapshot;
    constructor(message: string, receipt?: ManagedLcuSnapshot, options?: ErrorOptions);
}
/**
 * Attach real CUA tools to a real SDK Agent without inventing a preset header.
 * Exact app/origin approvals and the original host guard remain authoritative.
 * A scheduler owns cross-process leases and must inspect every cleanup receipt.
 */
export declare function attachManagedLcu(ctx: Context, options: ManagedLcuOptions): Promise<ManagedLcuHandle>;
/** Install the supported Agent-created seam; the resolver owns root/child lineage. */
export declare function installManagedLcu(ctx: Context, resolve: (agent: Agent) => Promise<Omit<ManagedLcuOptions, 'agent'> | undefined>): {
    get(agent: Agent): ManagedLcuHandle | undefined;
    closeAll(): Promise<readonly ManagedLcuSnapshot[]>;
};
//# sourceMappingURL=managed.d.ts.map