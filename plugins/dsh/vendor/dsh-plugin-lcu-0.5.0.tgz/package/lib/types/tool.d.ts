/**
 * Model-facing tools for LCU.
 *
 * These builders predate the PTC surface and remain for the internal `js`
 * transport plus the tests that cover it. The model-facing registration in
 * `index.ts` now uses `ptc.ts`: PTC programs see `cua`, never `js`.
 *
 * @module dsh-plugin-lcu/tool
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ToolDefinition, ToolRunContext } from '@deepseek-ai/dsh-tools';
import type { LcuContentBlock, LcuTool } from './connection.ts';
import type { RuntimeConnection } from './session.ts';
interface ImageBlock {
    readonly type: 'image';
    readonly data: string;
    readonly mimeType: string;
}
interface PreparedProjection {
    readonly value: unknown;
    readonly content: readonly {
        readonly type: string;
        readonly [key: string]: unknown;
    }[];
}
/**
 * The model-facing text for one MCP result.
 *
 * LCU returns documentation and command output as text, and screenshots as
 * separate image blocks, so joining the text blocks is the whole projection;
 * images are appended by {@link prepareProjection}.
 *
 * @param content - the raw MCP content array.
 * @param toolName - the tool, for the empty-result diagnostic.
 * @returns text for the model, never empty.
 */
export declare function extractText(content: readonly LcuContentBlock[], toolName: string): string;
/**
 * Decode one image block, rejecting anything the store would not accept.
 *
 * @param block - a declared MCP image block.
 * @returns the decoded attachment payload.
 * @throws {Error} when the media type is not admitted or the base64 is not canonical.
 */
export declare function decodeImage(block: ImageBlock): {
    data: Buffer;
    mediaType: string;
};
/** Stable diagnostic text for an image the host could not admit. */
export declare function imageDiagnostic(block: unknown, reason: string): string;
/**
 * Build the ordered content blocks for one result: text and images interleaved
 * exactly as the server emitted them, with any inadmissible image replaced by a
 * diagnostic instead of failing the whole call.
 */
export declare function prepareProjection(ctx: Context, exec: ToolRunContext, content: readonly LcuContentBlock[], toolName: string): Promise<PreparedProjection['content']>;
/** Host-owned hooks around one call. */
export interface LcuToolOptions {
    /**
     * Awaited before every call, and its rejection fails the call.
     *
     * The runtime's per-turn cleanup is asynchronous: when it outlives the host's
     * wait, acting on the desktop before it finishes is unsafe. This is where the
     * host retries it and refuses the call if it still has not settled.
     */
    readonly beforeCall?: () => Promise<void>;
    /**
     * The Agent's active turn identity, so calls carry what the runtime keys its
     * approvals, per-turn Stop and cleanup by. A unique id per turn, never an
     * ordinal: the runtime treats a repeated id as the same, already-ended turn.
     */
    readonly currentTurn?: () => string | undefined;
}
/**
 * Tell the model where a stored screenshot actually is, and what it may do with it.
 *
 * Without this the model has an image it cannot place: the JavaScript sandbox
 * refuses every write (EPERM, even in the temporary directory), so a model asked
 * for a file probes the sandbox blindly — one recorded run spent six calls doing
 * that before copying an object straight out of the store's internal layout by
 * hash, which breaks the moment that layout changes.
 *
 * @param paths - host paths the attachment store resolved, in image order.
 * @returns the note, or `undefined` when no path resolved.
 */
export declare function storedImageNote(paths: readonly string[]): string | undefined;
/**
 * An actionable line for a permission failure, when the text looks like one.
 *
 * @param text - the server's error text.
 * @returns the hint, or `undefined` when the failure is something else.
 */
export declare function capturePermissionHint(text: string): string | undefined;
/**
 * An actionable line for a Stop the runtime cannot clear.
 *
 * @param text - the server's error text.
 * @returns the hint, or `undefined` when the failure is something else.
 */
export declare function stuckStopHint(text: string): string | undefined;
/**
 * Build one model-facing tool from a server descriptor.
 *
 * @param descriptor - the tool as `tools/list` reported it.
 * @param connection - the connection this agent's calls go through.
 * @param ctx - the plugin context, used for the attachment store.
 * @param options - host hooks around the call.
 * @returns a registrable tool definition.
 */
export declare function createLcuTool(descriptor: LcuTool, connection: RuntimeConnection, ctx: Context, options?: LcuToolOptions): ToolDefinition;
/**
 * Build the legacy native tools for one agent's connection.
 *
 * @param connection - the connected LCU session.
 * @param ctx - the plugin context.
 * @returns tool definitions for `js` and `js_reset`, in server order.
 * @throws {LcuError} when the server does not expose the model tools.
 */
export declare function buildLcuTools(connection: RuntimeConnection, ctx: Context, options?: LcuToolOptions): ToolDefinition[];
/**
 * The explicit per-app release, which LCU exposes to a host rather than to the
 * model.
 *
 * LCU's own adapters surface this as a user command (`/lcu stop`), because
 * releasing an app is a user's decision. In DSH the equivalent user action is
 * asking the agent, so this is the one tool this plugin adds on top of the
 * server's contract. Called without `app` it reports what is held.
 *
 * @param connection - the agent's connected runtime.
 * @param currentTurn - resolves the agent's active turn, or `undefined` outside one.
 * @returns a registrable tool definition.
 */
export declare function createComputerUseStopTool(connection: RuntimeConnection, currentTurn: () => string | undefined): ToolDefinition;
/**
 * Register the model-facing tools in one agent's scope.
 *
 * Registration is per agent rather than at plugin mount because the server owns
 * the schemas: they can only be fetched after connecting, and an agent only
 * needs the capability once it exists.
 *
 * @param agentCtx - the agent's own context; its registrations unwind on disposal.
 * @param connection - the agent's connected LCU session.
 * @param ctx - the plugin context.
 * @returns a disposer that unregisters every tool.
 */
export declare function registerLcuTools(agentCtx: Context, connection: RuntimeConnection, ctx: Context, options?: LcuToolOptions): () => void;
export {};
//# sourceMappingURL=tool.d.ts.map