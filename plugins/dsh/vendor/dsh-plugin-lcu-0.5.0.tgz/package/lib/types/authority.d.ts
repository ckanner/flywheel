/** Shared desktop and managed-runtime authorization. @module */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { LcuElicitationRequest, LcuElicitationResponse } from './connection.ts';
export interface ApprovalSettings {
    readonly allowedApps: ReadonlySet<string>;
    readonly allowedOrigins: ReadonlySet<string>;
    readonly managed?: boolean;
}
export declare function presentLcuApproval(ctx: Context, agent: Agent, settings: ApprovalSettings, request: LcuElicitationRequest, signal: AbortSignal): Promise<LcuElicitationResponse>;
//# sourceMappingURL=authority.d.ts.map