/**
 * Best-effort diagnostic log for the attach, launch and approval path.
 *
 * The harness exposes plugin logs only through surfaces a running session
 * cannot read, and a failing `agent/created` listener is swallowed silently. So
 * the attach decision writes here: one line per branch, including the errors
 * that would otherwise vanish. It never throws and never changes behavior.
 *
 * Set `LCU_DIAG=0` to disable. The file is `~/.dsh/lcu-diag.log`.
 *
 * @module dsh-plugin-lcu/diag
 */
/** Append one diagnostic line; silently does nothing if the file cannot be written. */
export declare function diag(message: string): void;
/** Describe a value for the log without dumping unbounded data. */
export declare function describe(value: unknown): string;
//# sourceMappingURL=diag.d.ts.map