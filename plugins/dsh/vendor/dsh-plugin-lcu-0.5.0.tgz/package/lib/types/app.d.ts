/**
 * The ChatGPT application, and the runtime it carries.
 *
 * The computer-use provider is the original one inside the application: this
 * module locates it, checks the pieces it needs are present and not writable by
 * anyone else, and builds the environment the runtime expects. Nothing here
 * launches a third-party wrapper — the launcher is
 * `.../@oai/cua-repl/bin/cua-repl.mjs` inside the application itself.
 *
 * The environment is not guesswork. Every variable below is one the original
 * launcher sets, and each is named in a comment for the thing it selects.
 *
 * @module dsh-plugin-lcu/app
 */
/**
 * The Sky service module this plugin loads instead of the application's own.
 *
 * It forwards to the application unchanged and adds the turn-ended hook the
 * runtime has no handler for. See its own header for why that hook matters and
 * what it deliberately leaves out.
 */
export declare function skyServicePath(): string;
/** A failure that names the application as its source. */
export declare class AppError extends Error {
    constructor(message: string);
}
/** The paths one intact application generation offers. */
export interface AppPaths {
    readonly app: string;
    readonly resources: string;
    readonly runtime: string;
    /** The application's `CFBundleShortVersionString`. */
    readonly version: string;
    /** The computer-use runtime generation recorded in its manifest. */
    readonly runtimeVersion: string;
}
/** Everything needed to start the provider. */
export interface LaunchPlan {
    readonly command: string;
    readonly args: readonly string[];
    readonly env: NodeJS.ProcessEnv;
    readonly paths: AppPaths;
}
/**
 * Refuse a file another account could replace.
 *
 * The runtime is executed from inside the application, so a world-writable file
 * in that tree is a way for someone else to choose what this session runs. This
 * is the cheap half of what the original installer checks; it is not a
 * signature verification.
 *
 * @param path - the file to inspect.
 * @returns whether the file is a regular file owned by this account or root and writable by neither others nor group.
 */
export declare function isPrivateFile(path: string): boolean;
/**
 * Locate the application and the runtime inside it.
 *
 * @param appPath - the application to use; defaults to the standard install.
 * @returns the paths and both versions.
 * @throws AppError when the application or a required piece is missing.
 */
export declare function resolveApp(appPath?: string): AppPaths;
/**
 * Build the environment the runtime expects.
 *
 * Every entry mirrors the original launcher. The ones that matter most:
 * `CUA_REPL_NODE_REPL_PATH`/`NODE_REPL_NODE_PATH` select the application's own
 * node, `NODE_REPL_NODE_MODULE_DIRS` and `NODE_REPL_TRUSTED_CODE_PATHS` let it
 * load its modules, `CUA_REPL_ENABLED_SURFACES` chooses the API surface,
 * `SKY_CUA_SERVICE_PATH` is the signed helper the macOS native pipe launches,
 * and `NODE_REPL_REQUEST_META` supplies the identity the runtime uses when a
 * call carries none of its own.
 *
 * `NODE_REPL_TRUSTED_SERVICES` selects the `sky` service. It names this plugin's
 * wrapper rather than the application's own module, because the runtime has no
 * turn-ended handler of its own and a turn that never ends is a turn whose
 * per-application Stop is never released.
 *
 * @param paths - the resolved application paths.
 * @param options - surface selection and the identity fallback.
 * @returns the child environment.
 */
export declare function buildEnvironment(paths: AppPaths, options: {
    readonly chrome: boolean;
    readonly audio: boolean;
    readonly identity?: string;
}): NodeJS.ProcessEnv;
/**
 * The full plan for one connection.
 *
 * @param options - the application, surfaces and override.
 * @returns the command, its arguments, the environment and the paths.
 */
export declare function planLaunch(options: {
    readonly appPath?: string;
    readonly chrome: boolean;
    readonly audio: boolean;
    readonly identity?: string;
    /** An explicit command that replaces the computed one, for an unusual install. */
    readonly command?: string;
}): LaunchPlan;
/**
 * A fingerprint of the application generation the runtime is run from.
 *
 * The runtime is executed from files the application replaces when it updates, so
 * a session that is already connected can end up running a mix of two
 * generations. Both versions are read from the bundle and both timestamps are
 * part of the answer, because an update replaces the whole bundle and a
 * same-version reinstall is still a different set of files.
 *
 * @param paths - the resolved application paths.
 * @returns a value that changes exactly when the files underneath change.
 */
export declare function generationOf(paths: AppPaths): string;
/** Whether the application can be executed by this account. */
export declare function appIsRunnable(paths: AppPaths): boolean;
//# sourceMappingURL=app.d.ts.map