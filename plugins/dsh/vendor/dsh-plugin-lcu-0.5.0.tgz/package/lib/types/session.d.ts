/**
 * The connection an Agent's tools talk to.
 *
 * The runtime is executed from files inside the ChatGPT application, and the
 * application replaces those files when it updates. A session that stays
 * connected across an update therefore runs a mix of two generations — the
 * runtime it started with and the modules a later `import` resolves from the new
 * bundle — and the failure that follows is not obvious from the outside.
 *
 * This is a thin facade rather than a fix inside the connection: the tools close
 * over one object for the life of the Agent, so that object has to be able to
 * become a different connection. Before every call it compares the application's
 * fingerprint, and when it changed it opens a new connection and retires the old
 * one, so all later calls come from a single generation.
 *
 * @module dsh-plugin-lcu/session
 */
import type { LcuConnection } from './connection.ts';
/**
 * What the tools need from a connection.
 *
 * Written as indexed access types rather than restated signatures, so a change to
 * the connection cannot leave this out of date.
 */
export interface RuntimeConnection {
    sessionId: string | undefined;
    readonly epoch?: string;
    prepare?(): Promise<void>;
    rotateEpoch?(): void;
    modelTools: LcuConnection['modelTools'];
    readonly hasHostControl: boolean;
    callTool: LcuConnection['callTool'];
    turnEnded: LcuConnection['turnEnded'];
    controlStatus: LcuConnection['controlStatus'];
    controlStop: LcuConnection['controlStop'];
    close: LcuConnection['close'];
}
/** How the session opens a connection, and how it notices the application moved. */
export interface ManagedSessionOptions {
    /** Managed invocations pin their admitted runtime; a change requires a new admission. */
    generationPolicy?: 'replace' | 'pin';
    /**
     * Open a fresh connection.
     *
     * @param reason - whether this is the first connection or a replacement.
     */
    connect: (reason: 'initial' | 'regenerated') => Promise<LcuConnection>;
    /**
     * The application's current fingerprint.
     *
     * Called before every call, so it must stay cheap: it reads two file
     * timestamps. It may throw, which is treated as "the application moved" and
     * lets the reconnect report the real error.
     */
    generation: () => string;
    /** Called after a successful replacement, for the diagnostic log. */
    onRegenerated?: (transition: {
        readonly from: string;
        readonly to: string;
    }) => void;
    /** Called when a replacement fails. The previous connection stays in use. */
    onRegenerateFailed?: (error: unknown) => void;
    /**
     * Called when the fingerprint cannot be read at all.
     *
     * A fingerprint that cannot be read is **not** evidence that anything changed,
     * and opening a second runtime because of a transient read failure is worse
     * than waiting: the next call checks again.
     */
    onGenerationUnreadable?: (error: unknown) => void;
}
/** A connection that follows the application across an update. */
export declare class ManagedSession implements RuntimeConnection {
    #private;
    private constructor();
    /**
     * Open the first connection.
     *
     * @param options - how to connect and how to notice a change.
     * @returns the session, already connected.
     */
    static open(options: ManagedSessionOptions): Promise<ManagedSession>;
    get epoch(): string;
    /** Invalidate live proxies after a successful explicit runtime reset. */
    rotateEpoch(): void;
    /** Resolve the actual generation before interpreting a handle. */
    prepare(): Promise<void>;
    get sessionId(): string | undefined;
    set sessionId(value: string | undefined);
    get hasHostControl(): boolean;
    modelTools(): ReturnType<LcuConnection['modelTools']>;
    callTool(...args: Parameters<LcuConnection['callTool']>): ReturnType<LcuConnection['callTool']>;
    turnEnded(...args: Parameters<LcuConnection['turnEnded']>): ReturnType<LcuConnection['turnEnded']>;
    controlStatus(...args: Parameters<LcuConnection['controlStatus']>): ReturnType<LcuConnection['controlStatus']>;
    controlStop(...args: Parameters<LcuConnection['controlStop']>): ReturnType<LcuConnection['controlStop']>;
    /** Retire the connection. Later calls fail rather than opening a new runtime. */
    close(): Promise<void>;
}
//# sourceMappingURL=session.d.ts.map