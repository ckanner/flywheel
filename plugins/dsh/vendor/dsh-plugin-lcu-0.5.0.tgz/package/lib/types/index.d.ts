/**
 * `dsh-plugin-lcu` — drive the desktop and Chrome from DeepSeek Harness.
 *
 * The plugin is one root-scoped row. It does not open anything at load time:
 * The runtime starts only for an Agent whose preset is
 * listed in `presets`, and stops when that Agent is disposed. That keeps a
 * heavy, permission-bearing capability off every session that does not need it.
 *
 * Visibility is decided per Agent rather than by mounting rows inside a preset,
 * because the server owns the tool schemas: they can only be fetched after the
 * handshake, so the tools are registered into the Agent's own context once its
 * connection is up.
 *
 * @module dsh-plugin-lcu
 */
import type { Context } from '@deepseek-ai/cordis';
import { resolveElicitation } from './connection.ts';
export declare const name = "lcu";
export declare const inject: string[];
/** Plugin configuration. */
export interface Config {
    /**
     * The ChatGPT application whose runtime provides computer use.
     *
     * Defaults to the standard installation. The plugin launches the runtime from
     * inside this application directly — it does not go through a wrapper.
     */
    app?: string;
    /**
     * An explicit executable replacing the computed launch, for an unusual install.
     *
     * Set this only when the application is somewhere the built-in resolution
     * cannot reach; it bypasses the runtime's own environment setup.
     */
    command?: string;
    /** Enable the runtime's browser surface; needs the official browser extension and site approvals. */
    chrome?: boolean;
    /** Enable the runtime's computer-audio recording API. */
    audio?: boolean;
    /**
     * Agent preset ids whose sessions get the tools.
     *
     * Presets are independent compositions, so this is an explicit list rather
     * than a capability the preset itself declares; the generator builds `daily`
     * and `heavy`, and both now use PTC.
     */
    presets?: string[];
    /** Exact HTTP(S) origins pre-approved for browser access, never widened. */
    allowedOrigins?: string[];
    /**
     * Bundle identifiers computer use may use without asking.
     *
     * The runtime asks before it first uses each application, and an unanswered
     * question is a refusal, so an unattended run needs its targets listed here.
     * The application hosting the agent can never be admitted this way.
     */
    allowedApps?: string[];
    /** Prompt section order for the injected runtime instructions. */
    sectionOrder?: number;
}
/**
 * Mount the computer-use capability.
 *
 * @param ctx - the host context this row mounts into.
 * @param config - the row's configuration.
 */
export declare function apply(ctx: Context, config: Config): void;
export { resolveElicitation };
//# sourceMappingURL=index.d.ts.map