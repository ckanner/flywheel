/**
 * The runtime MCP client.
 *
 * Why not `@modelcontextprotocol/sdk` or the host's `@modelcontextprotocol/client`:
 * the harness's own MCP bridge declares `capabilities: {}` and therefore cannot
 * answer elicitation, which is how the runtime asks for per-app approval; and pulling a
 * second SDK into a profile plugin would pin a version the host does not own.
 * MCP over stdio is newline-delimited JSON-RPC, so the wire is small enough to
 * own here and keeps this plugin dependency-free at runtime.
 *
 * Contract taken from the runtime:
 * - declare `capabilities.elicitation` and answer `elicitation/create`
 * - `js` and `js_reset` remain the host transport; the PTC surface wraps them
 *   and never exposes them to the model
 * - inject the server's `initialize.instructions` into model context
 * - fail closed: an elicitation with no handler, or any unknown shape, cancels
 * - approvals never time out; a pending approval freezes the call deadline
 *
 * @module dsh-plugin-lcu/connection
 */
/** One tool as the server describes it. */
export interface LcuTool {
    readonly name: string;
    readonly description: string;
    readonly inputSchema: Record<string, unknown>;
}
/** A single MCP content block, text or image. */
export type LcuContentBlock = {
    readonly type: 'text';
    readonly text: string;
} | {
    readonly type: 'image';
    readonly data: string;
    readonly mimeType: string;
} | {
    readonly type: string;
    readonly [key: string]: unknown;
};
/** The result of one `tools/call`. */
export interface LcuCallResult {
    readonly content: readonly LcuContentBlock[];
    readonly isError: boolean;
    readonly structuredContent?: unknown;
}
/** An `elicitation/create` request as the server sends it. */
export interface LcuElicitationRequest {
    readonly message?: string;
    readonly mode?: string;
    readonly requestedSchema?: unknown;
    readonly _meta?: Record<string, unknown>;
    readonly [key: string]: unknown;
}
/** What a host may answer. Anything else is normalized to `cancel`. */
export type LcuElicitationResponse = {
    readonly action: 'accept';
    readonly content?: Record<string, unknown>;
    readonly _meta?: Record<string, unknown>;
} | {
    readonly action: 'decline';
} | {
    readonly action: 'cancel';
};
/** Tools the model may see. Everything else is host-only. */
export declare const MODEL_TOOL_NAMES: readonly string[];
export declare const HOST_ONLY_TOOL_NAMES: readonly string[];
/**
 * Build the `_meta` the original runtime reads its session and turn from.
 *
 * Its approvals, per-turn Stop and cleanup are all keyed by these identities.
 * Omitting them makes every call look like the same turn, so a Stop the user
 * issued once, or a cleanup that never ran, then applies to every later turn on
 * the connection. A synthetic pair would be worse than none: the runtime would
 * key its state to a lie. Returns `undefined` unless both identities are real.
 *
 * @param sessionId - the host session, or `undefined` before binding.
 * @param turnId - the active turn, or `undefined` outside one.
 * @param callId - the host's tool-call id, when it has one.
 * @returns the metadata block, or `undefined` when it cannot be truthful.
 */
export declare function turnMetadataFor(sessionId: string | undefined, turnId: string | undefined, callId?: string): Record<string, unknown> | undefined;
/** Lifecycle events the server accepts for `turn_ended`. */
export type LcuTurnEndEvent = 'Stop' | 'Interrupt' | 'SubagentStop';
/** Connection options. */
export interface LcuConnectionOptions {
    /** Executable to spawn, together with its arguments and environment. */
    readonly command: string;
    /** Extra arguments, e.g. `['--chrome']` to enable the browser surface. */
    readonly args?: readonly string[];
    /**
     * The complete child environment.
     *
     * The runtime selects its own node, module roots and surfaces from these, so
     * a caller replaces rather than layers: the launcher computes the whole set.
     */
    readonly env?: NodeJS.ProcessEnv;
    /** Working directory for the child process. */
    readonly cwd?: string;
    /**
     * Answer one elicitation. Omit to fail closed: every approval then cancels,
     * which is what the runtime expects from a host that cannot present the request.
     */
    readonly onElicitation?: (request: LcuElicitationRequest, signal: AbortSignal) => Promise<LcuElicitationResponse>;
    /** Called whenever the server's tool list changes. */
    readonly onToolsChanged?: (tools: readonly LcuTool[]) => void;
    /** Receives child-process stderr lines; never model-visible. */
    readonly onStderr?: (line: string) => void;
    /** Receives control-channel decisions, for the diagnostic log. */
    readonly onDiag?: (message: string) => void;
}
/** Where a request is in its lifecycle, for a diagnostic that names the stage. */
export type LcuStage = 'spawn' | 'initialize' | 'tools/list' | 'tools/call' | 'turn_ended';
/**
 * Code for the turn-cleanup timeout: the original host stopped waiting for its
 * per-turn cleanup. The cleanup keeps running in the worker and the runtime
 * retries it before the next action, so this is a warning the caller should
 * surface rather than a reason to abort the session.
 */
export declare const TURN_CLEANUP_TIMEOUT_CODE = "LCU_TURN_CLEANUP_TIMEOUT";
/** A failure that names the protocol stage it happened at. */
export declare class LcuError extends Error {
    readonly stage: LcuStage;
    /** Stable machine-readable classification, when one applies. */
    readonly code?: string;
    constructor(stage: LcuStage, message: string, cause?: unknown, code?: string);
}
/**
 * Classify a failed `turn_ended` call.
 *
 * The runtime reports its own cleanup timeout as an ordinary error result with a
 * recognizable detail. Missing it would let a stalled cleanup look like a
 * healthy turn, which is exactly what the runtime's contract asks a host not to do.
 *
 * @param result - the failed call's result.
 * @returns the classified error, or `undefined` when the call succeeded.
 */
export declare function classifyTurnEndFailure(result: LcuCallResult): LcuError | undefined;
/**
 * Answer one elicitation, failing closed on every unexpected shape.
 *
 * The runtime requires this exact discipline: a host that cannot present the request,
 * a handler that throws, or an answer that is not one of the three actions must
 * all end as `cancel`, because anything else would silently grant desktop access.
 *
 * @param handler - the host's presenter, or `undefined` when there is none.
 * @param request - the server's elicitation params.
 * @param activeCalls - signals of in-flight tool calls; aborting one cancels.
 * @returns an answer the server accepts; never rejects.
 */
export declare function resolveElicitation(handler: LcuConnectionOptions['onElicitation'], request: LcuElicitationRequest, activeCalls?: ReadonlySet<AbortSignal>): Promise<LcuElicitationResponse>;
/**
 * One long-lived connection to the runtime's MCP server.
 *
 * The connection is per Agent/Session: the runtime carries a persistent JavaScript
 * session on its side, and its approvals are scoped to a real host session and
 * turn, so sharing one connection across agents would interleave both.
 */
export declare class LcuConnection {
    #private;
    constructor(options: LcuConnectionOptions);
    /** The server's `initialize.instructions`, injected into model context. */
    get instructions(): string;
    /** The host session this connection serves, once bound. */
    sessionId: string | undefined;
    /** Server identity, for diagnostics. */
    get serverInfo(): {
        name?: string;
        version?: string;
    };
    /** Everything the server advertised, including host-only tools. */
    get allTools(): readonly LcuTool[];
    /** The tools the model may see, in server order. */
    modelTools(): LcuTool[];
    /**
     * Spawn the runtime, complete the MCP handshake, and discover tools.
     *
     * @throws {LcuError} when the process cannot start or the handshake fails.
     */
    connect(signal?: AbortSignal): Promise<void>;
    /**
     * Call one tool. `js` and `js_reset` back the PTC bridge; the host-only
     * tools are reachable here too because the lifecycle needs `turn_ended`.
     *
     * Requests carry no client-side deadline by default: a pause for a human
     * approval must not look like a hung call.
     */
    callTool(name: string, args: Readonly<Record<string, unknown>>, options?: {
        readonly timeoutMs?: number;
        readonly signal?: AbortSignal;
        /** The real host turn; the runtime keys per-turn state by it. */
        readonly turnId?: string;
        /** The host's tool-call id, forwarded as `call_id` when available. */
        readonly callId?: string;
        /** Checked by the managed facade before dispatch; never sent as authority to the runtime. */
        readonly expectedEpoch?: string;
    }): Promise<LcuCallResult>;
    /**
     * Tell the server a host turn ended, so its per-turn cleanup runs.
     *
     * @param sessionId - the real host session id, and nothing synthetic.
     * @param turnId - the real host turn id.
     * @param event - `Stop`, `Interrupt`, or `SubagentStop`.
     */
    turnEnded(sessionId: string, turnId: string, event?: LcuTurnEndEvent): Promise<void>;
    /**
     * Whether the explicit per-app Stop is actually available.
     *
     * The socket path alone is not the answer: a configuration that interposes no
     * lifecycle service sets nothing up to serve it, and reporting a channel that
     * cannot be reached would turn "this is not supported here" into a connection
     * error the caller has to interpret.
     */
    get hasHostControl(): boolean;
    /**
     * List the applications the runtime currently holds for one turn.
     *
     * @param sessionId - the real host session id.
     * @param turnId - the real host turn id.
     * @returns the active applications, with the names and bundle ids to stop by.
     */
    controlStatus(sessionId: string, turnId: string): Promise<readonly {
        name: string;
        bundleIdentifier: string;
    }[]>;
    /**
     * Ask the original host to stop using one application for this turn.
     *
     * This is the documented way to release an app without ending the connection;
     * the runtime then rejects further use of it until a later turn.
     *
     * @param sessionId - the real host session id.
     * @param turnId - the real host turn id.
     * @param app - the bundle identifier to stop.
     */
    controlStop(sessionId: string, turnId: string, app: string): Promise<void>;
    close(): Promise<void>;
}
//# sourceMappingURL=connection.d.ts.map