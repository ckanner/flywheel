/**
 * The control channel between this plugin and the runtime's Sky service.
 *
 * The runtime can hold an application open for a turn — that is what lets a
 * later call act on the same window. Releasing one early needs the runtime's own
 * control API, and that API lives inside the runtime's process, reachable only
 * from the Sky service wrapping it.
 *
 * So this is a relay. The wrapper inside the runtime connects first and becomes
 * the *service*; a request then arrives from the connection's client, is
 * forwarded to the service, and the service's answer is relayed back. No second
 * process is involved: the socket the child was told about is served here.
 *
 * The relay deliberately does not decide anything. Whether a session and turn are
 * real, and whether the application is actually being held, are questions only
 * the wrapper can answer, because only it has the turn metadata the runtime keys
 * that state by. A relay that guessed would turn "not yours to stop" into "done".
 *
 * Wire format, one JSON object per line:
 *   service -> here   {"type":"service"} first, then contexts, then replies
 *   here -> service   {"id":N,"type":"status"|"stop",…}
 *   client -> here    {"type":"status"|"stop",…}
 *   here -> client    {"ok":true,"result":…} or {"ok":false,"error":"…"}
 *
 * @module dsh-plugin-lcu/control
 */
/** The relay. */
export declare class ControlServer {
    #private;
    private constructor();
    /**
     * Serve one socket path.
     *
     * @param socketPath - the path the child was told about.
     * @param onDiag - the diagnostic sink.
     * @returns the running relay.
     */
    static open(socketPath: string, onDiag?: (message: string) => void): Promise<ControlServer>;
    /**
     * Whether the runtime's service has connected.
     *
     * This is the honest answer to "is the per-app Stop reachable": the path
     * existing means nothing, because a configuration with no wrapper never
     * connects to it.
     */
    get connected(): boolean;
    /** The turn contexts the service last reported, for diagnostics only. */
    get contexts(): readonly Record<string, unknown>[];
    /** Push one message to the service, for a caller that does not expect an answer. */
    notify(message: Record<string, unknown>): void;
    /** Stop serving. Requests already in flight are answered as failures. */
    close(): Promise<void>;
}
//# sourceMappingURL=control.d.ts.map