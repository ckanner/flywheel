export declare function isManagedAgent(agent: object): boolean;
export declare function claimManagedAgent(agent: object): () => void;
//# sourceMappingURL=ownership.d.ts.map