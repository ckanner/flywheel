/**
 * The program-facing side of the LCU PTC bridge.
 *
 * PTC programs run in the harness's own Node runtime, so they cannot reach the
 * objects that live inside the ChatGPT application's CUA REPL directly. This
 * module exposes those objects as a small proxy tree: every method call becomes
 * one `tools.lcu_cua` binding call, and every object returned by the runtime becomes
 * an opaque handle whose methods are routed back through the same binding.
 *
 * The file is imported from generated `run_code` programs, so it must stay
 * dependency-free and run in any of the PTC execution modes.
 *
 * @module dsh-plugin-lcu/bridge
 */
/** One method call routed to the LCU runtime. */
export interface CuaBridgeRequest {
    /** Opaque handle returned by a previous call; absent for top-level `cua` methods. */
    readonly target?: string;
    /** Method name on the runtime object. */
    readonly method: string;
    /** Positional arguments, exactly as the program passed them. */
    readonly args?: readonly unknown[];
}
/** The binding supplied by the PTC program. */
export type CuaBridgeCall = (request: CuaBridgeRequest) => Promise<unknown>;
/** A callable object exposed to the program. */
export type CuaBridgeObject = Record<string, (...args: unknown[]) => Promise<unknown>>;
/**
 * Build the `cua` object used by PTC programs.
 *
 * @param call - the `tools.lcu_cua` binding supplied by the generated SDK.
 * @param log - optional sink for runtime text; currently unused but kept so a
 *   caller can pass the same logger as the generic CUA bridge.
 * @returns a proxy whose top-level and returned-object methods all route through
 *   `call`.
 */
export declare function connectCua(call: CuaBridgeCall, log?: (text: string) => void): CuaBridgeObject;
//# sourceMappingURL=bridge.d.ts.map