/**
 * The agent-host guard.
 *
 * The application hosting the agent is refused, because
 * computer use can click anything an approved app shows — including the very
 * approval prompt — so approving the host would let the agent approve itself.
 *
 * The runtime's own shared client does this; a host that replaces that client owns the
 * rule. This is the DSH implementation: the agent's own process ancestry plus a
 * static list of dedicated agent hosts and terminals.
 *
 * A failed or unavailable process lookup falls back to the static list, so the
 * guard degrades to "known hosts are refused" rather than "nothing is refused".
 *
 * @module dsh-plugin-lcu/host-guard
 */
/**
 * Dedicated agent hosts, terminals, and this harness.
 *
 * Editors and IDEs are deliberately absent: they are common computer-use
 * targets, and when an editor hosts the agent its bundle is an ancestor of this
 * process, which the dynamic check already refuses.
 */
export declare const STATIC_HOST_BUNDLE_IDS: readonly string[];
/** The enclosing `.app` bundle of an executable path, if any. */
export declare function enclosingAppBundle(executablePath: string): string | undefined;
/**
 * The bundle identifiers of every `.app` on this process's ancestry.
 *
 * This is the dynamic half of the guard: whatever application actually launched
 * DSH — a terminal, an editor, a launcher — is refused by construction, even
 * when it is not on the static list.
 *
 * @returns the ancestor bundle identifiers; empty when the lookup fails.
 */
export declare function ancestorBundleIds(): Promise<ReadonlySet<string>>;
/**
 * Whether an approval would grant the agent control of its own host.
 *
 * @param app - the app the runtime is asking about: a display name, bundle id, or path.
 * @returns `true` when the request must be declined without asking the user.
 */
export declare function isAgentHostApp(app: string, options?: {
    allowTestOverride?: boolean;
}): Promise<boolean>;
/** Reset the memoized ancestry; for tests only. */
export declare function resetAncestorCache(): void;
//# sourceMappingURL=host-guard.d.ts.map