/**
 * The PTC-facing LCU surface.
 *
 * The ChatGPT application's CUA runtime is a JavaScript REPL (`js`). PTC
 * programs cannot call that REPL's `cua` object directly, so this module exposes
 * one namespaced structured RPC tool, `lcu_cua`, whose binding is a small RPC: a program calls a
 * method, the host runs it inside the persistent CUA REPL, and app/tab/window
 * objects come back as opaque handles.
 *
 * The model never sees the `js` tool. It sees the generated SDK's `tools.lcu_cua`
 * binding and the `connectCua` prelude in {@link ptcBridgeInstructions}.
 *
 * @module dsh-plugin-lcu/ptc
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ToolDefinition, ToolRunContext } from '@deepseek-ai/dsh-tools';
import type { RuntimeConnection } from './session.ts';
/** The single model-facing tool of the PTC surface. */
export declare const CUA_TOOL_NAME = "lcu_cua";
/** Marker printed by the in-REPL bridge so the host can find structured output. */
export declare const CUA_RESULT_MARKER = "__DSH_LCU_RESULT__";
/**
 * The in-REPL half of the bridge.
 *
 * It is deliberately installed with `??=` so a persistent PTC runtime (or a
 * persistent CUA REPL) can call it many times without replacing live handles.
 * Values that expose methods are remembered and returned as opaque handles;
 * plain JSON is passed through unchanged.
 */
export declare const CUA_PRELUDE: string;
/** Host-owned hooks around one bridge call. */
export interface CuaToolOptions {
    /** Awaited before every call; a rejection fails the call. */
    readonly beforeCall?: () => Promise<void>;
    /** The Agent's active turn identity, used for runtime approvals and cleanup. */
    readonly currentTurn?: () => string | undefined;
    /** The trusted owner may stop an entire turn, independently of the current model call. */
    readonly callSignal?: () => AbortSignal;
    /** Host admission surrounds the complete RPC, including its two native calls. */
    readonly aroundCall?: (request: CuaRequest, exec: ToolRunContext, operation: () => Promise<unknown>) => Promise<unknown>;
    /** Prepared projection is not proof that downstream policy or the model received it. */
    readonly onMedia?: (observation: CuaMediaObservation, exec: ToolRunContext) => Promise<void>;
}
export interface CuaMediaObservation {
    readonly method: string;
    readonly target?: string;
    readonly observedAt: string;
    readonly modelRoute: {
        readonly provider?: string;
        readonly model?: string;
    };
    readonly capturedImages: number;
    readonly preparedImages: number;
    readonly imageDeliveredToModel: 'unverified';
    readonly images: readonly {
        readonly sha256: string;
        readonly mimeType: string;
        readonly bytes: number;
        readonly attachment?: unknown;
        readonly hostPath?: string;
    }[];
}
/** Bind opaque native handles to the exact connection generation. */
export declare function scopeCuaValue(value: unknown, epoch?: string): unknown;
/** One validated bridge request. */
export interface CuaRequest {
    readonly target?: string;
    readonly method: string;
    readonly args: readonly unknown[];
}
/**
 * Validate the model's arguments.
 *
 * The tool is intentionally generic; the method name and positional arguments
 * are checked here so the in-REPL bridge never receives a non-string method or
 * a non-array argument list.
 *
 * @param value - parsed tool arguments.
 * @returns the normalized request.
 * @throws {Error} when the request shape is not usable.
 */
export declare function readCuaRequest(value: unknown): CuaRequest;
/**
 * Build the one model-facing PTC tool.
 *
 * @param connection - the Agent's LCU connection.
 * @param ctx - the plugin context, kept for the screenshot/attachment projection.
 * @param options - host hooks.
 * @returns a registrable tool definition.
 */
export declare function createCuaTool(connection: RuntimeConnection, ctx: Context, options?: CuaToolOptions): ToolDefinition;
/**
 * Register the PTC surface in one Agent's scope.
 *
 * @param agentCtx - the Agent's own context; registrations unwind on disposal.
 * @param connection - the Agent's connected LCU session.
 * @param ctx - the plugin context.
 * @param options - host hooks.
 * @returns a disposer that unregisters the tool.
 */
export declare function registerCuaTool(agentCtx: Context, connection: RuntimeConnection, ctx: Context, options?: CuaToolOptions): () => void;
/**
 * Model-facing PTC instructions.
 *
 * The generated SDK already declares `tools.lcu_cua`; this section teaches the model
 * how to turn it into the same `cua` object the native REPL used to expose.
 *
 * @param bridgeUrl - absolute `file:` URL of the compiled `bridge.js`.
 * @returns the prompt section text.
 */
export declare function ptcBridgeInstructions(bridgeUrl: string): string;
//# sourceMappingURL=ptc.d.ts.map