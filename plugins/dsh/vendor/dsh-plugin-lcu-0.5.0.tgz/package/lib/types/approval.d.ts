/**
 * Approval shapes.
 *
 * The runtime asks the host before it touches an app, and the request
 * is a specific `elicitation/create` form. This ports the recognition and
 * mapping rules from the runtime's shared client so a DSH host presents exactly the
 * choices the runtime offered — no more (granting an unoffered persistence scope
 * would let the agent keep desktop access the runtime meant to bound) and no
 * fewer (dropping `always` would nag the user every turn).
 *
 * @module dsh-plugin-lcu/approval
 */
import type { LcuElicitationRequest, LcuElicitationResponse } from './connection.ts';
/** One choice a native-app approval may offer. */
export interface ApprovalChoice {
    readonly value: 'once' | 'session' | 'always' | 'decline';
    readonly label: string;
}
/** A recognized native-app approval request. */
export interface NativeAppApproval {
    readonly message: string;
    readonly resource: string;
    readonly choices: readonly ApprovalChoice[];
}
/**
 * Recognize the runtime's native-app approval request.
 *
 * The shape is deliberately narrow: an empty-schema form whose `_meta` names the
 * computer-use connector and a concrete app. Every other elicitation the server
 * may send is *not* this, and must be handled elsewhere or cancelled.
 *
 * @param request - one `elicitation/create` payload.
 * @returns the recognized request, or `undefined` when it is a different shape.
 */
export declare function nativeAppApproval(request: LcuElicitationRequest): NativeAppApproval | undefined;
/**
 * Map the user's choice back to the response the runtime accepts.
 *
 * @param request - the same payload the choices came from.
 * @param value - the chosen value, or `'cancel'` for a dismissed prompt.
 * @returns an accept/decline/cancel answer; anything unrecognized cancels.
 */
export declare function nativeAppApprovalResponse(request: LcuElicitationRequest, value: string): LcuElicitationResponse;
/**
 * Map a presented option label back to the value the runtime accepts.
 *
 * These are different strings: the question surface answers with the option's
 * LABEL (`"Always allow"`), while the elicitation response needs the choice
 * VALUE (`"always"`). Passing the label straight through looks up nothing and
 * silently cancels a choice the user actually made.
 *
 * @param approval - the request the labels were presented for.
 * @param label - the label the user selected, or `undefined` when dismissed.
 * @returns the choice value, or `'cancel'` when the label matches no option.
 */
export declare function approvalValueForLabel(approval: NativeAppApproval, label: string | undefined): string;
/**
 * Normalize the pre-approved application bundle identifiers.
 *
 * Matching is case-insensitive because a bundle identifier's case is an
 * implementation detail of the application's Info.plist, and a user reading it
 * out of a log should not have to reproduce it exactly. Entries are otherwise
 * kept verbatim: nothing here widens what a match admits.
 *
 * @param raw - configured identifiers, possibly absent or malformed.
 * @returns the normalized set.
 */
export declare function normalizeApps(raw: readonly string[] | undefined): ReadonlySet<string>;
/**
 * Whether the user has already decided about this application.
 *
 * This is what makes an unattended run possible: without it the runtime asks
 * before it first uses each application, and an unanswered question is a refusal.
 * It is checked only after the agent-host guard, so a list can never authorize
 * the application the agent itself is running in.
 *
 * @param approval - the application approval the runtime sent.
 * @param allowedApps - normalized pre-approved identifiers.
 * @returns whether the application may be admitted without asking.
 */
export declare function isPreApprovedApp(approval: NativeAppApproval, allowedApps: ReadonlySet<string>): boolean;
/** The exact origin a browser-site approval names, when it names one. */
export declare function originApprovalOrigin(request: LcuElicitationRequest): string | undefined;
/** Whether the request names an already-authorized exact origin. */
export declare function isPreApprovedOrigin(request: LcuElicitationRequest, allowedOrigins: ReadonlySet<string>): boolean;
/**
 * Normalize a set of user-configured origins.
 *
 * Only exact HTTP(S) origins are accepted; anything else is dropped rather than
 * widened, because a relaxed match here is a site the user never approved.
 *
 * @param values - raw origin strings from configuration.
 * @returns the accepted origins.
 */
export declare function normalizeOrigins(values: readonly string[]): Set<string>;
//# sourceMappingURL=approval.d.ts.map