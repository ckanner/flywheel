#!/usr/bin/env node
/**
 * gen-presets.mjs — materialize DSH agent presets from the installed base.
 *
 * ## Why this is not part of a plugin
 *
 * DSH agent presets have no inheritance: a preset's `plugins` list is its
 * complete composition, and a patch replaces a whole entry rather than merging
 * into it. So any custom preset has to restate the base preset, and the base
 * ships inside the application and changes when DSH is upgraded.
 *
 * That job belongs to no single plugin. It started inside one, which meant a
 * plugin's script was rewriting a profile region that also serves other plugins
 * and the settings UI. Here it is a tool of its own: it reads the base, applies a
 * policy, and writes the marked region of a profile patch.
 *
 * ## The marker is load-bearing
 *
 * `BEGIN` names this file's original path, and it has to keep naming it: a
 * profile generated before this move already contains that exact string, and a
 * different one would make this script append a second block instead of
 * replacing the first.
 *
 * ## Usage
 *
 *   node src/gen-presets.mjs                 # write into the desktop profile
 *   node src/gen-presets.mjs --dry-run       # print, write nothing
 *   node src/gen-presets.mjs --out FILE      # write to FILE instead
 *   node src/gen-presets.mjs --daily-only    # refuse if the file already has heavy
 *   node src/gen-presets.mjs --asar PATH     # override the app.asar path
 *   node src/gen-presets.mjs --profile DIR   # override the profile directory
 *
 * @module dsh-preset-generator
 */

import { closeSync, openSync, readFileSync, readSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { PRESETS } from './policy.mjs'

// ---------------------------------------------------------------------------
// Defaults
// ---------------------------------------------------------------------------

const DEFAULT_ASAR =
  '/Applications/DeepSeek Harness.app/Contents/Resources/app.asar'
const BASE_PRESET = 'dsh/node_modules/@deepseek-ai/dsh-web-app/presets/ptc.patch.yml'
const DEFAULT_PROFILE = join(homedir(), '.dsh', 'profiles', 'desktop')

const BEGIN = '# >>> BEGIN generated presets (scripts/gen-presets.mjs) >>>'
const END = '# <<< END generated presets <<<'

/** The two presets this script owns. Both are PTC: LCU now exposes its
 * Computer/Browser runtime through the PTC `cua` bridge, not a native `js` tool.
 * DSH 0.2.2 deprecates the presentation selector in favour of mounting
 * `dsh-tool-executor-ptc` directly. */
// The pure SDK API consumes the same policies without running this CLI or
// writing the user's desktop profile. LCU attachment remains a separate grant.

// ---------------------------------------------------------------------------
// Minimal asar reader (Electron's asar is a simple header + flat blob)
// ---------------------------------------------------------------------------

/**
 * Read one file out of an asar archive without Electron.
 * @param asarPath - absolute path to the `.asar` file
 * @param innerPath - slash-separated path inside the archive
 * @returns the file contents
 */
function readAsarFile(asarPath, innerPath) {
  const fd = openSync(asarPath, 'r')
  try {
    const head = Buffer.alloc(16)
    readSync(fd, head, 0, 16, 0)
    const baseOffset = 8 + head.readUInt32LE(4)
    const jsonSize = head.readUInt32LE(12)
    const json = Buffer.alloc(jsonSize)
    readSync(fd, json, 0, jsonSize, 16)
    let node = JSON.parse(json.toString('utf8'))
    for (const segment of innerPath.split('/').filter(Boolean)) {
      node = node.files?.[segment]
      if (node === undefined) throw new Error(`not in archive: ${innerPath}`)
    }
    if (node.files !== undefined) throw new Error(`is a directory: ${innerPath}`)
    const buf = Buffer.alloc(node.size)
    readSync(fd, buf, 0, node.size, baseOffset + Number(node.offset))
    return buf
  } finally {
    closeSync(fd)
  }
}

// ---------------------------------------------------------------------------
// Line surgery
// ---------------------------------------------------------------------------

/** Indentation (0-based column of the first non-space char); -1 for blank lines. */
const indentOf = (line) => (line.trim() === '' ? -1 : line.search(/\S/))

/** Index of the child row `- id: <rowId>` inside a plugin list. */
function findRow(lines, rowId) {
  const index = lines.findIndex((line) => line.trim().startsWith(`- id: ${rowId}`))
  if (index < 0) throw new Error(`plugin row not found: ${rowId}`)
  return index
}

/**
 * Iterate the direct/indirect body lines of the row starting at `start`,
 * stopping at the next row or any line dedented to the row's own level.
 */
function* body(lines, start) {
  const base = indentOf(lines[start])
  for (let i = start + 1; i < lines.length; i += 1) {
    const ind = indentOf(lines[i])
    if (ind === -1) continue
    if (ind <= base) return
    yield i
  }
}

/**
 * Remove `disabled: true` from one row, turning it on.
 * @returns a new line array
 */
function enableRow(lines, rowId) {
  const start = findRow(lines, rowId)
  for (const i of body(lines, start)) {
    if (lines[i].trim().startsWith('disabled:')) {
      return lines.filter((_, k) => k !== i)
    }
  }
  return lines // already enabled — idempotent
}

/** Replace the base's tool-presentation selector with the concrete executor.
 *
 * DSH 0.2.2 carries `@deepseek-ai/dsh-tool-executor-ptc` in the base preset and
 * deprecates `@deepseek-ai/dsh-agent-tool-presentation`. Older bases still have
 * the selector with a `mode:` field. Both shapes are accepted here: the row is
 * replaced in place, so the custom preset asks for the executor directly and
 * never mounts the deprecated selector.
 */
function setPresentation(lines, presentation) {
  const rowId = `tool-executor-${presentation}`
  const rowName = `@deepseek-ai/dsh-tool-executor-${presentation}`
  const start = lines.findIndex((line) => {
    const text = line.trim()
    return /^- id: tool-executor-(native|ptc)$/.test(text) || text === '- id: tool-presentation'
  })
  if (start < 0) throw new Error('base preset has no tool-presentation or tool-executor row')

  const base = indentOf(lines[start])
  const indent = lines[start].slice(0, base)
  let end = start + 1
  while (end < lines.length) {
    const ind = indentOf(lines[end])
    if (ind !== -1 && ind <= base) break
    end += 1
  }
  const trailing = []
  while (end > start + 1 && lines[end - 1].trim() === '') {
    trailing.unshift(lines[end - 1])
    end -= 1
  }
  const replacement = [`${indent}- id: ${rowId}`, `${indent}  name: '${rowName}'`]
  return [...lines.slice(0, start), ...replacement, ...trailing, ...lines.slice(end)]
}

/** Extract the `plugins:` sub-tree (the row list) from a preset patch file. */
function extractPlugins(lines) {
  const index = lines.findIndex((line) => /^\s*plugins:\s*$/.test(line))
  if (index < 0) throw new Error('base preset has no `plugins:` key')
  const base = indentOf(lines[index])
  const out = []
  for (let i = index + 1; i < lines.length; i += 1) {
    const ind = indentOf(lines[i])
    if (ind !== -1 && ind <= base) break
    out.push(lines[i])
  }
  if (out.every((line) => line.trim() === '')) throw new Error('base `plugins:` is empty')
  while (out.length > 0 && out[out.length - 1].trim() === '') out.pop()
  return out
}

// ---------------------------------------------------------------------------
// Preset rendering
// ---------------------------------------------------------------------------

function renderPreset(spec, basePlugins) {
  const plugins = spec.enable.reduce(enableRow, [...basePlugins])
  const withMode = spec.presentation === null
    ? plugins
    : setPresentation(plugins, spec.presentation)
  const out = [
    `    - id: preset-${spec.id}`,
    "      name: '@deepseek-ai/dsh-agent-preset'",
    '      config:',
    `        id: ${spec.id}`,
    `        name: '${spec.name}'`,
    `        description: '${spec.description}'`,
    `        order: ${spec.order}`,
    '        plugins:',
    ...withMode,
    ...spec.append,
  ]
  return out
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

function parseArgs(argv) {
  const opts = {
    dryRun: false,
    // Preserve both managed choices on routine upgrades. An existing heavy
    // preset may be selected by the user or referenced by a plugin allowlist.
    withHeavy: true,
    out: undefined,
    asar: DEFAULT_ASAR,
    profile: DEFAULT_PROFILE,
  }
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i]
    if (arg === '--dry-run') opts.dryRun = true
    else if (arg === '--with-heavy') opts.withHeavy = true
    else if (arg === '--daily-only') opts.withHeavy = false
    else if (arg === '--out') opts.out = argv[++i]
    else if (arg === '--asar') opts.asar = argv[++i]
    else if (arg === '--profile') opts.profile = argv[++i]
    else throw new Error(`unknown argument: ${arg}`)
  }
  return opts
}

function buildBlock(baseLines, { withHeavy }) {
  const basePlugins = extractPlugins(baseLines)
  const specs = withHeavy ? [PRESETS.daily, PRESETS.heavy] : [PRESETS.daily]
  const lines = ['- insert:']
  for (const spec of specs) lines.push(...renderPreset(spec, basePlugins))
  return { body: lines.join('\n'), basePlugins, specs }
}

/** Replace the marked block in place, or append one. */
/**
 * Whether a top-level entry is the one this script wrote.
 *
 * The markers only say where the block lives, and the region is not exclusively
 * ours: DSH's settings UI appends its own entries there. So the entry to replace
 * is identified by what it contains — the `- insert:` shell carrying preset rows
 * — rather than by being the only thing between the markers.
 *
 * @param entry - the lines of one top-level entry.
 * @returns whether it is this script's.
 */
function isOwnEntry(entry) {
  return /^-\s+insert:\s*$/.test(entry[0]) && entry.some((line) => /^\s+- id: preset-/.test(line))
}

/**
 * Replace this script's own entry inside the region, and nothing else.
 *
 * Everything else in the region is left exactly where it is. That is the whole
 * point: entries the settings UI put there are neither moved nor re-emitted, so
 * there is nothing to collect, nothing to de-duplicate, and no way for a
 * repeated settings write to accumulate a copy per run.
 *
 * @param region - the text between the markers.
 * @param body - the entry to write, without the markers.
 * @returns the region with our entry replaced.
 */
function replaceOwnEntry(region, body) {
  const lines = region.split('\n')
  const out = []
  let replaced = false
  let i = 0
  while (i < lines.length) {
    if (!/^-\s+\S/.test(lines[i])) {
      out.push(lines[i])
      i += 1
      continue
    }
    const start = i
    i += 1
    while (i < lines.length && !/^-\s+\S/.test(lines[i])) i += 1
    const entry = lines.slice(start, i)
    if (!replaced && isOwnEntry(entry)) {
      // The entry as consumed includes the blank lines that followed it, since
      // they are not the start of another entry. They separate it from whatever
      // comes next, so they are restored — otherwise the marker that follows ends
      // up glued to the last line of the body.
      const trailing = []
      while (entry.length > 0 && entry[entry.length - 1].trim() === '') trailing.unshift(entry.pop())
      out.push(...body.split('\n'), ...trailing)
      replaced = true
      continue
    }
    out.push(...entry)
  }
  // No entry of ours inside — a hand-edited file, or a region whose block was
  // removed. Writing one is the same thing the first run does.
  if (!replaced) out.unshift(body)
  return out.join('\n')
}

function spliceBlock(text, body) {
  const begin = text.indexOf(BEGIN)
  const end = text.indexOf(END)
  if (begin >= 0 && end > begin) {
    // `region` runs from just after the BEGIN marker to just before END, so it
    // already carries the newline that ends the marker line and the one before
    // END. Adding either again would leave a blank line behind on every run.
    const region = text.slice(begin + BEGIN.length, end)
    return text.slice(0, begin)
      + BEGIN + replaceOwnEntry(region, body) + END
      + text.slice(end + END.length)
  }
  const separator = text === '' ? '' : text.endsWith('\n') ? '\n' : '\n\n'
  return `${text}${separator}${BEGIN}\n${body}\n${END}\n`
}

function main() {
  const opts = parseArgs(process.argv.slice(2))
  const baseLines = readAsarFile(opts.asar, BASE_PRESET).toString('utf8').split('\n')
  const { body, basePlugins, specs } = buildBlock(baseLines, opts)
  const verb = opts.dryRun ? 'would write' : 'wrote'
  const rowCount = basePlugins.filter((line) => /^\s*- id: /.test(line)).length

  if (opts.dryRun) {
    process.stdout.write(`${BEGIN}\n${body}\n${END}\n`)
  } else {
    const target = opts.out ?? join(opts.profile, 'cordis.patch.yml')
    let before
    let missing = false
    try {
      before = readFileSync(target, 'utf8')
    } catch (error) {
      // A new profile may not have a patch yet. Only absence is an empty
      // document; an unreadable or invalid existing target must still fail.
      if (error.code !== 'ENOENT') throw error
      before = ''
      missing = true
    }
    // Never delete a preset this file already had. A re-run is the documented
    // response to a DSH upgrade, and it must not be able to take away the mode a
    // user relies on as a side effect of an argument they did not pass.
    for (const preset of ['daily', 'heavy']) {
      const had = before.includes(`- id: preset-${preset}`)
      const keeps = body.includes(`- id: preset-${preset}`)
      if (had && !keeps) {
        throw new Error(
          `${target} already defines preset-${preset} and this run would remove it. `
          + 'Re-run without --daily-only to keep every preset the file has.',
        )
      }
    }
    // Do not overwrite a patch another writer created after the missing read.
    writeFileSync(target, spliceBlock(before, body), { mode: 0o600, flag: missing ? 'wx' : 'w' })
    process.stderr.write(`${verb} ${target}\n`)
  }
  process.stderr.write(
    `base: ${BASE_PRESET} (${rowCount} top-level rows)\n`
    + `presets: ${specs.map((s) => s.id).join(', ')}\n`,
  )
}

main()
