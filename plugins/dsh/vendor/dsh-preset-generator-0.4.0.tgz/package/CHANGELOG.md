# Changelog

## 0.4.0

Export a pure ESM SDK composition API alongside the existing desktop CLI.
`createSdkPtcComposition` shares daily/heavy policy and returns an isolated PTC
overlay with canonical base/bundle provenance. `inspectPtcBundle` distinguishes
same-version source bundles without inferring runtime support, and
`validateSdkPtcAdmission` checks correlated executor/output/image observations.
The API neither writes the desktop profile nor mounts a named preset or grants
GUI/delegation access. Existing profile-preservation tests now use portable ASAR
fixtures and run in CI without the Mac application.

## 0.3.0

Both generated presets now use PTC.

**LCU moves to a PTC bridge.** The `heavy` preset no longer swaps in
`tool-executor-native`; LCU's Computer/Browser runtime is exposed as the PTC
`cua` object instead of a directly-callable `js` tool. A profile regenerated
against 0.3.0 therefore has `tool-executor-ptc` in both `daily` and `heavy`.


## 0.2.0

Track DSH Desktop 0.2.2 and stop generating the deprecated presentation selector.

**The generated presets mount the executor directly.** DSH 0.2.2 deprecates
`@deepseek-ai/dsh-agent-tool-presentation`; the base preset now carries
`@deepseek-ai/dsh-tool-executor-ptc`. The generator replaces that row with
`tool-executor-ptc` (daily) or `tool-executor-native` (heavy) instead of writing a
`mode:` field, and still accepts a pre-0.2.2 base that has the old selector.

**Re-run after upgrading DSH.** The 0.2.2 base adds `tool-office`, the
`tool-fs.applyPatch` option, and `tool-subagent-control.interrupt`; a re-run picks
them up. The `--dry-run` output now matches the current profile block except for
these base changes.

## 0.1.1

Track DSH Desktop 0.2.1.

**`heavy` uses `native` presentation.** DSH 0.2.1 removed the `both` tool-presentation mode; a preset declares
one presentation and only `native` and `ptc` exist. `heavy` now asks for `native`, which keeps computer-use tools
directly callable and gives up the PTC `run_code` surface for that preset. A profile regenerated against the new
app no longer fails the `heavy` mount.

**Re-run after upgrading DSH.** The shipped base changed again: `persona.suffix` with `{{cwd}}` is gone (the
variable no longer exists and prompt assembly rejects it), `time-context` and `tool-schedule` rows were added,
`backgroundMode` was removed from `tool-subagent`, and the per-preset `tool-subagent-codex` /
`tool-subagent-claude-code` / `tool-ralph` rows were dropped. The generator reads the installed base, so a re-run
picks all of it up; the tests now pin the current surface instead of the old Codex-row expectation.

## 0.1.0

First release, as a project of its own.

**Moved out of `dsh-plugin-lcu`.** It generates presets that serve more than one plugin, and the region it writes
is also written by DSH's settings UI, so it does not belong to any one plugin — least of all one whose script was
rewriting a profile region shared with settings it does not own. The move is behaviour-preserving: generating
from the same profile with both produced byte-identical output.

**The marker still names the old path.** `BEGIN` contains `scripts/gen-presets.mjs` on purpose: a profile
generated before the move already has that exact string, and a different one would make the script append a
second block instead of replacing the first.

**Replaces only its own entry.** The region between the markers is not exclusively this script's — the settings
UI appends `agent-preset-registry` and `subagent-model-selection-settings` there. Splicing the whole region
deleted them; re-emitting them after the block left another copy behind on every later settings write. A run now
replaces the single `- insert:` entry it wrote and leaves everything else byte for byte where it is, so there is
nothing to move and nothing to accumulate.
