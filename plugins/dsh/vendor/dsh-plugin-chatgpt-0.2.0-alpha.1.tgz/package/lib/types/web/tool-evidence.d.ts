/** DSH's durable call event, scoped to its owning Session, identifies a tool tree. */
export interface WebToolRoot {
    sessionId: string;
    rootCallId: string;
    rootCallSeq: number;
}
export interface WebToolOccurrence extends WebToolRoot {
    hostInvocationId: string;
    callId: string;
}
export interface WebToolCommit extends WebToolRoot {
    resultEventSeq: number;
}
export interface WebToolIntent extends WebToolRoot {
    callId: string;
    completed: boolean;
    observed?: boolean;
    outcomeUnknown?: boolean;
    resultEventSeq?: number;
}
export interface WebSessionEvent {
    type: string;
    seq: number;
    data: Record<string, unknown>;
    sourceEventSeqs?: readonly number[];
}
export declare function validToolRoot(root: WebToolRoot): boolean;
export declare function toolOccurrenceKey(tool: WebToolRoot & {
    callId: string;
}): string;
/** A historical call with the same model-supplied ID is not a current dispatch. */
export declare function toolRootFromEvents(sessionId: string, rootCallId: string, events: readonly WebSessionEvent[]): WebToolRoot | undefined;
/** Result attribution comes from the persisted source-event link, never callId alone. */
export declare function toolCommitFromEvent(sessionId: string, event: WebSessionEvent, events: ReadonlyMap<number, WebSessionEvent>): WebToolCommit | undefined;
/** Legacy ID-only receipts cannot positively settle work after an upgrade/restart. */
export declare function settledToolIntent(key: string, tool: WebToolIntent, intents: Record<string, WebToolIntent>): boolean;
//# sourceMappingURL=tool-evidence.d.ts.map