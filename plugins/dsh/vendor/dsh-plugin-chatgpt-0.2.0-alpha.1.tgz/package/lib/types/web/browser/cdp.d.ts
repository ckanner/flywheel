import type { WebConnection } from './types.ts';
/** A small public Chrome DevTools Protocol client; no ChatGPT HTTP endpoints. */
export declare class CdpConnection {
    private nextId;
    private readonly pending;
    private readonly socket;
    private deadlineMs;
    private constructor();
    static connect(url: string, deadlineMs: number): Promise<CdpConnection>;
    command<T extends Record<string, unknown> = Record<string, unknown>>(method: string, params?: Record<string, unknown>, sessionId?: string): Promise<T>;
    close(): void;
    /** Only for cancelling/detaching an already-owned page; never for navigation or submission. */
    beginCleanup(): void;
    private fail;
}
/** Chrome is detached from each SDK request's process group and is never killed on call cleanup. */
export declare function openBrowser(connection: WebConnection, deadlineMs: number, signal?: AbortSignal): Promise<CdpConnection>;
export declare class CdpPage {
    readonly cdp: CdpConnection;
    readonly targetId: string;
    readonly sessionId: string;
    private constructor();
    static create(cdp: CdpConnection, targetId?: string): Promise<CdpPage>;
    evaluate<T>(expression: string): Promise<T>;
    navigate(url: string): Promise<void>;
    insertText(text: string): Promise<void>;
    /** Resolve one actual composer input in the bound document; never set a guessed node id. */
    setFileInputFiles(files: readonly string[], expectedUrl: string): Promise<void>;
    escape(): Promise<void>;
    /** Detach only. Keeping the owned tab allows cloud-state reconciliation and user inspection. */
    close(): Promise<void>;
}
//# sourceMappingURL=cdp.d.ts.map