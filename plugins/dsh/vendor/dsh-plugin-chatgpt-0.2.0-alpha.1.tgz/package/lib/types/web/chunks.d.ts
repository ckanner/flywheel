import type { StreamChunk } from '@deepseek-ai/dsh-llm';
import type { WebDelivery } from './session-coordinator.ts';
/** One immutable captured response, projected only after whole-answer validation. */
export declare function deliveryChunks(delivery: WebDelivery): StreamChunk[];
//# sourceMappingURL=chunks.d.ts.map