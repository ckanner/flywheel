import { CdpPage } from './cdp.ts';
import type { WebConnection, WebConversation, WebEvidence, WebPage, WebPageFactory, WebPageSample, WebTurnRequest } from './types.ts';
/** Self-contained page function: fixtures run the same DOM code as production. */
export declare function modelSelectionAction(action: 'open' | 'select' | 'verify', trigger: string, observedModel?: boolean): {
    ready: boolean;
    model?: string;
    effort?: string;
};
export declare function snapshotPage(): {
    url: string;
    projectUrl: string | null;
    messages: Array<{
        role: string;
        id: string;
        text: string;
        finished: boolean;
        thinking: boolean;
    }>;
    stopVisible: boolean;
    thinkingVisible: boolean;
    phase: string;
    composerReady: boolean;
    errorText: string;
};
/** Read only controls in the project settings dialog, never model-generated text. */
export declare function projectSettingsEvidence(): {
    projectOnly: boolean;
    emptyInstructions: boolean;
};
export declare function projectSourcesEvidence(): boolean;
export declare function projectSharingEvidence(): boolean;
export declare function conversationFromUrl(url: string, projectUrl?: string, title?: string): WebConversation;
export declare class ChatGptPage implements WebPage {
    readonly targetId: string;
    private projectUrl;
    private title;
    private baselineIds;
    private prompt;
    private boundConversationUrl;
    private cleanupUntil;
    private readonly page;
    private readonly connection;
    private readonly request;
    constructor(page: CdpPage, connection: WebConnection, request: WebTurnRequest);
    private evaluate;
    private ready;
    private account;
    observeAccountFingerprint(): Promise<string>;
    private selectModel;
    private createProject;
    private verifyContext;
    prepare(request: WebTurnRequest, beforeContainerMutation?: () => Promise<void>): Promise<{
        conversation: WebConversation;
        evidence: WebEvidence;
    }>;
    inspect(request: WebTurnRequest): Promise<{
        conversation: WebConversation;
        evidence: WebEvidence;
    }>;
    private evidence;
    submit(prompt: string): Promise<void>;
    sample(): Promise<WebPageSample>;
    stop(userMessageId: string): Promise<boolean>;
    finalize(conversation: WebConversation): Promise<WebConversation>;
    close(): Promise<void>;
}
export declare class CdpWebPageFactory implements WebPageFactory {
    open(connection: WebConnection, request: WebTurnRequest, targetId?: string): Promise<WebPage>;
    connect(connection: WebConnection, deadlineMs: number): Promise<{
        accountFingerprint?: string;
        targetId: string;
    }>;
}
//# sourceMappingURL=page.d.ts.map