export declare const WEB_MODEL_ID = "gpt-6-pro-web";
export declare const WEB_EFFORT = "pro";
export declare const WEB_PROTOCOL = "dsh-chatgpt-web/1";
/** Policy estimates are local limits, never claims about the ChatGPT context window. */
export interface WebBudgetPolicy {
    version: string;
    maxInputBytes: number;
    outputReserveBytes: number;
    maxResponseBytes: number;
    maxHistoryBytes: number;
    maxTurns: number;
    maxGenerations: number;
    maxToolCalls: number;
    maxJsonDepth: number;
    /** Additional format-only turns; all share the original wall and byte budgets. */
    maxFormatRepairs: number;
    wallTimeoutMs: number;
}
export declare const DEFAULT_WEB_BUDGET: Readonly<WebBudgetPolicy>;
export declare class WebPolicyError extends Error {
    readonly code: string;
    readonly reason: string;
    constructor(reason: string, code?: string);
}
export declare function objectValue(value: unknown, label: string): Record<string, unknown>;
export declare function exactKeys(value: Record<string, unknown>, allowed: readonly string[], label: string): void;
export declare function nonempty(value: unknown, label: string, max?: number): string;
export declare function integer(value: unknown, label: string, min: number, max: number): number;
export declare function budgetPolicy(value?: unknown): WebBudgetPolicy;
/** Deterministic, lossless-JSON fingerprints; reject values JSON.stringify would silently discard. */
export declare function canonical(value: unknown): string;
export declare function digest(value: unknown): string;
export declare function webModel(provider: string, policy?: Readonly<WebBudgetPolicy>): {
    provider: string;
    id: string;
    name: string;
    description: string;
    inputModalities: readonly ["text", "image"];
    badge: {
        text: string;
        tone: "info";
    };
    context: {
        contextWindow: number;
    };
    reasoning: {
        efforts: {
            id: string;
            name: string;
        }[];
        defaultEffort: string;
    };
    systemPromptUpdate: "in-history";
};
//# sourceMappingURL=policy.d.ts.map