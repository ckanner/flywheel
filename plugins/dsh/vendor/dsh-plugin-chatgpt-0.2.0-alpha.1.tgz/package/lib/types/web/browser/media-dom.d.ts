/** Resolve a real input in the owned composer, including the site's general file picker. */
export declare function composerImageInput(): HTMLInputElement;
/** This self-contained function is executed verbatim in the browser and DOM fixtures. */
export declare function imageUploadEvidence(messageId?: string): {
    scopeReady: boolean;
    cards: Array<{
        name: string;
        ready: boolean;
        failed: boolean;
    }>;
    busy: boolean;
    error: boolean;
    messageText?: string;
};
//# sourceMappingURL=media-dom.d.ts.map