import { type WebSettings } from './config.ts';
/** Private, invocation-bound evidence. This is not a browser connection API. */
export interface WebRecoveryIdentity {
    sessionId: string;
    executionDomainId: string;
    hostInvocationId: string;
}
export interface WebRecoveryCheckpoint {
    version: 1;
    contract: 'chatgpt-web/read-only-recovery/1';
    stateDir: string;
    provider: string;
    identity: WebRecoveryIdentity;
    ownerPid: number;
    settings: WebSettings;
    settingsDigest: string;
    profileManaged: boolean;
    invocationIdentity: string;
    domainInvocations: string[];
}
/** Called by the public host after beginInvocation and before any prompt. */
export declare function createWebRecoveryCheckpoint(source: {
    stateDir: string;
    route: string;
    settings: WebSettings;
    profileManaged: boolean;
}, input: WebRecoveryIdentity): Promise<WebRecoveryCheckpoint>;
/**
 * Inspect only original private evidence after the original SDK owner exits.
 * A committed model response is NOT a completed Flywheel task. Consumers must
 * also require their own prompt/wait/terminal and candidate/role checkpoints.
 */
export declare function readWebInvocationRecovery(input: WebRecoveryCheckpoint): Promise<{
    version: 1;
    contract: "chatgpt-web/read-only-recovery/1";
    identity: WebRecoveryIdentity;
    checkpointDigest: string;
    revision: string;
    disposition: "not-dispatched" | "retired" | "committed" | "blocked";
    binding: {
        protocol: 1;
        transport: "chatgpt-web";
        provider: string;
        model: string;
        reasoningEffort: string;
        connectionId: string;
        accountFingerprint: string;
        policyVersion: string;
        contextPolicy: "project-only";
        observation: "opaque";
        usage: "unknown";
        hostContractVersion: 1;
        runtimeVersion: "web-runtime/1";
    };
    facts: {
        dispatch: "unknown" | "not-dispatched" | "dispatched";
        outcome: "completed" | "failed" | "unknown";
        remoteGeneration: "unknown" | "running" | "idle";
        localCleanupConfirmed: boolean;
        usageStatus: "unknown";
        sessionId: string;
        executionDomainId: string;
        hostInvocationId: string;
        version: 1;
    };
    terminalMain: {
        requestId: string;
        responseId: string;
        contentDigest: string;
        hostCommitId: string;
        text: string;
    }[];
}>;
//# sourceMappingURL=recovery.d.ts.map