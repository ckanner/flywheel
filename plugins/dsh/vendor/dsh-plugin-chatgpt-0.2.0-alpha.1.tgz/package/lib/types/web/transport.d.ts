import type { WebConnection, WebFacts, WebJournal, WebPageFactory, WebPageSample, WebTurnRequest, WebTurnResult } from './browser/types.ts';
export { WebTransportError } from './browser/types.ts';
export type { WebActivity, WebConversation, WebEvidence, WebFacts } from './browser/types.ts';
export type WebConnectionConfig = WebConnection;
export type WebRunRequest = WebTurnRequest;
export type WebRunResult = WebTurnResult;
export interface TerminalState {
    key: string;
    stableSince: number;
    confirmations: number;
}
/** Repeated unchanged content cannot finish a turn without response-scoped terminal UI. */
export declare function advanceTerminal(state: TerminalState | undefined, sample: WebPageSample, now: number): {
    state: TerminalState;
    complete: boolean;
};
export interface WebRecovery {
    requestId: string;
    facts: WebFacts;
    result?: WebTurnResult;
    hostCommitId?: string;
    disposition?: WebJournal['disposition'];
    /** Observed cloud state is separate; the original dispatch record is never rewritten. */
    observation?: WebPageSample;
    rejection?: {
        reason: string;
        responseDigest: string;
        transportRequestId: string;
    };
    retired?: {
        at: number;
        responseDigest: string;
        transportRequestId: string;
        reason: 'user-discarded-invalid-response';
    };
}
interface RecoveryOptions {
    observe?: boolean;
    deadlineMs?: number;
    signal?: AbortSignal;
    preparedRepair?: {
        parentRequestId: string;
        parentDigest: string;
    };
}
export declare class WebTransport {
    private readonly pages;
    readonly connection: WebConnection;
    constructor(connection: WebConnection, options?: {
        pageFactory?: WebPageFactory;
    });
    /** No browser, account lookup or prompt. Suitable for catalog and diagnostics. */
    status(): {
        configured: true;
        transport: 'chatgpt-web';
        accountVerified: false;
        modelVerified: false;
    };
    connect(deadlineMs?: number): Promise<{
        accountFingerprint?: string;
        targetId: string;
    }>;
    run(request: WebTurnRequest): Promise<WebTurnResult>;
    recover(requestId: string, options?: RecoveryOptions): Promise<WebRecovery>;
    private recoverJournal;
    acknowledge(requestId: string, commit: {
        hostCommitId: string;
        responseDigest: string;
    }): Promise<void>;
    /** Transfers a rejected terminal turn's capacity to one named correction. */
    releaseForRepair(requestId: string, input: {
        nextRequestId: string;
        responseDigest: string;
    }): Promise<void>;
    /** Explicit failed disposition; it never fabricates an ACK or successful outcome. */
    retire(requestId: string, input: {
        responseDigest: string;
        reason: 'user-discarded-invalid-response';
    }): Promise<{
        at: number;
        responseDigest: string;
        reason: 'user-discarded-invalid-response';
    }>;
    private assertDisposable;
}
//# sourceMappingURL=transport.d.ts.map