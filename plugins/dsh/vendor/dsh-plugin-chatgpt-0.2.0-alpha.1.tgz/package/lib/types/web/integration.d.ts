import { ChatGptWebHost } from './host.ts';
import type { WebPageFactory } from './browser/types.ts';
/** Structural view of the public host API. The compatibility patch is version-checked at admission. */
export interface WebPluginContext {
    get(name: string): unknown;
    provide(name: string, value: unknown): () => void;
    on(name: string, callback: (...args: never[]) => unknown): () => void;
    emit(name: string, ...args: unknown[]): void;
}
/** Register public hooks once; the host owns AgentLoop, tools, compaction and persistence. */
export declare function installWebHost(ctx: WebPluginContext, stateDir: string, route: string, configured?: () => unknown, options?: {
    pageFactory?: WebPageFactory;
}): ChatGptWebHost;
//# sourceMappingURL=integration.d.ts.map