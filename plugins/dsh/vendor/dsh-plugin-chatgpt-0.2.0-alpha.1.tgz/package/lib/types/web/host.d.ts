import type { GenerateOptions, StreamChunk } from '@deepseek-ai/dsh-llm';
import { WebSettingsStore, type WebSettings } from './config.ts';
import { type WebCallContext, type WebDelivery, type WebReplayReference, type WebRetirement } from './session-coordinator.ts';
import type { WebFacts, WebPageFactory } from './browser/types.ts';
import { type WebRecoveryIdentity, type WebRecoveryCheckpoint } from './recovery.ts';
import { type WebToolCommit, type WebToolOccurrence } from './tool-evidence.ts';
export declare const webHostCapabilities: Readonly<{
    version: 1;
    runtimeVersion: "web-runtime/1";
    providerModel: "gpt-6-pro-web";
    transport: "chatgpt-web";
    observation: "opaque";
    usage: "unknown";
    requiredHost: Readonly<{
        replayVeto: 1;
        durableResponseAck: 1;
        summaryRoute: 2;
        durableSummaryAck: 1;
        pressurePolicy: 1;
    }>;
    media: "images";
    imageCapabilities: Readonly<{
        absoluteLimits: Readonly<import("./image-policy.ts").WebImageLimits>;
        mediaTypes: readonly ["image/png", "image/jpeg", "image/webp", "image/gif"];
        roles: readonly ["user", "tool"];
        fileInput: false;
        maxImages: number;
        maxImageBytes: number;
        maxTotalBytes: number;
        version: "web-images/1";
    }>;
    oracleRuntime: false;
}>;
export interface WebBindingRequest {
    provider: string;
    model: string;
    reasoningEffort?: string;
    sessionId?: string;
    hostInvocationId?: string;
    purpose?: string;
    executionDomainId?: string;
    requireIsolation?: boolean;
    deadlineMs?: number;
}
export interface WebInvocationRequest {
    sessionId: string;
    executionDomainId: string;
    hostInvocationId: string;
    deadlineMs?: number;
    requireIsolation?: boolean;
    workspace?: string;
}
export interface WebSessionOwner {
    sessionId: string;
    rootSessionId: string;
    workspace: string;
    parentSessionId?: string;
}
export interface WebHostEnvironment {
    capabilities(): {
        replayVeto?: number;
        durableResponseAck?: number;
        summaryRoute?: number;
        durableSummaryAck?: number;
        pressurePolicy?: number;
        recoveredResponse?: number;
        recoveredSummary?: number;
    };
    activity(value: unknown): void;
    /** Authoritative durable DSH image store; media never interprets arbitrary paths or URLs. */
    resolveAttachments?(): unknown;
    /** Construction-only test seam; production always uses the managed CDP page. */
    pageFactory?: WebPageFactory;
    isAgentBusy?(sessionId: string): boolean;
    blocked?(input: {
        executionDomainId: string;
        sessionIds: string[];
        workspaces: string[];
        reason: string;
    }): void | Promise<void>;
    /** Public host adoption transaction, installed only by the versioned compatibility contract. */
    adopt?(delivery: WebDelivery): Promise<unknown>;
}
export declare class ChatGptWebHost {
    readonly version = 1;
    readonly runtimeVersion = "web-runtime/1";
    readonly settings: WebSettingsStore;
    private readonly store;
    private readonly contexts;
    private readonly coordinators;
    private readonly transports;
    private queue;
    private readonly liveTools;
    private readonly liveCalls;
    private readonly stateDir;
    private readonly route;
    private readonly environment;
    constructor(stateDir: string, route: string, environment: WebHostEnvironment, configured?: () => unknown, changed?: () => void);
    private registry;
    private physicalWorkspace;
    private bindWorkspace;
    private stopDomain;
    private change;
    private requireHost;
    admitBinding(input: WebBindingRequest): Promise<{
        protocol: 1;
        transport: "chatgpt-web";
        provider: string;
        model: string;
        reasoningEffort: string;
        connectionId: string;
        accountFingerprint: string;
        policyVersion: string;
        contextPolicy: import("./browser/types.ts").WebContextPolicy;
        observation: "opaque";
        usage: "unknown";
        hostContractVersion: 1;
        runtimeVersion: string;
    }>;
    private unresolved;
    private toolsSettled;
    private callIsLive;
    assertDomain(executionDomainId: string): Promise<void>;
    beginInvocation(input: WebInvocationRequest): Promise<void>;
    private createInvocation;
    /** Bind the current execution directory for every managed provider/tool, including non-Web children. */
    inheritOwner(owner: WebSessionOwner): Promise<void>;
    callContext(options: GenerateOptions, kind: WebCallContext['kind'], owner: WebSessionOwner): Promise<WebCallContext>;
    /** Scope the complete lazy iterator, including return/throw, without mutating frozen host options. */
    wrap(context: WebCallContext, next: () => AsyncIterable<StreamChunk>): AsyncIterable<StreamChunk>;
    private connection;
    generate(expectedSettings?: string, resolved?: GenerateOptions): Promise<WebDelivery>;
    committed(reference: WebReplayReference, blocks: readonly unknown[], hostCommitId: string, durable: boolean): Promise<void>;
    replayCheck(sessionId: string): Promise<void>;
    toolStarted(sessionId: string, toolId: string, rootCallId?: string, rootCallSeq?: number): Promise<WebToolOccurrence | undefined>;
    toolObserved(occurrence: WebToolOccurrence, unknown: boolean): Promise<void>;
    toolCommitted(proof: WebToolCommit, durable: boolean, unknown: boolean): Promise<void>;
    guardSession(sessionId: string, workspace: string): Promise<void>;
    isManagedSession(sessionId: string, workspace: string): Promise<boolean>;
    observeAgentIdle(sessionId: string): void;
    agentIdle(sessionId: string): Promise<void>;
    deliveredEphemeral(reference: WebReplayReference, blocks: readonly unknown[]): Promise<void>;
    invocationFacts(input: Pick<WebInvocationRequest, 'sessionId' | 'executionDomainId' | 'hostInvocationId'>): Promise<{
        dispatch: "unknown" | "not-dispatched" | "dispatched";
        outcome: "completed" | "failed" | "unknown";
        remoteGeneration: "unknown" | "running" | "idle";
        localCleanupConfirmed: boolean;
        usageStatus: "unknown";
        invocations: {
            retired?: WebRetirement;
            requestId: string;
            sessionId: string;
            kind: "compaction" | "session-title" | "main" | "one-shot";
            facts: WebFacts;
            committed: boolean;
        }[];
        sessionId: string;
        executionDomainId: string;
        hostInvocationId: string;
        version: 1;
    }>;
    /** Freeze original invocation ownership before the caller submits its prompt. */
    recoveryCheckpoint(input: WebRecoveryIdentity): Promise<WebRecoveryCheckpoint>;
    status(): Promise<{
        settings: WebSettings;
        hostCapabilities: {
            replayVeto?: number;
            durableResponseAck?: number;
            summaryRoute?: number;
            durableSummaryAck?: number;
            pressurePolicy?: number;
            recoveredResponse?: number;
            recoveredSummary?: number;
        };
        runtimeVersion: string;
        managedByProfile: boolean;
        configured: boolean;
        liveVerified: boolean;
        recentConversations: {
            sessionId: string;
            kind: "compaction" | "session-title" | "main" | "one-shot";
            url: string;
        }[];
        pending: {
            sessionId: string;
            hostInvocationId: string;
            reason: string;
            requestIds: string[];
        }[];
    }>;
    configure(value: unknown): Promise<{
        settings: WebSettings;
        hostCapabilities: {
            replayVeto?: number;
            durableResponseAck?: number;
            summaryRoute?: number;
            durableSummaryAck?: number;
            pressurePolicy?: number;
            recoveredResponse?: number;
            recoveredSummary?: number;
        };
        runtimeVersion: string;
        managedByProfile: boolean;
        configured: boolean;
        liveVerified: boolean;
        recentConversations: {
            sessionId: string;
            kind: "compaction" | "session-title" | "main" | "one-shot";
            url: string;
        }[];
        pending: {
            sessionId: string;
            hostInvocationId: string;
            reason: string;
            requestIds: string[];
        }[];
    }>;
    connect(): Promise<{
        connection: {
            accountFingerprint?: string;
            targetId: string;
        };
        configurationRequired: boolean;
        settings: WebSettings;
        hostCapabilities: {
            replayVeto?: number;
            durableResponseAck?: number;
            summaryRoute?: number;
            durableSummaryAck?: number;
            pressurePolicy?: number;
            recoveredResponse?: number;
            recoveredSummary?: number;
        };
        runtimeVersion: string;
        managedByProfile: boolean;
        configured: boolean;
        liveVerified: boolean;
        recentConversations: {
            sessionId: string;
            kind: "compaction" | "session-title" | "main" | "one-shot";
            url: string;
        }[];
        pending: {
            sessionId: string;
            hostInvocationId: string;
            reason: string;
            requestIds: string[];
        }[];
    }>;
    recover(requestId: string, adopt?: boolean): Promise<unknown>;
    private assertRetirementOwner;
    private finishRetirement;
    /** Human UI action, separate from read-only recovery and response adoption. */
    retire(requestId: string, responseDigest: string, confirmation: string): Promise<unknown>;
    /** Adoption can settle this response, never unrelated remote/tool uncertainty. */
    authorizeRecovery(reference: WebReplayReference, chunks?: readonly StreamChunk[]): Promise<void>;
}
export declare function replayReference(value: unknown): WebReplayReference | undefined;
//# sourceMappingURL=host.d.ts.map