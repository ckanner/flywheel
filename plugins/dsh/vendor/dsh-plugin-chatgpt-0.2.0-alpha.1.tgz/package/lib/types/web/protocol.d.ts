import { WEB_PROTOCOL, type WebBudgetPolicy } from './policy.ts';
export interface WebToolSchema {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
}
export interface WebToolIdentity {
    hostCallId: string;
    requestId: string;
    providerCallId: string;
}
export type WebAnswer = {
    protocol: typeof WEB_PROTOCOL;
    requestId: string;
    generation: number;
    kind: 'final';
    text: string;
} | {
    protocol: typeof WEB_PROTOCOL;
    requestId: string;
    generation: number;
    kind: 'tool_calls';
    calls: {
        id: string;
        name: string;
        arguments: Record<string, unknown>;
    }[];
};
/** Check nesting and duplicate member names before JSON.parse can erase evidence. */
export declare function strictJson(text: string, maxBytes: number, maxDepth: number): unknown;
export declare class WebToolProtocol {
    readonly tools: readonly WebToolSchema[];
    private readonly validators;
    constructor(tools: readonly WebToolSchema[]);
    parse(text: string, requestId: string, generation: number, policy: WebBudgetPolicy): WebAnswer;
    prompt(requestId: string, generation: number, messages: readonly unknown[], bootstrap: boolean, system?: string, toolIdentities?: readonly WebToolIdentity[]): string;
    /** A correction of an already terminal answer, never a replay of the task. */
    repairPrompt(requestId: string, generation: number, attemptId: string, rejected: {
        text: string;
        sha256: string;
    }): string;
    repairable(error: unknown, original: string): boolean;
    /** Correction may change syntax only; it cannot manufacture or alter actions. */
    assertFaithfulRepair(answer: WebAnswer, original: string, requestId: string, generation: number, policy: WebBudgetPolicy): void;
}
/** The complete answer is validated before the first tool block becomes visible. */
export declare function answerBlocks(answer: WebAnswer): readonly Record<string, unknown>[];
//# sourceMappingURL=protocol.d.ts.map