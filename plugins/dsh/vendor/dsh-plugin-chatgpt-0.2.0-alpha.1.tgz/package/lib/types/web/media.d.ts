import type { GenerateOptions } from '@deepseek-ai/dsh-llm';
import type { ImageAttachmentRef } from '../convert/images.ts';
import type { WebMediaAttachment } from './browser/types.ts';
import { type WebImageLimits } from './image-policy.ts';
/** Local upload admission limits, not claims about the website's quota or context window. */
export declare const WEB_IMAGE_POLICY: Readonly<{
    absoluteLimits: Readonly<WebImageLimits>;
    mediaTypes: readonly ["image/png", "image/jpeg", "image/webp", "image/gif"];
    roles: readonly ["user", "tool"];
    fileInput: false;
    maxImages: number;
    maxImageBytes: number;
    maxTotalBytes: number;
    version: "web-images/1";
}>;
export declare function webImageRef(value: unknown): ImageAttachmentRef;
/** This checks the declared format; decoding and original digest validation belong to readImage. */
export declare function verifyImageSignature(data: Uint8Array, mediaType: ImageAttachmentRef['mediaType']): void;
export declare function webImageName(attachment: Pick<WebMediaAttachment, 'attachmentId' | 'mediaType' | 'messageIndex' | 'blockIndex' | 'role' | 'toolCallId'>, sha256: string): string;
/** Validate metadata before a browser can see a local filename. */
export declare function validateWebMedia(media: readonly WebMediaAttachment[] | undefined): void;
export declare function readWebMediaArtifact(item: WebMediaAttachment, directory: string): Promise<Buffer>;
/** Resolve before publishing any browser intent. The original host request retains its references. */
export declare function prepareWebMedia(options: GenerateOptions, directory: string, resolveAttachments: (() => unknown) | undefined, deadlineMs: number, configured?: WebImageLimits, fromMessage?: number): Promise<WebMediaAttachment[]>;
/** Order is kept in the original message manifest; the UI may reorder tiles. */
export declare function assertAcceptedWebMedia(media: readonly WebMediaAttachment[] | undefined, observed: readonly string[] | undefined): void;
//# sourceMappingURL=media.d.ts.map