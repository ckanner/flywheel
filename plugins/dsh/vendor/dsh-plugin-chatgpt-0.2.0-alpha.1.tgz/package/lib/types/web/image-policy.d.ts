export interface WebImageLimits {
    maxImages: number;
    maxImageBytes: number;
    maxTotalBytes: number;
}
export declare const DEFAULT_WEB_IMAGE_LIMITS: Readonly<WebImageLimits>;
/** Memory/upload admission ceilings, independent of account-dependent website limits. */
export declare const MAX_WEB_IMAGE_LIMITS: Readonly<WebImageLimits>;
export declare function imageLimits(value?: unknown): WebImageLimits;
//# sourceMappingURL=image-policy.d.ts.map