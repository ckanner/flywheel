import { type WebBudgetPolicy } from './policy.ts';
import type { WebConnection, WebContextPolicy } from './browser/types.ts';
import { type WebImageLimits } from './image-policy.ts';
export interface WebSettings {
    version: 1;
    enabled: boolean;
    activeConnection: string;
    connections: Record<string, WebConnection>;
    contextPolicy: WebContextPolicy;
    budget: WebBudgetPolicy;
    imagePolicy: WebImageLimits;
}
export declare function defaultWebSettings(stateDir: string): WebSettings;
export declare function parseWebSettings(input: unknown): WebSettings;
/** Profile-provided settings win; card settings otherwise persist in the plugin's private directory. */
export declare class WebSettingsStore {
    private readonly store;
    private readonly stateDir;
    private readonly configured;
    private readonly changed;
    constructor(stateDir: string, configured?: () => unknown, changed?: () => void);
    read(): Promise<WebSettings>;
    managedByProfile(): boolean;
    save(value: unknown): Promise<WebSettings>;
}
//# sourceMappingURL=config.d.ts.map