/** Includes the serialized authoritative request, tool arguments and commit metadata. */
export declare const WEB_RECORD_MAX_BYTES: number;
/**
 * Cross-process Lamport bakery lock over private local files. Publishing a
 * choosing marker before selecting a ticket closes the concurrent-entry race.
 * Unique claim names avoid the read-old-lock/unlink-new-lock (ABA) race when a
 * crashed owner is reaped. The lock directory is persistent and never removed.
 */
export declare function withOwnerLock<T>(directory: string, operation: () => Promise<T>, options?: {
    waitMs?: number;
    signal?: AbortSignal;
}): Promise<T>;
/** Small owner-only journal records. Names are hashes; records never contain executable paths. */
export declare class WebStore {
    private root;
    constructor(root: string);
    private directory;
    private path;
    read<T>(namespace: string, key: string): Promise<T | undefined>;
    write(namespace: string, key: string, value: unknown): Promise<void>;
    /** Short transactions may recover a dead lock owner; journal recovery remains a separate operation. */
    locked<T>(namespace: string, key: string, operation: () => Promise<T>): Promise<T>;
}
//# sourceMappingURL=store.d.ts.map