import type { WebArtifact, WebConnection, WebJournal, WebTurnRequest } from './types.ts';
export declare const digest: (text: string | Uint8Array) => string;
export declare function checkDeadline(deadlineMs: number, signal?: AbortSignal): void;
export declare function wait(ms: number, deadlineMs: number, signal?: AbortSignal): Promise<void>;
export declare function privateDirectory(path: string): Promise<string>;
/** fsync both data and directory. An ACK must never outrun its journal. */
export declare function atomicPrivateWrite(path: string, text: string): Promise<void>;
/** ESRCH is positive exit evidence; EPERM and PID reuse remain unknown/live. */
export declare function processExited(pid: number | undefined): boolean;
export declare function privateRead(path: string, maxBytes?: number): Promise<string>;
export declare class BrowserStore {
    readonly profilePath: string;
    readonly stateDir: string;
    readonly coordinationDir: string;
    private constructor();
    static open(connection: WebConnection): Promise<BrowserStore>;
    journalPath(id: string): string;
    create(journal: WebJournal): Promise<boolean>;
    get(id: string): Promise<WebJournal | undefined>;
    put(journal: WebJournal): Promise<void>;
    artifact(id: string, text: string): Promise<WebArtifact>;
    readArtifact(artifact: WebArtifact, maxBytes: number): Promise<string>;
    acquire(request: WebTurnRequest, recover?: boolean): Promise<{
        release: () => Promise<void>;
        retain: (reason?: 'awaiting-ack' | 'unresolved') => void;
    }>;
    assertConversationAvailable(conversationId: string, requestId: string): Promise<void>;
    holdConversation(conversationId: string, requestId: string): Promise<void>;
    releaseConversation(conversationId: string, requestId: string, onlyIfOwned?: boolean): Promise<void>;
    withAcknowledgement<T>(requestId: string, callback: () => Promise<T>): Promise<T>;
    releaseResolvedTurn(requestId: string): Promise<void>;
    assertExecutable(path: string): Promise<void>;
}
//# sourceMappingURL=storage.d.ts.map