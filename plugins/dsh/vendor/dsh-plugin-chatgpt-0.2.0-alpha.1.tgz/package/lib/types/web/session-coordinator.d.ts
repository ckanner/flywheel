import type { GenerateOptions } from '@deepseek-ai/dsh-llm';
import { WEB_PROTOCOL } from './policy.ts';
import type { WebSettings } from './config.ts';
import type { WebFacts, WebTurnRequest, WebTurnResult } from './browser/types.ts';
import type { WebMediaAttachment } from './browser/types.ts';
import type { WebRecovery } from './transport.ts';
export interface WebCallContext {
    kind: 'main' | 'compaction' | 'session-title' | 'one-shot';
    sessionId: string;
    executionDomainId: string;
    hostInvocationId: string;
    deadlineMs: number;
    requireIsolation: boolean;
    active: boolean;
    rawOptions: GenerateOptions;
    recovery?: {
        requestHeaderSeq?: number;
        surfaceSeqs: number[];
        originalCompactionId?: string;
        sourceEventSeqs?: number[];
    };
}
export interface WebTransportPort {
    run(request: WebTurnRequest): Promise<WebTurnResult>;
    acknowledge(requestId: string, receipt: {
        hostCommitId: string;
        responseDigest: string;
    }): Promise<void>;
    recover(requestId: string, options?: {
        observe?: boolean;
        deadlineMs?: number;
        preparedRepair?: {
            parentRequestId: string;
            parentDigest: string;
        };
    }): Promise<WebRecovery>;
    releaseForRepair?(requestId: string, input: {
        nextRequestId: string;
        responseDigest: string;
    }): Promise<void>;
    retire?(requestId: string, input: {
        responseDigest: string;
        reason: 'user-discarded-invalid-response';
    }): Promise<{
        at: number;
        responseDigest: string;
        reason: 'user-discarded-invalid-response';
    }>;
}
export interface WebReplayReference {
    protocol: typeof WEB_PROTOCOL;
    requestId: string;
    responseId: string;
    responseDigest: string;
    contentDigest: string;
    sessionId: string;
    executionDomainId: string;
    hostInvocationId: string;
    kind: WebCallContext['kind'];
    generation: number;
    conversationUrl: string;
    usage: 'unknown';
}
export interface WebDelivery {
    version: 1;
    reference: WebReplayReference;
    conversationKey: string;
    blocks: readonly Record<string, unknown>[];
    transportResult: Omit<WebTurnResult, 'text'>;
    committed?: {
        hostCommitId: string;
    };
    repairChain?: WebRepairAttempt[];
    recovery?: {
        request: Omit<GenerateOptions, 'signal'>;
        requestHeaderSeq?: number;
        surfaceSeqs: number[];
        originalCompactionId?: string;
        sourceEventSeqs?: number[];
    };
}
export interface WebRepairAttempt {
    requestId: string;
    parentRequestId: string;
    parentDigest: string;
    phase: 'prepared' | 'dispatch-intent' | 'not-dispatched';
    promptBytes: number;
}
export interface WebRetirement {
    at: number;
    responseDigest: string;
    transportRequestId: string;
    reason: 'user-discarded-invalid-response';
}
/** Ignore host-generated IDs and replay metadata, but preserve the complete model-visible content. */
export declare function projectMessages(options: GenerateOptions, media?: readonly WebMediaAttachment[], fromMessage?: number): readonly Record<string, unknown>[];
export declare class WebSessionCoordinator {
    private readonly store;
    private readonly transport;
    private readonly report;
    private readonly activity;
    private readonly resolveAttachments;
    constructor(stateDir: string, transport: WebTransportPort, report: (context: WebCallContext, requestId: string, facts: WebFacts, complete?: boolean) => Promise<void>, activity: (context: WebCallContext, value: unknown) => void, environment?: {
        resolveAttachments?: () => unknown;
    });
    private assertActive;
    run(context: WebCallContext, settings: WebSettings): Promise<WebDelivery>;
    private reject;
    private parseOrRepair;
    /** Called after the host stream has ended and its own transaction has flushed. */
    acknowledge(reference: WebReplayReference, blocks: readonly unknown[], hostCommitId: string): Promise<void>;
    delivery(requestId: string): Promise<WebDelivery | undefined>;
    private recoveryTail;
    private retainRetirement;
    recover(requestId: string): Promise<WebRecovery>;
    /** Only the explicit host/UI discard route calls this. No valid delivery is discarded. */
    retire(requestId: string, expectedDigest: string): Promise<WebRetirement>;
}
//# sourceMappingURL=session-coordinator.d.ts.map