/** Durable DSH images become request-local bytes; history keeps its references. */
import type { HarnessRequest } from '../adapter.ts';
/** Structural subset of the host's ImageAttachmentRef; the id is never a path. */
export interface ImageAttachmentRef {
    attachmentId: string;
    mediaType: 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif';
    bytes: number;
    width: number;
    height: number;
    name?: string;
}
/** The stable readImage contract shared by DSH rc.3 and current master. */
export interface ImageAttachmentReader {
    readImage(ref: ImageAttachmentRef, signal?: AbortSignal): Promise<{
        ref: ImageAttachmentRef;
        data: Uint8Array;
    }>;
}
export interface ImagePreparation {
    resolveModel(): Promise<{
        inputModalities?: readonly string[];
    }>;
    resolveAttachments?(): unknown;
}
/**
 * Resolve both user images and tool-result images, including PTC/LCU output.
 * No paths, bearer URLs or inline file objects are interpreted here. The host
 * store owns decoding/digest verification. Missing bytes or unsupported content
 * fail the turn before inference instead of replacing the content with text.
 */
export declare function prepareImages(request: HarnessRequest, options: ImagePreparation): Promise<HarnessRequest>;
//# sourceMappingURL=images.d.ts.map