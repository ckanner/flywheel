import type { GenerateOptions } from '@deepseek-ai/dsh-llm';
import type { HarnessRequest } from '../adapter.ts';
/** Translate one harness request into what the adapter reads. */
export declare function requestOf(options: GenerateOptions): HarnessRequest;
//# sourceMappingURL=harness.d.ts.map