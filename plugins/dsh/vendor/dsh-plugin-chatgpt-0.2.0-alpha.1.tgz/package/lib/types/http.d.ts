/** A fetch owned by one plugin instance, without changing Node's global dispatcher. */
export declare function createScopedFetch(proxyUrl: string | undefined): {
    fetch: typeof fetch;
    close: () => Promise<void>;
};
//# sourceMappingURL=http.d.ts.map