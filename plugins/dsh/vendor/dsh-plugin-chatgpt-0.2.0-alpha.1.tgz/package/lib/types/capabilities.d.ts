/**
 * Static adapter contract, not account entitlement or a successful live probe.
 * Import this subpath without mounting a DSH host or reading credentials.
 */
export declare const contentCapabilities: Readonly<{
    version: 1;
    imageInputRoles: readonly ["user", "tool"];
    imageSource: "durable-attachment-service";
    toolOutput: "text-or-responses-content-array";
    fileInput: false;
}>;
/** Shared by runtime admission and the browser settings card; contains no host code. */
export declare const webRequiredHostCapabilities: Readonly<{
    replayVeto: 1;
    durableResponseAck: 1;
    summaryRoute: 2;
    durableSummaryAck: 1;
    pressurePolicy: 1;
}>;
//# sourceMappingURL=capabilities.d.ts.map