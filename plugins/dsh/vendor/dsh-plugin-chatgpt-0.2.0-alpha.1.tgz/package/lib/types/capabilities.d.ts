/**
 * Static adapter contract, not account entitlement or a successful live probe.
 * Import this subpath without mounting a DSH host or reading credentials.
 */
export declare const contentCapabilities: Readonly<{
    version: 1;
    imageInputRoles: readonly ["user", "tool"];
    imageSource: "durable-attachment-service";
    toolOutput: "text-or-responses-content-array";
    fileInput: false;
}>;
//# sourceMappingURL=capabilities.d.ts.map