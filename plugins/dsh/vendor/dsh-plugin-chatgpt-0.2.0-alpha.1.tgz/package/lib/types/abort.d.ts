/** Caller cancellation is a terminal fact, never an authentication failure. */
export declare function assertNotAborted(signal?: AbortSignal): void;
/** Stop waiting promptly even when an optional host service ignores its signal. */
export declare function abortable<T>(pending: Promise<T>, signal?: AbortSignal): Promise<T>;
//# sourceMappingURL=abort.d.ts.map