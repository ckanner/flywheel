# dsh-plugin-chatgpt

[English](../README.md) | 中文

为 DeepSeek Harness 增加一个 Provider 路由 `chatgpt`，通过 ChatGPT 订阅使用模型。现有订阅模型采用 OpenAI 公布的 *Sign in with ChatGPT*（SIWC）流程和账号模型目录。实验性的 **GPT-6 Pro · Web** 模型使用独立的专用浏览器连接。路由命名为 `chatgpt`，因为内置 pi-ai 插件已占用 `openai`。

![把 DeepSeek Harness 接入 ChatGPT](../assets/screenshot-1-connect.png)

## Table of Contents

- [使用本包](#use-this-package)
- [实验性 ChatGPT Web Pro](#chatgpt-web-pro)
- [你会得到什么](#what-you-get)
- [实现说明](#understand-the-implementation)
- [延伸阅读](#further-exploration)
- [模型体验](#model-experience)
- [已知限制与待办](#known-limitations-and-deferred-work)
- [开发者说明](#dev-note)

-----

<a id="use-this-package"></a>
## 使用本包

### 安装到 profile

安装就是一行：

```text
dsh plugin --profile <name> add dsh-plugin-chatgpt
```

装完重启 harness：profile 在启动时组合。卸载：

```text
dsh plugin --profile <name> remove dsh-plugin-chatgpt
```

该包已在 npm 上，因此从 registry 安装就是全部步骤，不涉及任何构建：

```text
dsh plugin --profile <name> add dsh-plugin-chatgpt@0.1.9   # pin a version, or omit it for the latest
```

改从仓库地址安装则会从源码构建，而 pnpm 在构建脚本被允许之前会拒绝 git 依赖：`add https://github.com/ckanner/dsh-plugin-chatgpt` 会以 `ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED` 失败，直到在 profile 的 `pnpm-workspace.yaml` 里把 `dsh-plugin-chatgpt` 加进 `onlyBuiltDependencies`。

本包声明了 `dsh.bundle`，因此添加它会把该 bundle 追加到 profile 的 `dsh.profile.bundles`，并把它的行插入到组合中。可以不启动就检查这一层：

```text
dsh --profile <name> --dump-config   # shows a "# == dsh-plugin-chatgpt" layer
```

没有声明 `dsh.bundle` 的包不会激活任何层，`dsh plugin` 只会给出警告。

### 登录

打开**设置 → 模型**。本插件拥有一行 **ChatGPT**，该行的卡片提供 **Sign in with ChatGPT**。卡片会显示授权 URL 并支持选中复制；当浏览器无法访问回环地址时，可以粘贴最终的回调 URL；完成后卡片报告该账号——套餐、token 下次刷新时间、以及它提供多少个模型——并提供 **Sign out** 按钮。任何 token 都不会到达页面。

退出登录会先在授权服务器撤销可再生会话，再清除本地凭据；若服务器未能确认，卡片会如实说明。

如需只代理本插件在 DSH 进程中发出的请求，可在 DSH 进程环境中设置 `DSH_CHATGPT_PROXY_URL=http://127.0.0.1:7897`，或在本插件的 profile 配置中设置 `proxyUrl`，然后重启 DSH。代理 URL 须为 HTTP 或 HTTPS。它覆盖 OAuth 换取/刷新 token、发现与撤销、模型列表和推理请求，不修改 DSH 全局网络设置，也不改变浏览器访问授权页的连接。代理必须能从运行 DSH 的机器访问；`127.0.0.1` 指的是那台机器。留空则直连。`403 unsupported_country_region_territory` 是服务端拒绝；代理能连通并不代表登录获得许可。

显式配置的 profile `proxyUrl` 优先于 `DSH_CHATGPT_PROXY_URL`；将其设为空字符串会选择直连。

![模型页上的 ChatGPT 行，账号从这里登录](../assets/screenshot-2-models-page.png)

无头 harness 不需要浏览器，可以直接驱动同一个会话对象：

```js
import { ChatGptAuth } from 'dsh-plugin-chatgpt/src/auth/manager.ts'

const auth = new ChatGptAuth({
  stateDir: `${process.env.DSH_HOME ?? `${process.env.HOME}/.dsh`}/chatgpt-subscription`,
  agentNameHint: 'DeepSeek Harness',
})

const attempt = await auth.begin()
console.log('Open this URL in your browser:\n' + attempt.authorizationUrl)

// The browser redirects to the loopback listener this attempt bound. If the
// redirect cannot reach it — a headless host, or a blocked popup — paste the
// final URL back instead.
// await attempt.submit('<the full redirect URL from your browser>')

const credential = await attempt.result
auth.adopt(credential)
```

授权凭据以仅属主可读的权限存放在 `stateDir` 下。`attempt.submit()` 对格式错误或不匹配的值会拒绝，并让本次尝试保持存活，所以粘贴错了可以改正重试。

-----

<a id="chatgpt-web-pro"></a>
## 实验性 ChatGPT Web Pro

`0.2.0-alpha.1` 开发候选版本将 `chatgpt` / `gpt-6-pro-web` / `pro` 接入 DSH 原生模型和档位控件，尚未发布到 npm。Web 模型默认关闭，需要针对 commit `9c2670d3bce5275e0d1610272958121af87787bb`（`0.2.2-rc.5`）维护的精确基线 [DSH 兼容补丁](../compat/README.zh.md)；只在原版 SDK 中安装插件不会补出这些宿主扩展。

在现有 ChatGPT Provider 卡片中，为 Chrome、专用浏览器 profile 和单独的私有恢复目录配置绝对路径。保存后点击 **Connect / verify login**，在该浏览器中手动完成网页登录，再次点击 **Connect / verify login**。启用 **GPT-6 Pro · Web**，并在普通模型选择器中选择 **Pro**。这条连接与 SIWC 登录及其账号目录模型相互独立。

默认 Web 上下文为每个会话代次独立的私有 `project-only` 项目。DSH 负责本地工具和权限，在执行工具前验证完整结构化响应，并让唯一压缩引擎使用 Web 压力与摘要策略。兼容轮次发送增量历史，代次迁移依据 DSH 的权威历史。模型可按调用方的权限用于规划、review 和执行角色。

被中断的 Web 工作分别保留派发、结果、本地清理和远端生成事实。检查恢复不发送 prompt，也不执行工具。显式采纳已捕获响应可能执行其中已验证的工具，但不会自动请求下一次模型回答。远端或工具结果未知时阻断执行域；网页用量未知就保持 unknown。

macOS Desktop 使用已登录账号访问当前 ChatGPT 网页的端到端验收仍未完成。已实现持久图片上传、有界语法修正及完整拒绝响应的显式丢弃，并覆盖离线 fixture。模型是否实际消费图片仍未验证；网页上下文已满或项目创建存在歧义时保守阻断。启用候选版本前，请阅读完整的 [Web Pro 设置、预算、恢复与验收边界](web-pro.zh.md)。

-----

<a id="what-you-get"></a>
## 你会得到什么

一个 Provider 路由，像内置 Provider 一样出现在 **设置 → 模型** 中。现有 SIWC 模型跟随账号目录，显式启用的 Web 模型显示在同一处。在那里选择模型，就会将其加入普通模型选择器。

模型元数据来自账号列表。内置目录现已描述 **GPT-6.2 Astra** 与 **GPT-6.2 Sol**（`gpt-6.2-astra`、`gpt-6.2-sol`）的 1,050,000 token 上下文、128,000 token 输出上限和推理级别；当登录账号的目录公布这些模型时，它们会出现在选择器中。Astra 或 Sol 可用时，选择器还会提供它们的 **UltraFast** 服务档变体（`gpt-6.2-astra-ultrafast`、`gpt-6.2-sol-ultrafast`），请求会发送 `service_tier: "ultrafast"`，费用更高。适配器默认跟随各模型在账号目录中声明的上下文窗口，并在目录刷新时采用更新值。可用 `contextWindowLimit` 设置全局预算，或用 `modelContextWindowLimits` 为指定模型设置预算；显式配置会按填写的值采用。登录仍在这一行的卡片上。

例如，在插件配置中加入以下字段，即可把没有单独配置的模型的 DSH 上下文预算设为 1,000,000 token，即使目录声明的最大值是 872,000 也不会缩小。删除此字段后，这些模型恢复账号默认值。这些设置与 Codex 配置相互独立。DSH 仍会为压缩预留空间；它们不会改变服务端的请求限制。

```yaml
contextWindowLimit: 1000000
```

单独配置模型预算时，以完整模型 ID 为字典键。优先级为指定模型配置、全局预算、账号默认值。下面的示例中，Astra 使用 1,000,000，Sol 使用 800,000，其余模型使用 500,000。全局字段是可选的；省略它可让其余模型跟随各自账号默认值。

```yaml
contextWindowLimit: 500000
modelContextWindowLimits:
  gpt-6-astra: 1000000
  gpt-6.1-sol: 800000
```

修改会在 DSH 下次解析模型时生效。删除某个模型项后，该模型恢复当前全局预算；未设置全局预算时则恢复账号默认值。字典键按区分大小写的完整模型 ID 匹配，不使用显示名称或通配符。

![模型选择器里，账号自己的模型列在 ChatGPT 分组下](../assets/screenshot-3-model-picker.png)

这个安装可以花掉的套餐份额是在 ChatGPT 设置里按应用单独设定的：

![该应用在套餐中的额度占比，在 ChatGPT 设置里逐应用设置](../assets/screenshot-4-app-limits.png)

-----

<a id="understand-the-implementation"></a>
## 实现说明

<details>
<summary>实现细节 — 点击展开</summary>

| 源码 | 职责 |
|---|---|
| `cordis.patch.yml` | 配置层：插入一行，指明路由与状态目录。 |
| `src/index.ts` | 插件入口：持有适配器实例并注册路由。 |
| `src/auth/protocol.ts` | 所公布流程的精确端点、scope 与 loopback 规则。 |
| `src/auth/sign-in.ts` | 授权：loopback 监听与粘贴重定向 URL，两条路径并行竞争。 |
| `src/auth/manager.ts` | 已存凭据、当前账号，以及单飞刷新。 |
| `src/auth/store.ts` | 原子写、仅属主可读的凭据存储。 |
| `src/api/events.ts` | 解码 Responses 事件流及其失败形态。 |
| `src/convert/request.ts` | Harness 请求转 Responses 请求体，含该路由拒收的字段。 |
| `src/convert/harness.ts` | DSH 请求边界，含会话身份与回放元数据。 |
| `src/convert/images.ts` | 解析用户/工具持久图片、保留宿主 offload 决策，在推理前拒绝不支持的内容。 |
| `src/convert/replay.ts` | 原生输出校验及限定账号和模型的 DSH 回放封装。 |
| `src/convert/blocks.ts` | 线上事件转 Harness 的编号内容块。 |
| `src/api/client.ts` | 两次 HTTP 调用：列出模型、跑一轮。 |
| `src/models/describe.ts` | 可用性与容量，优先采用账号所报的值而非内置目录。 |
| `src/adapter.ts` | provider 契约面向 Harness 的那一半。 |
| `src/web/host.ts` 与 `src/web/integration.ts` | Web 绑定、执行域归属、公共 DSH hooks 与恢复采纳。 |
| `src/web/session-coordinator.ts` 与 `src/web/protocol.ts` | 浏览器代次增量历史、持久交付与本地工具响应整包校验。 |
| `src/web/transport.ts` 与 `src/web/browser/` | 专用 Chrome 控制、实际活动、不可变响应 artifact 与独立清理事实。 |

代码实际强制的三条 SIWC 规则：

- 请求绝不携带 `temperature`、`max_output_tokens`、`top_p`、`truncation` 等套餐额度路由拒收的字段。它们被显式列在 `REFUSED_FIELDS` 中，因此不会被误加回来。
- `response.completed` 是唯一成功的终态。没有它就以结束的流算作错误，因为「被截断却看起来已完成」的回答比一个可见的失败更糟。
- **运行时读取账号元数据。** 插件使用当前账号的授权请求 `GET /v1/models`。内置目录补充缺失的描述，带测量日期的清单可加入未列出的模型。模型可用性、容量和报告给 DSH 的上下文预算是不同的概念。

</details>

-----

<a id="further-exploration"></a>
## 延伸阅读

- [Sign in with ChatGPT: OSS token sharing](https://developers.openai.com/siwc/token-sharing-open-source) — 本包所实现的公开流程。
- [Models and inference](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference) — 列表与请求约束。
- [Preview limitations](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations) — 该路由目前尚不具备的能力。

-----

<a id="model-experience"></a>
## 模型体验

本节的上下文与缓存行为描述现有 SIWC 模型。这个 bundle 插入一个 Provider 行，由该行的插件负责模型行为；配置层自身不增加 prompt、工具或上下文。Web Pro 使用独立的浏览器与结构化工具契约，详见其使用说明。

### 请求上下文与条件

#### 模型能看到什么

每轮发往 `chatgpt` 的请求都保留消息、助手内容块、工具调用及结果的原始顺序。system 与 developer 指令在原位置作为 developer 消息发送，并向 DSH 声明在历史中追加系统提示更新。助手的原生输出（含加密推理）通过 DSH 的 `replayState` 保存；授权、路由、模型一致且内容未变化时，完整回放这些数据。

#### Token 影响

可变。可见上下文来自 DSH；回放加密推理也可能计入输入 token，可读的思考摘要不能替代它。适配器不自行截断历史，由 DSH 按报告的上下文预算执行压缩。输出预留保持低于该预算，但这条路由不接受输出 token 上限。

#### KV Cache 影响

适配器在多轮工具调用和会话恢复中保留可复用前缀及不透明推理状态。本地授权命名空间、client 注册、端点、provider、会话 ID 和调用用途的固定长度哈希同时用于 `prompt_cache_key` 与 `session_id` 请求头；刷新 token 不改变它。重新授权会生成新命名空间，旧凭据在首次读取时补齐；无会话 ID 的调用则省略两者。GPT-5.6 及以后由 OpenAI 自动处理缓存路由，key 不保证命中。SIWC 要求 `store: false` 并在 HTTP 请求中携带完整历史，响应存储与提示词缓存是两件事。与 Pi 的公共 SIWC 路线一样，这里继续省略缓存保留期与 options，等待按模型和路由验证。参见[官方缓存指南](https://developers.openai.com/api/docs/guides/prompt-caching)及[推理回放说明](https://developers.openai.com/api/docs/guides/reasoning#preserve-reasoning-without-stored-responses)。

## 已知限制与待办

- **Web Pro 是实验性的独立连接模型** — 其候选版本、宿主补丁要求、未知用量、有界图片输入、恢复阻断与未完成的真实验收均记录在 [Web Pro 使用说明](web-pro.zh.md)。SIWC 的上下文覆盖、图片支持、代理设置和缓存计数不能证明 Web 通道具备相同能力。

- **已有历史仍可使用** — 旧会话缺失的加密回放数据无法恢复，但可见消息和工具记录会按顺序回放。对于被编辑、裁剪、来自其他适配器、格式错误或不兼容的元数据，会退回可见历史，避免重新引入已丢弃内容。此集成要求 DSH 宿主支持 `finish.replayState` 和 `systemPromptUpdate: "in-history"`；参见[回放设计与验证方案](cache-replay.md)。

- **UI 一次只展示一个账号** — 宿主为每个已授权账号分别保存，并可按 subject 退出其中任一个，但卡片只显示与切换当前账号，因此添加第二个账号需要先退出当前账号。
- **图片需要宿主附件服务与视觉模型** — 用户附件及工具结果图片（包括 PTC/LCU 截图）会被解析为本次请求的字节，并作为 Responses 图片内容发送。工具结果保留 call ID、文本/JSON、图片顺序及错误状态。宿主明确 offload 的图片仍表示为文本；不可读取的附件、不支持的角色/模型及原始文件块会在推理请求前失败。参见[内容契约与本地验证](multimodal-content.md)。本地请求测试不认证某个订阅账号的在线图片接收能力。
- **套餐额度路由仍处于 preview** — computer use、Code Interpreter、file search、hosted MCP、图像生成与 `tool_search` 无论本插件发送什么都会被上游拒绝；而 `multi_agent`、`temperature` 和 `max_output_tokens` 属于必须省略的十五个字段之列。
- **名单混合了两个权威性不同的来源** — 账号的列表提供「被宣传的」模型，并附带接口自己的元数据；实测可用但列表未提及的模型来自 `src/models/served.ts`，并记录测量日期。若列表在测量过期后发生变化，会显示出已经不再应答的额外模型；`includeUnlisted: false` 可把名单收窄为账号自己的回答。
- **一个安装对应一个 host id** — host id 以状态目录为作用域。两个 profile 共用一个目录，对 OpenAI 而言就是一个安装；两个目录就是两个，各自需要单独授权。
- **`agent_name_hint` 是常量** — 默认 `DeepSeek Harness`，可按 profile 覆盖；但它是人类在授权页上读到的名字，也是 OpenAI 记录的此应用身份，因此改动它会改变既有授权凭据的归属。

- **上下文增长受可配置预算约束** — 默认跟随各模型的账号目录窗口，不设置统一固定上限。`contextWindowLimit` 和 `modelContextWindowLimits` 中的每个值都必须是至少 1,024 的安全整数。指定模型值优先于全局值；参照 Pi 的覆盖逻辑，两者均优先于目录元数据，且不按目录最大值缩小。未显式配置且账号元数据缺失时，使用内置回退值。实际触发点与预留空间仍由 DSH 的压缩策略控制。这是上下文预算，不是消费硬上限或缓存命中目标。

- **退出登录是两件事，卡片会说明发生了哪一件** — 可再生会话会先在授权服务器撤销，再清除本机凭据，因为本地删除的授权凭据可能在别处仍然有效。服务器无法送达时，本地登出仍然完成，而结果会明确说明远端撤销未被确认。额度耗尽时会指向 ChatGPT 自己的用量页面，并说明该错误码既不指明原因、也不给出重置时间：套餐的共享用量与应用级限制都可能是原因，因此网站上看起来远未接近上限的套餐与一次拒绝可以同时为真。

- **每个 Config 字段都是 `volatile()`，这是有实际作用的** — Harness 只根据 volatile 字段构建插件的 settings 表单，没有 volatile 字段的插件就不会有 settings 命名空间。而模型页只为命名空间存在的行渲染 provider 行，所以没有 volatile 字段的 schema 会让这条路由、以及依附其上的卡片，根本无法显示。volatile 字段在使用处以 `.get()` 读取，而不是被当作值捕获。

- **客户端半会自己挂载它的 Remote 命名空间** — 打包的第三方插件无法自行访问 `ctx.remote.<namespace>`：Gateway 只从生成出来的 descriptor contribution 安装命名空间，而承载这些内容的包是在构建期按固定的 workspace 包列表生成的。没有任何机制为树外包生成它，生成器也未发布，因此本插件在 `src/remote-methods.ts` 里自行挂载该 contribution。有测试会读取控制器源码，在两边列表不一致时失败——因为只在一边新增方法，会在用户点击的瞬间才报错。

- **登录后会向浏览器通告新的模型清单** — 模型选择器会缓存宿主 catalog，只在宿主声明有变化时重载，因此在登录时把空清单填满的插件必须发布 `llm/adapters-updated`。否则模型确实在服务，却永远不会出现在选择器里——看起来就像 provider 坏了。账号卡片会报告该账号提供多少个模型，或说明清单为何读不到。

- **缓存统计来自实测，不作预测** — 百分比按服务端计数计算为 `cacheReadTokens / (inputTokens + cacheReadTokens + cacheWriteTokens)`。旧版本曾重排工具历史并丢弃原生推理，其低命中率不能证明 SIWC 存在固有上限。前缀保持测试不等于线上命中率测试；应固定模型与推理级别，预热后比较缓存读写、总输入、延迟和额度影响。

- **每个安装各自注册一个 client** — ChatGPT 设置里每个注册对应一行应用，名称取自 `agent_name_hint`；本插件在登出后仍保留「账号 ↔ client」的映射，因此同一安装下次登录会复用原来那一行，而不是再添一行。第二个 state 目录对 OpenAI 而言就是第二个安装，会单独注册；删除某个 state 目录即等于忘记那个安装。

## Dev Note

```text
npm test          # node --test, no build step
npm run typecheck # entry point checked against dev-types/ shims
npm run build     # tsc emits the host half and the declarations, esbuild the browser bundle
npm run verify:harness -- /path/to/deepseek-harness # actual DSH assembler, offline
node scripts/verify-web-harness.mjs /path/to/patched/deepseek-harness # actual Web host/compaction with offline browser pages
npm run verify:install # install candidate with real rc.3 host peers; registry access required
```

`dev-types/` 存放 Harness 的 LLM 与 Cordis 接缝的开发期声明，转录自 Harness 源码。它们不发布、也从不随包分发；宿主以 peer dependency 的形式提供真实包。在真实 Harness 中做端到端挂载仍然是权威的验证方式。

当上游目录更新时，重新生成模型目录：

```text
node scripts/generate-model-catalog.mjs /path/to/@earendil-works/pi-ai
```

### 发版

合并 PR 不会自动发布包。先把版本变更（`package.json` 与 `package-lock.json` 同步）合并到 `main`，再推送匹配的 `v<version>` 标签。发布流水线只接受已存在、指向本次流水线精确提交且位于 `origin/main` 的标签，并在发布前重新核对远端标签对象。当前开发版本在 review、合并后可按以下步骤打标签：

```text
git switch main
git pull --ff-only
git tag v0.2.0-alpha.1
git push origin v0.2.0-alpha.1
```

发布工具链固定为 Node `24.22.1` 与 npm `12.2.1`，依赖按已提交的 lockfile 安装。现有单元测试、真实 DSH 契约、构建、类型、客户端、双语文档与 macOS/Linux Web 宿主门禁仍然必需；PR CI 矩阵另覆盖 Node 22 兼容性。源码只打包一次，先核对真实压缩包的内容和真实宿主 peer 安装，再将同一份压缩包发布到 `candidate-<version>` 标签（版本号中的点替换为连字符）。

随后流水线从公共 registry 获取该精确版本，核对 SHA-512 完整性与字节，再次进行消费者安装检查。通过后才把 `-alpha.N` 提升到 npm `alpha`、`-beta.N` 提升到 `beta`、`-rc.N` 提升到 `rc`，或把稳定版 `X.Y.Z` 提升到 `latest`。Alpha/beta/rc 的 GitHub Release 显式标记为预发布，不会替换稳定版 latest Release。安装预发布版时请使用精确版本或相应渠道，例如 `dsh-plugin-chatgpt@0.2.0-alpha.1` 或 `dsh-plugin-chatgpt@alpha`。

重试只有在 registry 完整性和下载压缩包都与已验证的源码候选包一致时，才复用已发布版本。GitHub Release 附带的正是这份 registry 字节；已有附件必须一致，绝不会被覆盖。Release 会先创建为草稿，上传压缩包经下载核验后，才发布同一个 release ID。创建、上传或发布中断后，重试可以继续完成身份一致的草稿；附件存在冲突或仅部分上传时，对账会停止。来源不同、远端标签变化、渠道已有更新版本、Release 冲突、认证失败、超时或 registry 响应格式异常都会中止流水线。只有正常退出进程返回的结构化 npm `E404` 才能证明版本不存在。

发布与渠道提升使用仓库的 `NPM_TOKEN` secret，或为 `release.yml` 配置的 npm trusted publishing；GitHub Release 使用本次运行的 token。首次运行前，应提供有权发布本包并更新其 dist-tag 的 token，或为 trusted publisher 同时允许直接 `npm publish` 和 **Allow npm dist-tag**。[dist-tag 权限](https://docs.npmjs.com/trusted-publishers/#managing-dist-tags-with-trusted-publishing) 是独立授权，默认关闭；已有 publisher 也须启用。固定的 npm `12.2.1` 已满足 CLI 版本要求。只有 publish 权限时，候选版本可能已发布，但流程会在 `promote` 失败，公共渠道保持不变，GitHub Release 尚未完成。补齐 publisher 权限或提供适用的 token 后，可重试同一标签。读取公共标签和 `npm whoami` 都不能证明 trusted publisher 具有写权限。

重试时以已有发布标签运行 `gh workflow run release.yml --ref v0.2.0-alpha.1`。手动从分支运行会被拒绝，不会创建标签。npm 包包含维护中的 [DSH 兼容源码](../compat/README.zh.md)，安装插件不会自动应用宿主补丁，也不会生成兼容桌面端安装包。
