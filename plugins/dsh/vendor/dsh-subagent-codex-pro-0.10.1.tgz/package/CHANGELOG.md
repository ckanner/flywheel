# Changelog

## 0.10.1 (source candidate)

- Forward coalesced, metadata-only activity from the active root and owned child turns through the public machine API and independent supervisor. Keep activity separate from text output, durable ACKs and receipts; do not synthesize heartbeats or count unrelated/stale turns.
- Observe owned child activity with default native tools even when no native profile is supplied, without changing Codex configuration or inventing requested-native evidence.
- Require collaboration ancestry to belong to the active parent turn and match its sender. Stale parent turns or foreign senders cannot establish activity ownership.
- Relay the same activity from Host provider, foreground/PTC and background tool calls through the optional versioned Flywheel host service, using the actual DSH Agent and per-call identity.
- Bound individual protocol frames and retained answer/image/early-message data instead of cumulative valid stream traffic; preserve UTF-8 framing, reject oversized unfinished frames and bound stderr display without cancelling useful work.
- Include native ownership and usage replay in the retained-data allowance, copy only required identities/counters, and use one bounded JSONL buffer for arbitrarily fragmented reads.
- Name new persistent machine threads with an explicit readable threadName or workspace-based fallback. Normalize desktop task labels and preserve existing/user-edited titles on resume without changing ephemeral persistence.
- Require confirmed naming before a new persistent machine task is dispatched. A rejected or unconfirmed write returns a recoverable, not-dispatched failure with the known thread and independent cleanup evidence; direct desktop naming remains best effort.
- Keep observed child turn and closure facts authoritative over late creation snapshots, including V2 started markers. Preserve real subsequent turns and queued follow-up work in the native completion gate.
- Preserve parent-only child terminal evidence across repeated creation snapshots, even before a child turn ID is known; keep missing turn identity and usage unknown.
- Exercise real public machine/supervisor/guardian and registered desktop tool paths for long streams exceeding 32 MiB, child-only progress, stale/foreign events, genuine silence, cancellation, recovery, naming and retained-output limits. No new registry publication or live-account acceptance is claimed.

## 0.10.0 (source candidate)

- Add a real DSH native settings page, a live Config schema, whole-object per-call overrides and explicit null/off semantics. Keep default inheritance distinct from off.
- Wire desktop/PTC delegation and the Host provider through native validation, app-server configuration, child lifecycle and receipts; invalidate implicit session reuse when the effective binding changes.
- Add a dedicated fresh, read-only subagent_codex_review tool. Review cannot become an ordinary delegation default or silently ignore prompt/schema/resume arguments.
- Preserve native receipts in direct tools and background results, report bounded Host evidence, reject unfinished children, and retain image attachment blocks in PTC rendering.
- Validate schemas with the actual DSH closed subset and PTC SDK generator, validate serialized settings before save, and exercise real React revisions/off/reset plus plugin-to-process cancellation and cleanup.

- Add optional native capability v1 controls, verified scoped Codex configuration, V2 backend selection and explicit off across both backends.
- Preserve full native agent tools/permissions; collect owned child states, model evidence and deduplicated baseline-aware usage without mixing observations into the model answer.
- Add independent fresh-thread native review, correct review model/effort configuration and explicit native combination constraints.
- Propagate child events and terminal native evidence through the existing guardian, machine supervisor and read-only recovery lifecycle.
- Keep the current child turn authoritative under replay and late completion, including failed terminal turns.
- Keep protocol 1, authentication and absent-native behavior compatible. See [native capabilities](docs/native-capabilities.md) for exact evidence and validation limits.

## 0.9.0 (2026-11-12)

- Add lifecycle v1 with awaited configuration-checked thread-ready, dispatch-intent,
  dispatch-possible and turn-accepted checkpoints. A failed ACK cannot silently
  continue a turn; the possible-send window remains explicitly ambiguous.
- Add a separately grouped machine supervisor for opted-in lifecycle/journal
  calls. Caller death aborts native work and persists the original complete
  receipt; a lost terminal notification never rewrites a completed run as cancelled.
- Add exclusive private, atomic and fsynced invocation journals plus a read-only
  recoverMachine entry. Missing/corrupt evidence remains unknown, not a retry.
- Record typed execution.dispatch without inferring model execution from a PID,
  progress text, a thread ID, or cleanup success. Require explicit boolean
  persistence evidence on thread/start.
- Exercise real checkpoint rejection, caller process-group SIGKILL, original
  receipt recovery and built-package lifecycle paths with offline app-server
  fixtures. No new live-account or installed desktop acceptance is claimed.

## 0.8.0

Released 2026-11-03.

- Add the public protocol-1 machine API and single-request CLI, preserving run identity, actual process facts, configuration and usage completeness without changing DSH Host result shapes.
- Supervise POSIX Codex groups with an IPC-lifeline guardian so caller death triggers bounded cleanup; never substitute supervisor exit for the actual Codex exit. A live caller's normal stop now exits the guardian as soon as the app-server is gone instead of paying the full dispose grace; caller-death cleanup keeps the full grace.
- Confirm cleanup from a final independent absence probe, retaining unknown status for EPERM while allowing a later ESRCH to resolve a Darwin exit race.
- Reject missing or conflicting effective configuration before sending a task. Preserve full sandbox policy and request-only effort evidence.
- Default to workspace-write + never; full access remains explicit and tool overrides cannot expand configured permissions.
- Align DSH rc.5 capabilities, reject unsupported provider/maxTokens overrides, and reject dispose when cleanup is unconfirmed.
- Correct malformed, early, foreign-turn and resumed token-usage accounting; unknown counters and costs are not zero. A resumed thread's historical replay is adopted even when it arrives after turn/start; a different-turn snapshot after live current-turn usage remains unattributed.
- Add Ubuntu/macOS Node22/24 CI, real packed-package/public-entry tests, migration notes and Flywheel/PR workflow documentation.
- Accept the protocol-defaulted `cacheWriteInputTokens`, preserve bounded approval diagnostics, gate the model-facing permission enum to the configured policy, handle CLI EPIPE, and retain startup failure causes in machine receipts.
- Real Codex 0.165 app-server live cases pass 4/4 (including resume/usage replay); real DSH Desktop smoke is not claimed.

## 0.7.0

Adapter reliability and observability hardening. Released 2026-11-01. The
user's global Codex login/config is untouched.

- **One deadline for the whole delegation.** A single derived abort signal now
  covers `initialize`, `thread/start`/`thread/resume`, `thread/name/set`, and the
  turn. Startup hangs can no longer outlive `runTimeoutMs`; `0` still disables
  the deadline. Timeout, caller cancellation, protocol failure, and process exit
  are classified distinctly, settlement occurs once, and teardown is idempotent.
  An auto-resume retry inherits the original absolute deadline instead of a
  fresh full timeout.
- **Resume applies requested configuration.** On the 0.165 protocol,
  `thread/resume` sends explicit model, cwd, and permission overrides and checks
  the response's effective `model`, `cwd`, `approvalPolicy`, `approvalsReviewer`,
  and `sandbox`. A mismatch fails an explicit resume; a remembered session
  thread with incompatible configuration is replaced by a new thread under the
  same deadline. `thread/start` no longer sends `reasoningEffort`, which is not
  in the 0.165/0.166 start parameters; thinking remains a per-turn `effort`.
- **Read-only review mode.** Added `read-only` (`approvalPolicy: never`,
  `sandbox: read-only`), available in configuration and per-call as
  `permission_mode`. `never` remains only "do not prompt"; the default
  write-capable mode is unchanged.
- **Token usage and rate limits.** `thread/tokenUsage/updated` is folded from
  thread-cumulative snapshots into a run delta: resume replays are baselines,
  duplicates/out-of-order snapshots never add, missing baselines are `unknown`
  rather than zero, and observed usage survives failure/timeout/cancel.
  `account/rateLimits/updated` is stored separately from token usage and is
  never merged into it.
- **Result envelope separated.** Final text, structured result, thread id,
  usage, configuration, diagnostics, cleanup, and schema errors are distinct
  fields on the internal outcome. A schema-constrained answer stays pure JSON:
  the persistent-thread marker is not appended to it, and parse/schema
  verification is fail-closed. The DSH provider/tool/job contracts are
  unchanged; they carry no usage field, so usage/rate limits are reported in
  the outcome and diagnostic log rather than invented host fields.
- **Provable process cleanup.** POSIX children are process-group leaders;
  teardown signals the group, escalates to `SIGKILL` after a separate grace, and
  verifies the group is gone. Unconfirmed cleanup is reported, including for
  descendants that ignore `SIGTERM`; there is no global `killall`.
- **Tests and docs.** Added fake-app-server lifecycle tests, usage-accounting
  tests, structured-verification tests, resume-override tests, result-marker
  tests, and permission-forwarding tests. Updated README and Chinese README to
  match the 0.165 baseline and to separate offline, real-Codex, and real-DSH
  desktop validation. Validation baseline: installed Codex 0.165.0; live
  app-server cases 4/4 passed and the `codex exec` live case passed; official
  0.166.0 schemas reviewed, no 0.166 runtime executed; real DSH desktop smoke
  still not run.

## 0.6.4

Tests only; the shipped runtime is unchanged.

The live suite still read `delegateOnce` as if it returned the answer string, but
the function has returned `{ text, threadId, images }` since persistent threads
landed. Both live cases therefore failed their assertion even though the real
app-server turn had answered correctly; they now read `outcome.text`.

Verified against `@openai/codex` 0.164.0: the hermetic suite passes, and both
live cases complete a real turn (model + reasoning effort, and the defaults).
The 0.164.0 app-server protocol keeps every message phase and server request
this wire handles; it only adds optional `TurnStartParams` fields
(`parentTurnId`, `rootTurnId`) and two notifications this provider ignores.

## 0.6.3

A missing Codex executable now fails one delegation instead of the Host.

`spawn codex` reports `ENOENT` when the executable is not on the Host's `PATH`
— for example after a Node version switch through a version manager drops the
global npm install. The run failed correctly, but the process-cleanup path
attached its termination-timer cleanup with a bare `finally()` on the
already-rejected exit promise. That derived rejection was unhandled, and the
Host's global unhandled-rejection handler escalates it to a fatal load failure:
DSH Desktop exited instead of returning the delegation error, taking every
running session with it. Cleanup now handles both settlements, so the only
observable result is a failed run with its diagnostic.

Add a regression test: a delegation whose executable is missing rejects
without leaving an unhandled rejection behind.

The README now records how to point `command` at an absolute executable for a
Host whose launch-time `PATH` does not carry the global install.

## 0.6.2

Compatibility with DSH 0.2.1's subagent seam and the Codex app-server it drives.

- Accept the `partial_answer` agent-message phase. It is retained as a fallback answer and selection stays
  final → partial → unphased, matching the official provider as of DSH 0.2.1. A turn that emitted only a partial
  answer no longer fails with `unknown agent message phase "partial_answer"`.
- Use the working directory the shared subagent service selected (`request.cwd`) when one is supplied, falling
  back to the parent session's directory. Provider-row and workflow dispatch now honour it; this plugin's own
  tool path is unchanged because it already resolves the directory itself.
- Document the changed official activation model: since DSH 0.2.1 the official `subagent_codex` is a global Host
  tool, and this plugin's per-Agent registration shadows it for the configured presets rather than a per-preset
  disabled row switching it off. A same-scope duplicate still collides, so the profile must not enable a
  same-name `tool-subagent` row beside this provider.

## 0.6.1

The deadline is now a parameter, so a prompt can set it.

`timeout_ms` overrides the configured `runTimeoutMs` for one delegation, and `0` means no deadline at all. The
default was already a plugin setting, which made it usable only by editing a profile and restarting — plugin
configuration is not hot-reloaded, and a model cannot pass a value that no parameter declares. Now the routine
that needs tens of minutes and the lookup that needs seconds can be told apart by the model itself, in the same
turn, without a restart.

`0` is forwarded rather than treated as "unset": asking for no deadline is a different request from asking for
the configured one.

The README now records how a profile overrides this package's row. The loader replaces the whole `config` map
rather than merging it — read out of `applyEntryPatches`, which assigns each top-level field in turn, `config`
being one of them — so overriding `runTimeoutMs` without restating `presets` mounts a row that matches no
preset and therefore serves no session. The failure is silent, the log line names the presets actually received,
and both READMEs now carry the wrong and right shapes side by side.

Also corrects a contradiction in the capabilities table: `outputSchema` was listed as ✅ and, three rows later,
still inside the ❌ row left over from 0.6.0. The three refusals that remain — `maxDepth`, persona, `toolFilter`
— are now described as not applicable rather than not implemented, with the reason: a Codex delegation is a
leaf with no DSH child to cap, its tools are Codex's own rather than this harness's, and a persona is a system
instruction for a child agent where this one already takes the task in `prompt`.

## 0.6.0


The answer can now be made machine-readable, and the capability table stops understating what this provider can
do.

`output_schema` hands Codex a JSON Schema its final answer must conform to, so a later step reads the answer
instead of parsing prose and hoping. The schema must be object-rooted, the same rule the harness applies to a
schema it passes a provider. The app-server enforces it: a measured run returned
`{"verdict":"pass","reason":"…","count":2}` with no extra keys and every required one present. The answer still
arrives as text, and that text is JSON.

It is sent on the **turn**: the same field on `thread/start` is accepted and then silently ignored — measured
both ways, and the thread-level form produced prose. Another silent-ignore, like a missing `localImage` path.

`capabilities.outputSchema` is now `true` rather than `false`, because it is now honored: a schema the harness
puts on a `tool-subagent` row reaches Codex, and the answer is parsed so the caller receives `structured`
alongside the text. Declaring it while ignoring it would have been worse than the old `false`.

The `apply` diagnostic line now names the version, so a restart's log says which build is loaded. It previously
could not tell two releases apart: 0.3.3 and 0.4.0 logged identically.

## 0.5.0


Pictures now travel both ways. `images` hands Codex pictures alongside the task:

```js
tools.subagent_codex({ description: "Match this design", prompt: "…", images: ["/tmp/design.png"] })
```

Each path must be absolute, must exist, and must be a file, and the call fails before anything is spawned
otherwise. That check is load-bearing rather than decorative: **the app-server silently ignores a `localImage`
path that does not exist** — measured, with the turn completing normally and not one error item — so an
unchecked typo would produce a delegation that quietly lacks the picture its task was about.

The pictures go out as the app-server's `localImage` variant, which the error messages themselves identified as
one of `text`, `image`, `localImage`, `audio`, `localAudio`. Its `image` variant wants an `ImageReference` this
plugin cannot construct — both `{type:'image', data, mimeType}` and a `data:` URL are rejected with
`did not match any variant of untagged enum ImageReference` — so a host path is not a workaround but the form
that needs no encoding at all.

A delegation prompt remains text. An image block arriving there is refused with a message naming the `images`
parameter instead of the old flat refusal, because the harness can put an image in a prompt but a tool call's
arguments are JSON and the model has no bytes to put in them.

Verified live: a delegation whose prompt never mentioned a path, given one image, answered "Settings, Models" —
the two words on it.

## 0.4.0


A delegation can run in a directory of its own.

`cwd` names an absolute path the run should use instead of the session's working directory — the shape a
post-deploy smoke test needs, where the run may write its artifacts but the repository must stay clean.

The path must be absolute, must exist, and must be a directory; anything else is refused with a message naming
the problem, rather than a run that quietly happens somewhere unexpected. It is a working directory and not a
sandbox boundary: what a run may touch remains the permission mode's decision.

Naming a directory also starts a fresh Codex thread, because a thread belongs to the directory it was created
in — continuing one elsewhere would be continuing a conversation about different files. `cwd` is therefore
incompatible with `threadMode: session`'s reuse, and the log says which directory each run used.

Requested while retiring a skill whose two jobs this plugin now covers: dispatching to Codex, and getting
screenshots back — which the skill could not do, and which is why its instructions required artifacts to land on
disk instead.

## 0.3.3


A delegation now has a deadline, because one without it is invisible when it stalls.

`runTimeoutMs` bounds one whole delegation, defaulting to ten minutes and disabled by `0`. When the deadline
passes, the run is cancelled, the child process is torn down, and the result carries
`codex-pro: the delegation exceeded its 600000 ms deadline and was cancelled` rather than nothing at all.

The harness's own vocabulary has no `timeout` stop reason, so the provider path reports a cancelled run as
`aborted` while the diagnostic carries the reason; this plugin's own tool reports `timeout` and formats the
message itself.

Found in a real session: a screenshot delegation had been running for seven minutes at 0% CPU with one
established connection to a local proxy, no rollout written, and nothing anywhere in the log to say so. The
proxy turned out to be healthy — the stall was in the streaming request — which is precisely why the deadline
matters more than the diagnosis: whatever the cause, the wait now ends with a reason.

Verified live: a three-second deadline cancelled a run at 3.1 s, returned the diagnostic, and left no child
process behind.

## 0.3.2


A background delegation no longer loses its images.

`run_in_background` returns a job id, and everything read back through `job_output` is text by contract, so the
image blocks a foreground call returns were simply dropped — silently, and with no trace of where the picture
went. A screenshot taken by a background delegation is still a file on this host, so the text now names it:
`[1 image: /Users/…/shot.png]`. A foreground call is unchanged and still delivers the image itself; `render` no
longer repeats the count, because the text already carries it.

Found by looking at a real session rather than at the code: a screenshot delegation had been started in the
background, and there was no path in the answer it would eventually produce.

## 0.3.1


The image guard was too strict, and it would have hidden the feature it was added for.

0.3.0 refused an image whenever the calling route did not **report** `image` among its input modalities, and it
failed closed: a route it could not resolve was treated as a route that cannot take images. The default
`deepseek-flash` entry declares `['text', 'image']`, so a session that could display screenshots would instead
have been told `[image not delivered: …]` for every one of them.

The rule is now the harness's own — an image is refused only when the route **declares** modalities and `image`
is not among them — and an unresolvable route delivers the image rather than withholding it. The route lookup
also gained the fallback `dsh-plugin-lcu` uses, so a session header without a model still resolves.

The rule is a pure function, `routeRefusesImages`, so the boundary is covered by tests instead of by whichever
session happens to be running.

## 0.3.0


Images a delegation produces now come back.

The app-server reports them two ways and both are captured. `imageView` names a file on this host — the bytes
are never inlined, because the host that asked for the work is expected to read the file itself — while a
computer-use screenshot arrives as an image content block inside an MCP tool result. The plugin reads or decodes
whichever it gets, hands the bytes to the harness's attachment store, and returns image blocks beside the text,
so the model sees a picture instead of a description of one.

An image is only delivered when the calling Agent's model route reports `image` among its input modalities, the
same guard `dsh-plugin-lcu` applies to its screenshots. Everything else — no store, an unreadable file, over
20 MB, an unsupported type, a route that cannot take images — becomes a text note. None of it can fail the
delegation: the answer the run produced always survives.

Verified against a real app-server through this package's own code: asked to open a file by path, Codex read the
providers listed on the screenshot aloud, and the run reported one captured image with its host path.

Sending images *in* is not implemented. The protocol accepts `input_image`, `local_image`, `image_url` and
audio, but this tool still sends text only; naming a path in the prompt remains the working route, and both
READMEs now document what each side actually supports.

## 0.2.2


**`session` mode no longer collides with itself.** A thread carries one turn at a time, so two delegations sent
together from one session both reached for the remembered thread and the app-server refused the second with
`thread-store conflict: … already has an active writer`. The plugin now tracks which threads its Agent is
delegating in and checks before it starts: a remembered thread in use is skipped, the call gets a thread of its
own, and the skip is logged. Parallel work keeps running, and the mode falls back to `persistent` — which is
what that shape of work needs anyway — instead of failing and retrying.

The decision is a pure function, `chooseThread`, so it is covered by tests rather than by an app-server. An id
the caller passed explicitly is never skipped: continuing that thread was the request, and running somewhere
else would answer a different question.

## 0.2.1


`apply` now records the thread mode and the originator, so the log says which lifetime is in force without
anyone reading the profile to find out.

**The session-mode retry is narrowed to the failure it was meant for.** It wrapped every delegation, so a turn
that failed for its own reasons was retried as a fresh thread — paying for the same work twice and hiding the
real failure behind a second attempt. It now applies only to a resume the app-server refused.

**A concurrency limit, measured rather than assumed.** Two delegations sent at once to one thread collide: the
app-server answers `thread-store conflict: … already has an active writer` and the second fails, while
`ephemeral` runs the same pair independently. `session` is therefore the wrong mode for parallel work, and both
READMEs now say so.

## 0.2.0


A delegation can now outlive its run.

**Thread lifetime is a choice, not a constant.** Every delegation used to open an ephemeral thread, which the
app-server deletes when the connection ends — nothing to list, nothing to continue. `threadMode` now has three
settings: `ephemeral` keeps that behaviour and stays the default; `persistent` gives each delegation a durable
thread; `session` reuses one durable thread for the whole Agent session, so ten delegations leave one thread
rather than ten and each call after the first continues the same conversation.

**A durable thread is one the Codex CLI and the Codex application can see.** Verified against a real
app-server: the thread is written to `~/.codex/sessions/`, appears in `thread/list`, and can be continued with
`thread/resume`. The application's own list is the narrow part — its client filters by a single hardcoded
originator value, `Codex Desktop`, so `originator` exists to set that and defaults to the value that works.
Overriding it trades application visibility for an honest name; the CLI lists the thread either way.

**Threads are named, because the originator cannot say where they came from.** A thread from this provider has
to claim to be `Codex Desktop` to be listed at all, so `thread/name/set` carries the identification instead:
a persistent thread is named `DSH · <the call's description>`, which is what a person sees in the list.

**The model can control it per call.** The tool gained `thread_mode` and `thread_id`, and a persistent result
ends with the thread's id so a follow-up call can continue it. Resuming ignores `model` and `reasoning_effort`:
both are `thread/start` parameters and a resumed thread keeps the ones it was created with, while the per-turn
`effort` still applies.

**Why it is worth the change beyond convenience:** a resumed thread keeps the same prompt prefix, so the
endpoint's cache keeps hitting — measured on the Codex side at 93–99% of input tokens, against 0% for the same
work driven through a plan-usage route that refuses every cache control.

A thread with no turn yet is not resumable — the app-server answers `no rollout found` — so a thread becomes
continuable only after its first completed turn. A remembered session thread that has gone is replaced with a
fresh one; an id the caller passed explicitly is reported as a failure instead, because continuing it was the
whole request.

## 0.1.1


Documentation and packaging; no behaviour change.

The published `files` list named only `lib` and the patch, so an installed copy shipped **no licence and no
readme** — npm's own defaults covered neither once `files` was set. It now carries the licence, the readme, this
changelog and the Chinese page.

Joins a closing sentence that a blank line had split in two, and removes a `helper` entry from `files` that
named a directory this package does not have.

## 0.1.0

First release.

**A Codex delegation that can carry a model and a reasoning effort per call** — the two things
`@deepseek-ai/dsh-subagent-codex` cannot express. The Codex protocol supports both
(`ThreadStartParams.reasoningEffort`, `TurnStartParams.effort`); the official provider never sends them, and its
schema exposes neither, so a caller told to use a specific model and thinking level has nowhere to put either.

**Execution is a port of the official app-server adapter** (`src/wire.ts`, `src/run.ts`) — the initialize
handshake, the ephemeral thread, thread/turn association including notifications that arrive before
`turn/start` returns, unattended approval decisions, and terminal-answer selection — with `reasoningEffort` added
to `thread/start` and `effort` added to `turn/start`. The two literals appear nowhere in the official adapter.

**The tool is registered by this plugin itself**, on `agent/created`, into that Agent's own context, which keeps
the harness's preset-row machinery out of the path. Because the tool name is fixed, the official
`tool-subagent-codex` row stays disabled in those presets: two rows registering the same name in one scope
collide, and the second registration throws while its tool silently never appears.

**Defaults are deliberately absent.** What the call names is what runs; when it names neither, the choice stays
with Codex's own `~/.codex/config.toml`. The Host's `subagent-model-selection` setting is not consulted — it
governs a DSH catalog route billed as tokens, not a Codex model id under the CLI's own subscription.

**Background runs report progress.** `run_in_background` appends the child's completed commands, file changes,
and `commentary` messages to the job's output ring, so `job_output` shows how a long delegation is going.
