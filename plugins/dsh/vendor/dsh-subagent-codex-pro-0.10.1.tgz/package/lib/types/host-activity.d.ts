import { type ActivityEvent } from './activity.ts';
import type { AgentLike, Context } from './dsh-types.ts';
/** Optional Flywheel extension, not an invented DSH core event or model message. */
export interface FlywheelProviderActivity {
    readonly version: 1;
    readonly intervalMs: number;
    report(agent: AgentLike, event: ActivityEvent & {
        readonly invocationId: string;
    }): void;
}
export declare function hostActivity(host: Pick<Context, 'get'> | undefined, agent: AgentLike, signal: AbortSignal): {
    onActivity?: (event: ActivityEvent) => void;
    activityIntervalMs?: number;
};
//# sourceMappingURL=host-activity.d.ts.map