/**
 * A Codex delegation that can carry a model and a reasoning effort.
 *
 * ## Why this exists
 *
 * `@deepseek-ai/dsh-subagent-codex` declares `NO_START_CAPABILITIES`, so its
 * `tool-subagent` row cannot enable `modelSelectionSettings` — that requires a
 * provider declaring `agentOptions`, which the Codex provider does not. The
 * Codex protocol supports the choices this package exposes: `model` on
 * `thread/start`, per-turn `effort` on `turn/start`, and model/cwd/permission
 * overrides on `thread/resume` (0.165+). The official adapter sends none of
 * them; a thinking level is not a `thread/start` field in 0.165/0.166.
 *
 * Enabling the flag on a Codex row of our own provider was tried and did not
 * work: the row vanished with no tool and no error, while a control row — same
 * provider, same row, flag off — registered fine. That defect belongs to the
 * flag, not to the provider, and is reported upstream.
 *
 * ## What this does instead
 *
 * Two things, both under this package's control:
 *
 * 1. **Execution** is a port of the official app-server adapter (`wire.ts`,
 *    `run.ts`), with `model` on `thread/start`, `effort` on `turn/start`, and
 *    explicit model/cwd/permission overrides plus effective-config verification
 *    on `thread/resume`. That is the same protocol the official provider speaks,
 *    including its initialize handshake, ephemeral thread, unattended approval
 *    decisions, and terminal-answer selection.
 * 2. **The tool** is registered on `agent/created` into that Agent's own context
 *    — the path `dsh-plugin-lcu` uses — so the harness's preset-row machinery
 *    stays out of the way. `presets` names the presets that get it.
 *
 * `model` and `reasoning_effort` appear while this plugin's independent
 * modelSelection setting is enabled. Codex model ids are not DSH LLM routes.
 *
 * @module dsh-subagent-codex-pro
 */
import type { Context, SubagentProviderLike, SubagentRunLike, SubagentStartRequestLike } from './dsh-types.ts';
import { type NativeConfigValue } from './desktop-native.ts';
import type { CodexPermissionMode } from './wire.ts';
/** Cordis plugin name. */
export declare const name = "codex-pro";
/**
 * The services this plugin cannot work without.
 *
 * `subagents` is the provider registry. Everything else — the Agent registry,
 * the preset registry, the host opt-in — is looked up with `ctx.get`, so a
 * deployment missing one degrades instead of failing to load.
 */
export declare const inject: string[];
/** Runtime schema consumed by DSH's plugin settings service. */
export declare const Config: import("@deepseek-ai/schemastery").default<Schemastery.ObjectS<NoInfer<{
    providerName: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    command: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    model: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    reasoningEffort: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    modelSelection: import("@deepseek-ai/schemastery").default<boolean, boolean, "plain">;
    permissionMode: import("@deepseek-ai/schemastery").default<"read-only" | "workspace-write" | "never" | "approve-for-me" | "dangerously-bypass-approvals-and-sandbox", "read-only" | "workspace-write" | "never" | "approve-for-me" | "dangerously-bypass-approvals-and-sandbox", "plain">;
    env: import("@deepseek-ai/schemastery").default;
    presets: import("@deepseek-ai/schemastery").default;
    threadMode: import("@deepseek-ai/schemastery").default<"ephemeral" | "persistent" | "session", "ephemeral" | "persistent" | "session", "plain">;
    runTimeoutMs: import("@deepseek-ai/schemastery").default<number, number, "plain">;
    originator: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    native: import("@deepseek-ai/schemastery").default<any, unknown, "volatile">;
}>>, Schemastery.ObjectT<NoInfer<{
    providerName: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    command: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    model: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    reasoningEffort: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    modelSelection: import("@deepseek-ai/schemastery").default<boolean, boolean, "plain">;
    permissionMode: import("@deepseek-ai/schemastery").default<"read-only" | "workspace-write" | "never" | "approve-for-me" | "dangerously-bypass-approvals-and-sandbox", "read-only" | "workspace-write" | "never" | "approve-for-me" | "dangerously-bypass-approvals-and-sandbox", "plain">;
    env: import("@deepseek-ai/schemastery").default;
    presets: import("@deepseek-ai/schemastery").default;
    threadMode: import("@deepseek-ai/schemastery").default<"ephemeral" | "persistent" | "session", "ephemeral" | "persistent" | "session", "plain">;
    runTimeoutMs: import("@deepseek-ai/schemastery").default<number, number, "plain">;
    originator: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    native: import("@deepseek-ai/schemastery").default<any, unknown, "volatile">;
}>>, "plain">;
/** Plugin configuration. */
export interface Config {
    /** Live ordinary-delegation defaults. Omit for CLI defaults; null explicitly turns agents off. */
    native?: NativeConfigValue;
    /** Provider name to register under. Must differ from the official `codex`. */
    providerName?: string;
    /** Codex executable; the app-server is started as `<command> app-server --stdio`. */
    command?: string;
    /** Default model when a call does not name one. */
    model?: string;
    /** Default reasoning effort when a call does not name one. */
    reasoningEffort?: string;
    /**
     * Whether an Agent may name a model and a thinking level for a delegation.
     *
     * This plugin's own control, deliberately independent of the Host's
     * `subagent-model-selection` setting. That setting authorizes a child **LLM
     * route** chosen from the DSH model catalog and billed as tokens; a Codex
     * delegation names a **Codex model id** governed by the Codex CLI's own
     * subscription. The two are different resources with different namespaces, so
     * the Host's list can neither authorize nor constrain this choice — reading it
     * would only couple this tool to a setting that has nothing to say about it.
     *
     * Defaults to true: being able to name the model is the point of this package.
     */
    modelSelection?: boolean;
    /** Unattended permission policy for the child thread. */
    permissionMode?: CodexPermissionMode;
    /** Extra environment entries for the child. */
    env?: Record<string, string>;
    /** Agent preset ids whose sessions receive the delegation tool. */
    presets?: string[];
    /**
     * How long a delegated Codex thread lives.
     *
     * - `ephemeral` (the default) is a throwaway run: nothing is written that the
     *   Codex CLI or the Codex application can list afterwards.
     * - `persistent` gives every delegation its own durable thread, which the Codex
     *   CLI and application list under the session's working directory and
     *   `thread_id` can continue.
     * - `session` reuses one durable thread for the whole Agent session, so a
     *   session that delegates ten times leaves one thread rather than ten, and
     *   after the first delegation each call continues the same conversation —
     *   which keeps the prompt prefix stable and lets the model's cache do its
     *   work. A call may still override either choice, and pass `thread_id` to
     *   continue a thread of its own.
     */
    threadMode?: 'ephemeral' | 'persistent' | 'session';
    /**
     * Deadline for one delegation in milliseconds; `0` disables it.
     *
     * A delegation that hangs is otherwise invisible: the job stays `running`, the
     * session waits, and nothing is logged. The deadline turns that into a failure
     * with a reason. Defaults to ten minutes, which is generous against a task
     * class whose own documentation says "a minute or more".
     */
    runTimeoutMs?: number;
    /**
     * What the app-server records as the thread's originator.
     *
     * This is what decides whether the Codex desktop application lists a thread:
     * that client filters its list to the single value `Codex Desktop`, so the
     * default here is that literal. Overriding it trades desktop visibility for an
     * honest name — a thread the application will not show is still listed by the
     * Codex CLI and still resumable.
     */
    originator?: string;
}
/**
 * Check a caller-named deadline.
 *
 * A duration, so it must be a whole number of milliseconds: negative and
 * fractional values have no meaning, and silently rounding one would give a
 * caller a deadline it did not ask for. `0` is allowed and means no deadline,
 * which is what the plugin's own configuration uses to disable it.
 *
 * @param value - the deadline a call named.
 * @returns the deadline, unchanged.
 * @throws when it is not a whole non-negative number of milliseconds.
 */
export declare function checkedTimeout(value: number): number;
/**
 * Check a caller-named output schema's shape.
 *
 * The harness applies the same rule to a schema it passes a provider —
 * `assertObjectJsonSchema` — so matching it means a schema this tool accepts is
 * one the harness would too. Only the root is checked: it must be an object with
 * `type: "object"`, because Codex constrains a whole answer and a bare array or
 * scalar has nowhere to put the shape.
 *
 * @param value - the schema a call named.
 * @returns the schema, unchanged.
 * @throws when it is not an object-rooted JSON Schema.
 */
export declare function checkedOutputSchema(value: unknown): Record<string, unknown>;
/**
 * Check one caller-named image path.
 *
 * The path must be absolute and must name a file this plugin could hand the
 * app-server. Whether it exists is checked where the run is prepared, next to
 * the check for the working directory, because that is where a real path is.
 *
 * @param requested - the path a call named.
 * @returns the path, unchanged.
 * @throws when it is not an absolute path.
 */
export declare function checkedImagePath(requested: string): string;
/**
 * Check a caller-named working directory's shape.
 *
 * Only the shape is checked — absolute and non-empty — so the rule is testable
 * without a filesystem. Whether the path exists and is a directory is checked
 * where the run is prepared, because that is where a real path matters.
 *
 * @param requested - the path a call named.
 * @returns the path, unchanged.
 * @throws when it is not an absolute path.
 */
export declare function checkedWorkdir(requested: string): string;
/**
 * Whether a model route's declared modalities refuse images.
 *
 * This is the harness's own rule, and matching it exactly is the point: an image
 * is refused only when the route **declares** input modalities and `image` is not
 * among them. An undeclared route is left to the harness, which rejects an
 * attachment for a model that cannot read it anyway.
 *
 * Being stricter cost a real screenshot. The default `deepseek-flash` entry
 * declares `['text', 'image']`, and an earlier guard here failed closed whenever
 * the route could not be resolved — which turned every image into a text note in
 * a session that could have displayed it.
 *
 * @param info - the resolved model route, when it could be resolved.
 * @returns whether the route says it cannot take images.
 */
export declare function routeRefusesImages(info: {
    readonly inputModalities?: readonly string[];
} | undefined): boolean;
/**
 * A line naming where each image is, appended to the text.
 *
 * A foreground call carries the pictures as blocks, but a background call's
 * result is a string by contract — its reader sees this text and nothing else. So
 * the paths go in the text as well: a screenshot a background delegation took is
 * still a file on this host, and naming it is the difference between the work
 * being usable and being lost.
 *
 * @param text - the delegation's answer.
 * @param images - the images the run produced.
 * @returns the answer with the image line appended.
 */
export declare function withImageNote(text: string, images: readonly {
    readonly path?: string;
}[]): string;
/** Tool calls may narrow their configured policy, never expand it implicitly. */
export declare function resolvePermissionOverride(configured: CodexPermissionMode, requested: CodexPermissionMode | undefined): CodexPermissionMode;
/**
 * One delegation to Codex, exposed as a provider the harness can start.
 *
 * Exported so the provider adapter can be exercised against the same fake
 * app-server as the tool path; the plugin's `apply` is its only production
 * constructor.
 */
export declare class CodexExecProvider implements SubagentProviderLike {
    readonly name: string;
    readonly inheritsParentContext = false;
    /**
     * The declaration that unlocks the delegation tool's model surface.
     *
     * `agentOptions: true` is what `tool-subagent` checks before accepting either a
     * configured `agentOptions` or `modelSelectionSettings: true` on its row.
     */
    readonly capabilities: {
        readonly agentOptions: true;
        readonly agentPreset: false;
        readonly outputSchema: true;
        readonly depthLimit: false;
    };
    /**
     * The resolved configuration.
     *
     * A plain field rather than a constructor parameter property: Node's
     * type-stripping mode rejects that syntax outright, which made this module
     * unimportable from a test and left its pure helpers untestable.
     */
    readonly resolved: Required<Pick<Config, 'command' | 'providerName' | 'permissionMode'>> & Config;
    readonly activityHost: Pick<Context, 'get'> | undefined;
    constructor(resolved: Required<Pick<Config, 'command' | 'providerName' | 'permissionMode'>> & Config, activityHost?: Pick<Context, 'get'>);
    /**
     * Start one Codex run over the app-server protocol.
     *
     * @param request - the delegation the harness resolved.
     * @returns a run handle; its `result` settles with the child's final message.
     */
    start(request: SubagentStartRequestLike): Promise<SubagentRunLike>;
}
/**
 * Register the provider and the delegation tool.
 *
 * @param ctx - context carrying the subagent registry.
 * @param config - provider name, defaults, and the presets to serve.
 */
export declare function apply(ctx: Context, config?: Config): void;
/**
 * Append the thread marker to a human-text delegation result.
 *
 * A machine-readable answer (one carrying `output_schema`) must stay valid JSON:
 * appending a marker would make the whole result unparseable. Such a run keeps
 * its thread id in the result envelope/diagnostic log instead of in the text.
 *
 * @param outcome - the finished run.
 * @param mode - the thread mode the run used.
 * @param machineOutput - whether the answer is schema-constrained JSON.
 * @returns the text to report.
 */
export declare function withThreadMarker(outcome: {
    readonly text: string;
    readonly threadId: string | undefined;
}, mode: 'ephemeral' | 'persistent', machineOutput: boolean): string;
//# sourceMappingURL=index.d.ts.map