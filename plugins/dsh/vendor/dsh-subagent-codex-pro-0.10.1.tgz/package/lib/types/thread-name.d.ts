/** Name from an explicit task label or workspace only, never from the complete prompt. */
export declare function readableThreadName(label: string | undefined, cwd: string): string;
//# sourceMappingURL=thread-name.d.ts.map