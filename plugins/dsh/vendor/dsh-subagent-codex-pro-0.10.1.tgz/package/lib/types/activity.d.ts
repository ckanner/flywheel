/** Observed provider activity is separate from answers and durable lifecycle ACKs. */
export declare const MACHINE_ACTIVITY_VERSION: 1;
export declare const MACHINE_ACTIVITY_CAPABILITIES: Readonly<{
    version: 1;
    metadataOnly: true;
    coalesced: true;
    rootAndChildren: true;
}>;
export declare const ACTIVITY_EVENT_TYPES: readonly ["turn/started", "turn/completed", "item/started", "item/completed", "item/agentMessage/delta", "item/plan/delta", "item/reasoning/summaryTextDelta", "item/reasoning/summaryPartAdded", "item/reasoning/textDelta", "item/commandExecution/outputDelta", "item/mcpToolCall/progress", "turn/plan/updated", "turn/diff/updated", "thread/tokenUsage/updated"];
export type ActivityScope = 'root' | 'child' | 'mixed';
export interface ActivityEvent {
    readonly version: 1;
    readonly sequence: number;
    readonly kind: 'provider-progress';
    readonly source: 'codex-pro';
    readonly scope: ActivityScope;
    readonly eventTypes: readonly string[];
    readonly observedEvents: number;
}
export declare function validActivity(value: unknown): value is ActivityEvent;
export declare function activityInterval(value: number | undefined): number;
/** No timer: a report is emitted only while processing a new owned event. */
export declare function createActivityReporter(report: ((event: ActivityEvent) => void) | undefined, intervalMs?: number): (scope: 'root' | 'child', method: string) => void;
//# sourceMappingURL=activity.d.ts.map