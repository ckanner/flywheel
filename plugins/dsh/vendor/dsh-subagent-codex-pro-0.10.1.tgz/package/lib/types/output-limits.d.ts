/** A retained frame/result exceeds its bound; lifetime stream traffic is not retained memory. */
export declare class OutputLimitError extends Error {
    constructor(message: string);
}
//# sourceMappingURL=output-limits.d.ts.map