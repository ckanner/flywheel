/**
 * Newline-delimited JSON-RPC 2.0 over a child process's stdio.
 *
 * The official Codex provider gets this from
 * `@deepseek-ai/dsh-sdk-protocol`'s `JsonRpcLineTransport`. This plugin keeps
 * zero runtime dependencies, so the transport lives here — and it is a small,
 * well-understood piece: frame by line, correlate by id, surface every failure
 * instead of leaving a caller pending forever.
 *
 * Framing: one JSON object per line, `\n`-terminated, on both directions. A
 * partial line is buffered; a malformed line is reported and skipped, because a
 * protocol peer that emits one bad frame should not take the session down.
 *
 * @module dsh-subagent-codex-pro/jsonrpc
 */
import { OutputLimitError } from './output-limits.ts';
/** One decoded JSON-RPC message. */
export interface JsonRpcMessage {
    readonly jsonrpc?: string;
    readonly id?: number | string;
    readonly method?: string;
    readonly params?: unknown;
    readonly result?: unknown;
    readonly error?: {
        readonly code?: number;
        readonly message?: string;
        readonly data?: unknown;
    };
}
/** What the owner does with messages that are not responses. */
export interface TransportHooks {
    /**
     * Handle a request from the peer. The resolved value becomes its `result`; a
     * throw becomes its `error`.
     *
     * @param method - the JSON-RPC method.
     * @param params - its params.
     * @returns the result to send back.
     */
    onRequest?(method: string, params: unknown): Promise<unknown> | unknown;
    /**
     * Handle a notification.
     *
     * @param method - the JSON-RPC method.
     * @param params - its params.
     */
    onNotification?(method: string, params: unknown): void;
    /**
     * Report a transport-level failure (bad frame, write error).
     *
     * @param error - what went wrong.
     */
    onProblem?(error: Error): void;
}
/** The writable side of a transport. */
export interface TransportWritable {
    write(chunk: string): unknown;
}
/** The readable side of a transport. */
export interface TransportReadable {
    on(event: 'data', listener: (chunk: Buffer | string) => void): unknown;
}
/** A JSON-RPC peer speaking one object per line. */
export declare class LineTransport {
    #private;
    constructor(toPeer: TransportWritable, fromPeer: TransportReadable, hooks?: TransportHooks, limits?: {
        maxFrameBytes?: number;
        onLimit?: (error: OutputLimitError) => void;
    });
    /**
     * Replace the message hooks.
     *
     * The wire installs its handlers after construction, which keeps the transport
     * independent of the product methods layered on top of it.
     *
     * @param hooks - the handlers to install.
     */
    setHooks(hooks: TransportHooks): void;
    /**
     * Wait until everything written so far has left this process.
     *
     * Writes go to the peer's stream synchronously, so there is nothing to drain;
     * the method exists because the protocol's handshake uses it as an explicit
     * write barrier between `initialized` and `thread/start`.
     *
     * @returns a promise that is already settled.
     */
    flush(): Promise<void>;
    /**
     * Send one request and await its response.
     *
     * @param method - the JSON-RPC method.
     * @param params - its params.
     * @param options - optional caller cancellation and a response deadline.
     * @returns the peer's `result`.
     */
    request(method: string, params: unknown, options?: {
        signal?: AbortSignal | undefined;
        timeoutMs?: number | undefined;
    }): Promise<unknown>;
    /**
     * Send one notification; nothing is awaited.
     *
     * @param method - the JSON-RPC method.
     * @param params - its params.
     */
    notify(method: string, params?: unknown): void;
    /**
     * Fail every in-flight request and stop reading.
     *
     * @param reason - why the transport is going away.
     */
    dispose(reason?: Error): void;
    /** How many requests are still awaiting a response. */
    get pendingCount(): number;
}
//# sourceMappingURL=jsonrpc.d.ts.map