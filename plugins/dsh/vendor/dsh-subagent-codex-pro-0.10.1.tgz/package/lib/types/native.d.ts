/** Versioned controls and evidence for Codex's native child threads. */
import { type CodexUsageReport } from './usage.ts';
export declare const MACHINE_NATIVE_VERSION: 1;
export declare const MACHINE_NATIVE_CAPABILITIES: Readonly<{
    version: 1;
    agents: true;
    review: true;
    images: true;
    structuredOutput: true;
    childEvents: true;
    cleanup: "local-process-group";
    remoteJobs: false;
}>;
export type NativeReviewTarget = {
    type: 'uncommittedChanges';
} | {
    type: 'baseBranch';
    branch: string;
} | {
    type: 'commit';
    sha: string;
    title?: string;
} | {
    type: 'custom';
    instructions: string;
};
export interface NativeRequest {
    readonly version: 1;
    readonly agents?: {
        readonly enabled: boolean;
        readonly maxConcurrentThreads?: number;
        readonly defaultModel?: string;
        readonly defaultEffort?: string;
        readonly backend?: 'v2';
    };
    readonly review?: {
        readonly target: NativeReviewTarget;
    };
}
export interface NativeEvent {
    readonly version: 1;
    readonly sequence: number;
    readonly kind: string;
    readonly id: string;
    readonly parentId: string | null;
    readonly state: string;
    readonly turnId?: string;
    readonly model?: string;
}
export interface NativeChild {
    id: string;
    parentId: string | null;
    kind: string;
    state: string;
    model: string | null;
    turnId: string | null;
    usage: CodexUsageReport | null;
}
export interface NativeReceipt {
    version: 1;
    requested: NativeRequest;
    effective: {
        source: string | null;
        matched: boolean;
        config: Record<string, unknown> | null;
    };
    observed: {
        events: NativeEvent[];
        truncated: boolean;
    };
    children: NativeChild[];
    usage: {
        strategy: 'per-thread';
        scope: 'observed-children';
        status: 'complete' | 'partial' | 'unknown';
        children: Record<string, CodexUsageReport>;
        totalTokens: number | null;
    };
    completion: {
        confirmed: boolean;
        pendingIds: string[];
    };
    cleanup: {
        confirmed: boolean;
        scope: 'local-process-group';
        pendingIds: string[];
    };
}
/** Reject unsupported controls, instead of silently dropping a policy. */
export declare function parseNativeRequest(value: unknown): NativeRequest;
/** Each override is passed as one argv value; never interpolated into a shell. */
export declare function nativeConfig(request: NativeRequest, review?: {
    model?: string | undefined;
    effort?: string | undefined;
}): Record<string, unknown>;
export declare function nativeArguments(request: NativeRequest | undefined, review?: {
    model?: string | undefined;
    effort?: string | undefined;
}): string[];
/** Identity must be established by a parent relation, never by an arbitrary notification. */
export declare class NativeTracker<Request extends NativeRequest | undefined = NativeRequest> {
    #private;
    readonly request: Request;
    constructor(request: Request, report?: (event: NativeEvent) => void, review?: {
        model?: string | undefined;
        effort?: string | undefined;
    });
    get configurationOverrides(): Record<string, unknown>;
    setRoot(id: string): void;
    verifyConfiguration(response: unknown): void;
    owns(id: unknown): boolean;
    acceptsTurn(id: unknown, turnId: unknown, nullable?: boolean): boolean;
    activeTurn(id: unknown, turnId: unknown): boolean;
    observe(method: string, params: unknown): void;
    running(): {
        threadId: string;
        turnId: string;
    }[];
    report(cleanupConfirmed?: boolean): NativeReceipt;
}
//# sourceMappingURL=native.d.ts.map