/**
 * Codex app-server protocol adapter.
 *
 * A faithful port of `@deepseek-ai/dsh-subagent-codex`'s wire module, extended
 * with the per-call choices this package exists for: `model` and the unattended
 * permission policy on `thread/start`, per-turn `effort` on `turn/start`, and
 * explicit model/cwd/permission overrides plus effective-configuration checks
 * on `thread/resume` (0.165+). A thinking level is **not** a `thread/start`
 * field in 0.165/0.166. The module also accounts for token usage and account
 * rate limits, keeping them separate.
 *
 * Everything else is carried over as-is, because the surrounding behaviour is
 * load-bearing and was tuned against a real app-server: the initialize
 * handshake, thread/turn association (including notifications that arrive
 * before `turn/start` returns), unattended approval decisions, terminal-answer
 * selection by phase, and the failure taxonomy.
 *
 * Differences from the source, all mechanical:
 * - `JsonRpcLineTransport` is this package's own `LineTransport`, so the
 *   transport method shape is `request(method, params, { signal })` rather than
 *   a positional signal.
 * - Error text uses this package's prefix.
 * - Model and permission choices are constructor state; `effort` travels through
 *   `runTurn`; resume overrides are per call.
 *
 * @module dsh-subagent-codex-pro/wire
 */
import type { LineTransport } from './jsonrpc.ts';
import { type CodexUsageReport } from './usage.ts';
/** Explicit thread permissions; approval policy never implies a sandbox. */
declare const THREAD_PERMISSION_PARAMS: {
    readonly 'read-only': {
        readonly approvalPolicy: "never";
        readonly sandbox: "read-only";
    };
    readonly 'workspace-write': {
        readonly approvalPolicy: "never";
        readonly sandbox: "workspace-write";
    };
    readonly never: {
        readonly approvalPolicy: "never";
    };
    readonly 'approve-for-me': {
        readonly approvalPolicy: "on-request";
        readonly approvalsReviewer: "auto_review";
        readonly sandbox: "workspace-write";
    };
    readonly 'dangerously-bypass-approvals-and-sandbox': {
        readonly approvalPolicy: "never";
        readonly sandbox: "danger-full-access";
    };
};
/** The permission params one mode sends to thread/start and thread/resume. */
export type CodexPermissionParams = (typeof THREAD_PERMISSION_PARAMS)[CodexPermissionMode];
/** The configured permission mode. */
export type CodexPermissionMode = keyof typeof THREAD_PERMISSION_PARAMS;
/** The model/cwd/permission facts a start or resume request asked for. */
export interface RequestedConfiguration {
    readonly model?: string;
    readonly cwd?: string;
    readonly approvalPolicy?: string;
    readonly approvalsReviewer?: string;
    readonly sandbox?: string;
}
/** The facts the app-server reports after applying a start or resume request. */
export interface EffectiveConfiguration {
    readonly model?: string;
    readonly cwd?: string;
    readonly approvalPolicy?: string;
    readonly approvalsReviewer?: string;
    readonly sandbox?: string;
    /** Full server-reported policy; matching the mode alone does not prove its roots/network scope. */
    readonly sandboxPolicy?: Readonly<Record<string, unknown>>;
    /** Historical thread default, not evidence of this run's per-turn effort. */
    readonly reasoningEffort?: string | null;
}
/** One path's requested/effective facts, kept for observability and comparison. */
export interface AppliedConfiguration {
    readonly source: 'thread/start' | 'thread/resume';
    readonly requested: RequestedConfiguration;
    readonly effective: EffectiveConfiguration;
    readonly matched: boolean;
    /** Requested facts whose effective value is absent, malformed, or unsupported. */
    readonly missing: readonly (keyof RequestedConfiguration)[];
    /** Names of requested facts whose effective value differs; values are not echoed. */
    readonly mismatches: readonly (keyof RequestedConfiguration)[];
}
/** Codex acknowledges the turn, but 0.165/0.166 do not echo its effective effort. */
export interface TurnConfiguration {
    readonly requestedEffort?: string;
    readonly effectiveEffort: null;
    readonly evidence: 'turn/start-request';
    readonly accepted: boolean;
}
/** Overrides sent on `thread/resume` instead of silently preserving history. */
export interface CodexResumeOverrides {
    /** Model override, when the caller/configuration supplied one. */
    readonly model?: string;
    /** Working directory override applied to the resumed thread. */
    readonly cwd?: string;
    /** Permission mode override. Omitted means preserve the thread's history. */
    readonly permission?: CodexPermissionMode;
}
/** The rate-limit snapshot Codex sends separately from token usage. */
export interface CodexRateLimitsReport {
    readonly observations: number;
    /** Latest `rateLimits` object, exactly as reported. */
    readonly latest?: Record<string, unknown>;
}
/**
 * One image the run produced.
 *
 * Two shapes reach here. `imageView` names a file on this host, which the caller
 * can read directly — the app-server never inlines it. An MCP tool result carries
 * the bytes, which is how a computer-use screenshot arrives.
 */
export interface CodexImage {
    /** A host path to read, for `imageView`. */
    readonly path?: string;
    /** Base64 bytes, for an image an MCP tool returned. */
    readonly data?: string;
    /** The bytes' media type, when the source named one. */
    readonly mimeType?: string;
}
/** The stop reasons one run can end with. */
export type CodexStopReason = 'completed' | 'max-tokens' | 'error' | 'aborted' | 'timeout';
/**
 * How long a thread lives.
 *
 * `ephemeral` is what this provider always did: the app-server's own notion of a
 * throwaway thread, deleted when the connection ends, leaving nothing behind.
 * `persistent` writes a rollout the Codex CLI can list and `thread/resume` can
 * continue, which is also what puts it in front of the Codex desktop application.
 */
export type CodexThreadMode = 'ephemeral' | 'persistent';
/** One text-only task submitted to a turn. */
export type TaskText = string;
/** The structured failure facts observed for a turn. */
export interface CodexFailureFacts {
    readonly stage: string;
    readonly category: string;
    readonly httpStatus?: number;
}
/** One thing that ends a turn. */
export interface TurnCompletion {
    readonly params: {
        readonly turn: unknown;
    };
    readonly order: number;
}
/** The end of one run. */
export interface WireRunResult {
    readonly output: readonly {
        readonly type: 'text';
        readonly text: string;
    }[];
    readonly stopReason: CodexStopReason;
    /** Images the run produced, for a caller that can deliver them. */
    readonly images: readonly CodexImage[];
}
/** A decoded protocol object. */
type Record0 = Record<string, unknown>;
/**
 * Race one pending operation against a cancellation signal.
 *
 * @param pending - the operation.
 * @param signal - cancellation.
 * @returns the operation's value.
 */
export declare function raceAbort<T>(pending: Promise<T>, signal: AbortSignal | undefined): Promise<T>;
/** The stream surface the wire reads for lifecycle events. */
export interface WireInput {
    on(event: 'error', listener: (error: Error) => void): unknown;
    on(event: 'end', listener: () => void): unknown;
    off(event: 'end', listener: () => void): unknown;
}
/** The stream surface the wire writes to. */
export interface WireOutput {
    on(event: 'error', listener: (error: Error) => void): unknown;
}
/**
 * What one wire needs beyond its transport.
 *
 * Bundled rather than positional: the caller's choice set grew past the point
 * where six positional arguments stayed readable, and every one of them is a
 * named decision the caller already holds.
 */
export interface CodexWireOptions {
    /** Unattended permission policy for the thread. */
    readonly permissionMode: CodexPermissionMode;
    /** Model for `thread/start`, when the caller chose one. */
    readonly model?: string | undefined;
    /** How long the thread lives. Defaults to `ephemeral`. */
    readonly threadMode?: CodexThreadMode | undefined;
    /**
     * What the app-server records as the thread's originator.
     *
     * This is `initialize`'s `clientInfo.name`, and for a thread to appear in the
     * Codex desktop application it must be exactly `Codex Desktop` — that client
     * filters its list by this one value. The default here is therefore that
     * literal, and overriding it trades desktop visibility for an honest name.
     */
    readonly originator?: string | undefined;
}
/** The originator the Codex desktop client lists. */
export declare const DEFAULT_ORIGINATOR = "Codex Desktop";
/**
 * One app-server connection and its single ephemeral thread/turn.
 *
 * Deliberately exposes no generic request surface: supporting another product
 * method must first become part of the provider contract.
 */
export declare class CodexAppServerWire {
    #private;
    constructor(input: WireInput, output: WireOutput, transport: LineTransport, options: CodexWireOptions);
    /**
     * Install a progress narrator.
     *
     * A delegation can run for minutes, so a caller that reports progress needs
     * the child's intermediate activity rather than only its final answer. Never
     * lets a reporter's failure reach the protocol loop.
     *
     * @param onProgress - called with one line per notable event.
     */
    setProgressReporter(onProgress: (text: string) => void): void;
    /** Whether protocol output ended before a terminal turn notification. */
    get endedBeforeTerminal(): boolean;
    /**
     * Perform the required initialize/initialized handshake.
     *
     * @param signal - cancellation for an unpublished start.
     */
    initialize(signal?: AbortSignal): Promise<void>;
    /**
     * Create the run's thread and retain its identity.
     *
     * `ephemeral` follows this wire's thread mode. The app-server reports the
     * decision back, and the check below is what proves it honoured the request:
     * a `persistent` thread that came back ephemeral would be a silent downgrade,
     * and the caller is about to promise the user a thread they can resume.
     *
     * @param cwd - the parent session's workspace.
     * @param signal - cancellation for an unpublished start.
     */
    startThread(cwd: string, signal?: AbortSignal): Promise<void>;
    /**
     * Continue an existing thread instead of creating one.
     *
     * Codex 0.165+ accepts configuration overrides on `thread/resume`. Parameters
     * that are present replace the thread's historical values; absent parameters
     * leave history alone. The response is compared with the requested facts so a
     * caller never mistakes a requested model, cwd, or permission policy for an
     * effective one.
     *
     * The app-server refuses a thread with no rollout yet, so a thread becomes
     * resumable only after it has carried one turn.
     *
     * @param threadId - the thread to continue, as a previous run reported it.
     * @param overrides - explicit model/cwd/permission facts to apply.
     * @param signal - cancellation for an unpublished resume.
     */
    resumeThread(threadId: string, overrides?: CodexResumeOverrides, signal?: AbortSignal): Promise<void>;
    /**
     * Give the thread a name.
     *
     * The name is what a person sees in the Codex application's thread list. It
     * matters here because a thread this provider creates has to report itself as
     * `Codex Desktop` to be listed at all, so the name is the only place left to
     * say that the work came from DSH and what it was. Best effort: a thread that
     * ran is worth more than a naming failure, so the caller is told rather than
     * thrown at.
     *
     * @param name - the name to record.
     * @param signal - cancellation for an unpublished request.
     * @returns whether the app-server accepted it.
     */
    setThreadName(name: string, signal?: AbortSignal): Promise<boolean>;
    /** The images this run produced, in arrival order. */
    get images(): readonly CodexImage[];
    /** The thread this wire is working in, once it has one. */
    get threadId(): string | undefined;
    /** Authoritative turn id, adopted only after the start response agrees. */
    get turnId(): string | undefined;
    /** Conservative request boundary, not inferred from progress or a known PID. */
    get dispatch(): 'not-dispatched' | 'possible' | 'accepted';
    /** Token usage attributable to this one delegation; never a zero guess. */
    get usageReport(): CodexUsageReport;
    /** Account rate limits, kept separate from token usage. */
    get rateLimitsReport(): CodexRateLimitsReport;
    /** The requested and effective configuration of the one start/resume. */
    get configuration(): AppliedConfiguration | undefined;
    get turnConfiguration(): TurnConfiguration | undefined;
    /**
     * Submit the one text-only task and wait for this thread/turn's terminal
     * notification.
     *
     * @param texts - already validated task text blocks.
     * @param signal - local cancellation for the published run.
     * @param effort - per-turn thinking level, if the caller chose one.
     * @returns the selected output and its stop reason.
     */
    runTurn(texts: readonly TaskText[], signal?: AbortSignal, effort?: string, images?: readonly string[], outputSchema?: Record0, lifecycle?: (stage: 'dispatch-intent' | 'dispatch-possible' | 'turn-accepted') => Promise<void>): Promise<WireRunResult>;
    /** The best non-commentary answer observed so far, preserving exact bytes. */
    get partialOutput(): readonly {
        readonly type: 'text';
        readonly text: string;
    }[];
    /**
     * Best-effort remote cancellation. Local settlement and process teardown stay
     * authoritative when the child no longer accepts protocol requests.
     */
    interrupt(): void;
    /** The latest safe unattended permission fact observed for this run. */
    collectDiagnostic(): string | undefined;
    /** The structured failure fact observed for this published turn. */
    collectFailure(): CodexFailureFacts | undefined;
    /** Detach listeners and fail outstanding requests. Idempotent. */
    close(): void;
}
export {};
//# sourceMappingURL=wire.d.ts.map